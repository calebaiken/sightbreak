# Neutral native input/lifecycle comparison

This packet contains two anonymously named samples of completed measurements.
The commissioning parent holds the identity map and original counterparts
separately. Comparative judgement belongs to a separate critic. No new native
execution was performed to prepare this packet.

## Start here

1. Verify the externally supplied SHA256 of `MANIFEST.json`, then run:

   ```text
   python -B verify_packet.py --manifest-sha256 <external-pin>
   ```

2. Read `run_manifest.json`, `schedule.json`, `CLOCKS_AND_LIMITS.md` and the
   `shared/` fixture/context. There are **16 pairs per sample**, hence **32 pairs
   and 64 native peer processes**, plus **11 focused native gate processes per
   sample** (22 supplemental gate processes, outside the 64-peer count).
3. In each sample, inspect each case's `server.json`, `client.json`, native logs,
   `capture.json`, and `timeline_index.json`. The index is a lossless-reference
   aid derived from raw row indices, not a replacement for the captures.
4. Inspect the 11 gate logs per sample, especially held-edge lifecycle,
   interrupted welcome, alias confirmation and privacy controls. Recorded case
   lines and process receipts are indexed in the run manifest.

The offline verifier checks bytes, file inventory, source-cleanliness receipts,
all 64 recorded peer return codes, completion markers and native-error scans,
22 focused gate receipts, and deterministic timeline extraction. It **does not
choose a winning sample or provide an independent outcome verdict**. A SHA pin
establishes byte identity, not independent truth of measurements or the recorder.

## Observations available to the critic

- **Control clearing versus physical stop:** compare `simulation_t - last_input`
  at the first `move_x == 0` row with adjacent rows. Separately inspect `vx` and
  `x` until x-axis rest. Do not call the entire ACK-to-rest delay a simulation-time
  neutralization deadline.
- **Wall-clock idle cleanup:** inspect the last observed lifecycle update,
  `peer_last_input_msec`, the last bound/first unbound rows and final cleanup
  tables. The index gives a callback-sampling bracket for elapsed inactivity;
  the exact relative-clock origin needed for a direct millisecond-age subtraction
  was not retained.
- **ACK/snapshot recovery:** inspect resumed snapshot counters, pending history,
  fresh sequence production, resumed authority ACKs and later signed leftward
  controls. The snapshot-gap observation ends at eight seconds; it does not
  establish a further thirty-second healthy-session soak.
- **Edges:** inspect `fire_held`, shot and ammo transitions across silence and
  genuine release/press. The live pair captures the fire latch, not all jump or
  utility latches. The focused input-lifecycle fixture covers additional held
  edge behavior under its own controlled conditions.
- **Default prediction off:** the off-mode launch omits `--prediction`, the shared
  fixture omits the prediction setting, and the raw client report records false.
  Input sequences and authority movement are still observable in that mode.
- **Privacy/authority:** the pair records cumulative privacy-check counters and
  authoritative x/velocity/ACK/shot/ammo samples. The focused tests provide
  additional assertions. Snapshot payloads and a full wire capture were not
  retained, so the privacy counter cannot be re-audited packet-by-packet here.

## Neutralization and custody

`provenance.json` records the transformation for every exported source artifact.
Raw peer JSON, native logs, barrier/ready records and focused gate logs are copied
byte-for-byte. Metadata keeps numeric observations, clean-status strings, timing
and return codes, but removes source commits/tree/module identities, prior
sample names, absolute command paths and policy/aggregate verdict flags.
Commands contain explicit placeholders; they are redacted receipts, not directly
executable commands. The full originals and identity map are held outside this
packet. `failure_retention_index.json` indexes prior unsuccessful/superseded
attempts without including them in the outcome dataset or naming their sources.

The original committed Git blobs and their retained disk counterparts were
checked during preparation; the separate parent custody record contains the
repository identities and byte proofs. A critic given only this packet can
verify its internal bytes and recorded facts, not independently resolve the
withheld Git identities. Original native logs are historical recorder output,
not cryptographically signed engine/OS attestations. Return codes come from the
controller's awaited process receipts.

There is no supplied winner label or source-review verdict. Raw facts, native
test assertions, timestamps, ports, differing check counts and outcomes remain
visible; identity blinding does not prevent inference from those facts. Zip
metadata is normalized, but captured timestamps are not altered.

## Remaining boundary

The **120-command history cap still blocks fresh intent until acknowledgments
resume**. Sequence freshness is not proof of human presence: a stream of higher
valid sequence numbers can continue providing controls. Protocol 6, default-off
prediction and disabled live rewind remain the measured settings. This packet
does not establish device/rendered feel, Internet behavior or aggregate acceptance.
