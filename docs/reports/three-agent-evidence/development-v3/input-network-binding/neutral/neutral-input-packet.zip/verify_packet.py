"""Offline byte/capture verifier and descriptive extractor. Never starts a game.

No sample is declared a winner here. Gate thresholds belong to the separate
review. Run with the externally supplied manifest pin; output is JSON to stdout.
"""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import re

ERROR = re.compile(r"SCRIPT ERROR|ERROR:|ObjectDB instances leaked|resources still in use|CrashHandlerException|Program crashed", re.I)


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def point(rows, index):
    return None if index is None else {"row_index": index, **rows[index]}


def changes(rows, fields):
    return [{"row_index": i, "t": r["t"], "values": {k: r[k] for k in fields},
             "previous_row_index": i - 1 if i else None}
            for i, r in enumerate(rows) if i == 0 or any(r[k] != rows[i - 1][k] for k in fields)]


def describe(server, client, case):
    s, c = server["rows"], client["rows"]
    def first(rows, predicate):
        return next((i for i, row in enumerate(rows) if predicate(i, row)), None)
    def window(start, end):
        selected = [(i, r) for i, r in enumerate(s) if start <= r["t"] <= end]
        if not selected:
            return {"requested_inclusive": [start, end], "row_count": 0}
        first_i, first_r = selected[0]
        last_i, last_r = selected[-1]
        return {"requested_inclusive": [start, end], "row_count": len(selected),
                "first_row_index": first_i, "last_row_index": last_i,
                "actual_t": [first_r["t"], last_r["t"]],
                "x_first_last_m": [first_r["x"], last_r["x"]],
                "absolute_x_displacement_m": abs(last_r["x"] - first_r["x"]),
                "max_abs_vx_mps": max(abs(r["vx"]) for _, r in selected),
                "largest_signed_vx_mps": max(r["vx"] for _, r in selected)}
    result = {"rows": {"server": len(s), "client": len(c)},
              "first_server": point(s, 0), "last_server": point(s, len(s) - 1),
              "first_client": point(c, 0), "last_client": point(c, len(c) - 1),
              "observation_window": window(3.8, 4.8), "fresh_direction_window": window(7.0, 7.8),
              "control_and_edge_changes": changes(s, ["move_x", "fire_held", "shots", "ammo", "peer_count"]),
              "ack_changes": changes(s, ["ack"]),
              "liveness_updates_at_sampled_rows": changes(s, ["last_input", "peer_last_input_msec"]),
              "snapshot_counter_changes": changes(c, ["accepted_snapshots", "dropped_snapshots"]),
              "first_history_cap": point(c, first(c, lambda i, r: r["pending"] == 120)),
              "cleanup_reported": {k: server[k] for k in ("final_peer_count", "lifecycle_entries", "input_queues", "pending_joins")},
              "captured_counters": {"server_shots": server["shots"], "client_privacy_violations": client["privacy_violations"],
                                    "client_dropped_snapshots": client["dropped_snapshots"], "client_max_pending": client["max_pending"]}}
    # Mirror only the prior extractor's ACK anchor; distinguish control clear
    # from velocity rest instead of conflating the two in one stop metric.
    relevant = [(i, r) for i, r in enumerate(s) if 2.0 <= r["t"] < 4.8]
    ack_change_indices = [i for j, (i, r) in enumerate(relevant) if j == 0 or r["ack"] != relevant[j - 1][1]["ack"]]
    anchor = ack_change_indices[-1] if ack_change_indices else None
    clear = first(s, lambda i, r: anchor is not None and i >= anchor and r["t"] < 5 and abs(r["move_x"]) < .001)
    rest = first(s, lambda i, r: clear is not None and i >= clear and r["t"] < 5 and abs(r["vx"]) < .001)
    result["silence_opportunity"] = {
        "scope": "last ACK-change row in [2,4.8), followed only until t<5; inspect scenario before interpreting",
        "last_ack_anchor": point(s, anchor), "row_before_control_clear": point(s, clear - 1 if clear else None),
        "first_control_clear": point(s, clear), "first_x_velocity_rest": point(s, rest),
        "simulation_silence_age_at_clear": s[clear]["simulation_t"] - s[clear]["last_input"] if clear is not None else None,
        "simulation_silence_age_before_clear": s[clear - 1]["simulation_t"] - s[clear - 1]["last_input"] if clear else None,
        "deceleration_simulation_seconds": s[rest]["simulation_t"] - s[clear]["simulation_t"] if clear is not None and rest is not None else None,
        "deceleration_observed_wall_seconds": s[rest]["t"] - s[clear]["t"] if clear is not None and rest is not None else None,
        "x_rest_wall_seconds_after_ack_anchor": s[rest]["t"] - s[anchor]["t"] if rest is not None and anchor is not None else None}
    if case["scenario"] == "snapshot-gap":
        snapshot = first(c, lambda i, r: i > 0 and r["t"] >= 5 and r["accepted_snapshots"] > c[i - 1]["accepted_snapshots"])
        cap = first(c, lambda i, r: r["pending"] == 120 and r["t"] < 5)
        pending = first(c, lambda i, r: cap is not None and r["t"] >= 5 and r["pending"] < 120)
        production = first(c, lambda i, r: cap is not None and r["t"] >= 5 and r["sequence"] > c[cap]["sequence"])
        ack = first(s, lambda i, r: i > 0 and r["t"] >= 5 and r["ack"] > s[i - 1]["ack"])
        left = first(s, lambda i, r: r["t"] >= 6 and r["move_x"] < -.1)
        result["snapshot_recovery"] = {"first_resumed_snapshot_counter": point(c, snapshot),
            "first_pending_below_cap": point(c, pending), "first_new_sequence_after_cap": point(c, production),
            "first_resumed_ack": point(s, ack), "first_leftward_authority_control": point(s, left),
            "peer_count_values_through_observation": sorted(set(r["peer_count"] for r in s)),
            "limit": "eight-second trace; later 30-second healthy retention was not recorded"}
    unbound = first(s, lambda i, r: i > 0 and r["peer_count"] == 0 and s[i - 1]["peer_count"] > 0)
    updates = [i for i, r in enumerate(s) if r["peer_last_input_msec"] >= 0 and (i == 0 or r["peer_last_input_msec"] != s[i - 1]["peer_last_input_msec"])]
    update = next((i for i in reversed(updates) if unbound is None or i < unbound), None)
    result["wall_expiry"] = {"last_observed_liveness_update": point(s, update),
        "row_before_liveness_update": point(s, update - 1 if update else None),
        "last_bound_row": point(s, unbound - 1 if unbound else None), "first_unbound_row": point(s, unbound),
        "reported_disconnected_at": server["disconnected_at"],
        "inactivity_seconds_bracket_from_callback_samples": [s[unbound - 1]["t"] - s[update]["t"], s[unbound]["t"] - s[update - 1]["t"]] if unbound and update else None,
        "limit": "t is server monotonic milliseconds relative to an unretained start_msec; bracket is not an exact server wall-age reading"}
    return result


def verify(root, expected_pin):
    problems = []
    def require(ok, label):
        if not ok:
            problems.append(label)
    manifest_path = root / "MANIFEST.json"
    require(sha(manifest_path.read_bytes()) == expected_pin, "manifest pin mismatch")
    manifest = load(manifest_path)
    actual_files = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and p != manifest_path}
    require(actual_files == set(manifest["files"]), "manifest file set mismatch")
    for name, entry in manifest["files"].items():
        data = (root / name).read_bytes()
        require(len(data) == entry["bytes"] and sha(data) == entry["sha256"], "file bytes mismatch: " + name)
    samples = load(root / "run_manifest.json")["samples"]
    require(len(samples) == 2, "expected two samples")
    counts = collections.Counter()
    sample_counts = {}
    for sample in samples:
        sample_id = sample["sample"]
        require(sample["source_before_status"] == sample["source_after_status"] == sample["harness_status"] == "", "recorded source cleanliness: " + sample_id)
        require(sample["source_unchanged"] and sample["source_identity_fields_equal_before_after"], "recorded source continuity: " + sample_id)
        cases = sample["cases"]
        require(len(cases) == 16, "expected sixteen pairs: " + sample_id)
        cells = collections.Counter((c["scenario"], c["prediction_requested"], c["repeat"]) for c in cases)
        require(len(cells) == 16 and set(cells.values()) == {1}, "duplicate or missing cases: " + sample_id)
        for case in cases:
            folder = root / sample_id / case["case"]
            capture = load(folder / "capture.json")
            server, client = load(folder / "server.json"), load(folder / "client.json")
            derived = load(folder / "timeline_index.json")
            require(derived == describe(server, client, case), "timeline extraction mismatch: " + str(folder.relative_to(root)))
            for role in ("server", "client"):
                text = (folder / (role + ".log")).read_text(encoding="utf-8", errors="replace")
                require(capture["exits"][role] == 0, "recorded process exit: " + str(folder.relative_to(root)) + "/" + role)
                require(not ERROR.search(text), "native error scan: " + str(folder.relative_to(root)) + "/" + role)
                sentinel = "INPUT_FRESHNESS_PROBE role=" + role + " scenario=" + case["scenario"] + " completed"
                require(sentinel in text, "missing completion marker: " + str(folder.relative_to(root)) + "/" + role)
                counts["native_peer_exits_checked"] += 1
            require(client["prediction"] == case["prediction_requested"], "prediction configuration mismatch")
            has_flag = "--prediction" in capture["normalized_commands"]["client"]
            require(has_flag == case["prediction_requested"], "prediction command flag mismatch")
            require(client["protocol"] == server["protocol"] == 6, "recorded protocol mismatch")
            require(client["hit_history_frames"] == server["hit_history_frames"] == 0, "recorded diagnostic history mismatch")
            counts["native_pairs_checked"] += 1
        for gate in sample["focused_gates"]:
            text = (root / sample_id / "gates" / gate["log"]).read_text(encoding="utf-8", errors="replace")
            require(gate["exit"] == 0 and not ERROR.search(text), "gate process/log receipt: " + sample_id + "/" + gate["name"])
            require(sha((root / sample_id / "gates" / gate["log"]).read_bytes()) == gate["log_sha256"], "gate raw log hash")
            counts["focused_gate_processes_checked"] += 1
        require(len(sample["focused_gates"]) == 11, "expected eleven focused groups")
        sample_counts[sample_id] = {"pairs": len(cases), "focused_groups": len(sample["focused_gates"])}
    require(counts["native_peer_exits_checked"] == 64 and counts["focused_gate_processes_checked"] == 22, "full process counts")
    return {"integrity_ok": not problems, "problems": problems, "manifest_sha256": expected_pin,
            "counts": dict(counts), "samples": sample_counts,
            "scope": "byte integrity, receipt/log coverage and deterministic extraction only; no comparative verdict; recorded exits are controller receipts, not independently signed OS attestations"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--manifest-sha256", required=True)
    args = parser.parse_args()
    result = verify(args.root, args.manifest_sha256)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["integrity_ok"] else 1)
