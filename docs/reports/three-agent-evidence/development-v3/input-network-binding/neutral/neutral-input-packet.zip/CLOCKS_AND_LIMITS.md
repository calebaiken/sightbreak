# Clock definitions and capture limits

## Pre-observation preparation and warmup

The native class/resource cache was already imported. Each pair starts its server
and waits for a ready file, then starts the client and waits for admitted/connected
readiness. The controller publishes an empty start file for 250 ms as a reader
negative control, then atomically publishes a Unix epoch 500 ms in the future.
On Windows a destination-open rename can be retried, bounded by five seconds;
each retry recomputes a future start. The actual epoch is retained in each case's
`barrier/start.json`, and read/publish retry counters are captured.

The physics/ENet lifecycle runs before the observation barrier. During this time
the scripted move is zero and fire false. Warmup duration is variable. Per-role
spawn, ready and start-latch timestamps were **not captured**, so an exact per-peer
wall warmup cannot be reconstructed. The first server row's `simulation_t` and
the first client row's sequence/pending/snapshot counts expose pre-observation
state; they are not a fabricated precise warmup duration. Ready-file content is
retained, but filesystem copy/Git timestamps are not measurement timestamps.

## Observed clocks

- `t`: `(Time.get_ticks_msec() - start_msec) / 1000` in each process, with
  `start_msec` derived from the common published epoch. Values are sampled after
  the actual Match physics callback. First/last samples need not be exactly 0/8/34.
- `simulation_t`: server `_elapsed`, incremented by physics delta. It includes
  pre-barrier simulation and is independent of wall-clock scheduling delays.
- `last_input`: simulation time stored by the accepted-input path. The existing
  silence test uses **strictly greater than 0.3 simulation seconds**; frame
  quantization and floating-point boundaries matter.
- `peer_last_input_msec`: server monotonic wall-clock time stored by the lifecycle
  accepted-input path, or −1 once the observed lifecycle entry is gone.
- Peer expiry uses **at least 30,000 monotonic wall milliseconds**. The raw report
  does not retain server `start_msec`, so subtracting `t*1000` directly from this
  absolute monotonic timestamp would be invalid.

The timeline index brackets an update between its previous callback and the
first callback reflecting it, and retirement between the last bound and first
unbound callbacks. These are sampling bounds, not an exact service-decision
timestamp. `disconnected_at` is the fixture's first observed absent binding.

## Neutralization, deceleration and action edges

The common authority code first chooses a queued command, then applies the
silence guard. It saves fire/jump/grenade/smoke latch states, installs neutral
controls, advances actor authority, and restores those latches. Silence is not
a genuine button release. The capture records the resulting fire latch.

The common movement code uses `move_toward` rather than setting horizontal
velocity immediately to zero. Ground acceleration/deceleration is 28 m/s²;
air acceleration is 7 m/s², with nominal physics delta 1/60 s. The configured
0.2 movement input requests 1.02 m/s. `move_x == 0` therefore precedes x-axis rest.
The captures do not include the grounded flag or y/z position/velocity. Inspect
the actual x/vx samples; do not infer an exact full-vector stop or contact state.

## Scheduled windows

All windows are applied by the fixture to its sampled relative wall clock:

| Window | Definition |
| --- | --- |
| Standard case observation | Report at first process callback with t ≥ 8 s |
| Replay observation | Report at first process callback with t ≥ 34 s |
| Initial held movement | 0 ≤ t < 3.5 s; move +0.2 on x |
| Neutral requested movement | 3.5 ≤ t < 6 s |
| Later fresh-direction movement | t ≥ 6 s; move −0.2 on x |
| Fire | Held from t ≥ 0 except genuine release during 6.2 ≤ t < 6.4 s |
| Input-gap override | Return without client processing during 1 ≤ t < 1.2 s |
| Snapshot-gap override | Discard application snapshots during 1 ≤ t < 5 s |
| Stale-replay override | From t ≥ 2 s, return after resending the last stored batch at a nominal 30 Hz while connected; later movement/fire schedule is not processed |
| Travel observation | Inclusive authority rows 3.8 ≤ t ≤ 4.8 s |
| Fresh-direction observation | Inclusive authority rows 7 ≤ t ≤ 7.8 s |

Snapshots resume far earlier than a 30-second idle interval in the eight-second
snapshot-gap scenario. Inspect actual accepted-snapshot, pending, sequence, ACK
and peer-binding traces rather than treating recovery as an isolated boolean.

Prior declared thresholds are supplied for criticism, not a packet verdict:
under 0.001 m / m/s travel / speed in the travel window, x-axis rest within 350 ms
of the chosen last-ACK anchor before t=5, recovery vx below −0.9 m/s, two shots
with ammo 15→13 in the three eight-second scenarios, and replay retirement at
31.5–32.5 s with the four recorded cleanup tables empty. The 350 ms ACK-to-rest
gate is distinct from the 300 ms simulation-time input-neutralization policy.

## Packet schedule and authenticity limits

No randomized impairment seed was used or captured. The fault schedule is
deterministic application-level omission and replay, not a seeded UDP proxy.
The shared client code targets one input send per 1/30 simulation seconds and
authority snapshots every third nominal 60 Hz tick. OS/ENet callback timing is
not deterministic. There is **no PCAP, datagram send/receive timestamp list,
packet payload archive, or ENet retransmission trace** in the retained evidence.

`schedule.json` states the configured schedule. Raw server ACK/liveness updates
and client accepted/dropped snapshot counters, plus their indexed changes, are
the actual captured observations. Counter changes can aggregate more than one
event between callbacks and must not be relabeled an exact wire-packet schedule.
The fixed replay packet's bytes were not retained. Loopback UDP ports and barrier
epochs are actual recorded values and remain available in the neutral receipts.

Both peers latch reports before the controller releases their stop barrier.
The fixture then deletes Match, waits a frame and drains 0.7 seconds for audio
cleanup. Process exit codes and native log completion markers are retained.
