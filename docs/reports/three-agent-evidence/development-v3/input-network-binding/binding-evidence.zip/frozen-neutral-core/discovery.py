import pathlib,json,sys,hashlib,re
sys.stdout.reconfigure(encoding='utf-8')
root=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-neutral-20261023T005129814690Z')
p=root/'payload'
(root/'discovery.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
m=json.loads((p/'run_manifest.json').read_bytes())
print('MANIFEST_EXTRA',json.dumps({k:v for k,v in m.items() if k!='samples'},indent=2))
for sample in m['samples']:
 print('\nSAMPLE',sample['sample'],'RECEIPT',json.dumps({k:v for k,v in sample.items() if k not in ['cases','focused_gates']}))
 for case in sample['cases']:
  path=p/sample['sample']/case['case'];s=json.loads((path/'server.json').read_bytes());c=json.loads((path/'client.json').read_bytes());cap=json.loads((path/'capture.json').read_bytes());sr=s['rows'];cr=c['rows']
  win=[r for r in sr if 3.8<=r['t']<=4.8]; rec=[r for r in sr if 7<=r['t']<=7.8]
  changes={k:[(i,r['t'],r[k]) for i,r in enumerate(sr) if i==0 or r[k]!=sr[i-1][k]] for k in ['ack','last_input','peer_last_input_msec','move_x','fire_held','shots','ammo','peer_count']}
  print(case['case'],case['scenario'],'prediction',case['prediction_requested'],'rows',len(sr),len(cr),'initialsim',sr[0]['simulation_t'],'travel',abs(win[-1]['x']-win[0]['x']),'maxvx',max(abs(r['vx']) for r in win),'recovery_vx',max(r['vx'] for r in rec),'shots',s['shots'],'final',sr[-1]['ammo'],'pendingmax',max(r['pending'] for r in cr),'accepted/dropped',c['accepted_snapshots'],c['dropped_snapshots'],'disconnect',s['disconnected_at'],'cleanup',[s[k] for k in ['final_peer_count','lifecycle_entries','input_queues','pending_joins']],'lastack',changes['ack'][-1],'lastlive',changes['peer_last_input_msec'][-2:])
  print(' LOGS',json.dumps({'server':(path/'server.log').read_text(),'client':(path/'client.log').read_text()}))
  if case['scenario'] in ['snapshot-gap','stale-replay']:
   print(' CHANGES',json.dumps({k:v for k,v in changes.items() if k not in ['ack','last_input','peer_last_input_msec']}))
   print(' ACK_LAST_BEFORE5',[e for e in changes['ack'] if 2<=e[1]<5][-10:])
   caps=[(i,r) for i,r in enumerate(cr) if r['pending']>=120]
   print(' HISTORY_CAP',json.dumps({'first':caps[0] if caps else None,'last':caps[-1] if caps else None,'count':len(caps)}))
   if case['case'] in ['case-05','case-07']:
    fields=['t','simulation_t','last_input','peer_last_input_msec','ack','move_x','vx','x','shots','fire_held','ammo','peer_count']
    relevant=[]
    for i,r in enumerate(sr):
     if (case['scenario']=='snapshot-gap' and 3.65<=r['t']<=4.25) or (case['scenario']=='stale-replay' and 1.95<=r['t']<=2.50) or 31.9<=r['t']<=32.1:
      relevant.append({'row_index':i,**{k:r[k] for k in fields}})
    print(' ACTUAL_ROWS',json.dumps(relevant))
    print(' CLIENT_AROUND_RECOVERY',json.dumps([{'row_index':i,**r} for i,r in enumerate(cr) if 4.9<=r['t']<=5.25]))
 for g in sample['focused_gates']:
  text=(p/sample['sample']/'gates'/g['log']).read_text()
  print('GATE',g['name'],'RECEIPT',json.dumps(g),'RAW_LOG',text)