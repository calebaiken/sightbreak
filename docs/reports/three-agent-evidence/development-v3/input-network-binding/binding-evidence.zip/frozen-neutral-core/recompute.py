import pathlib,sys,json,hashlib,zipfile,stat,re,math,datetime,collections
sys.stdout.reconfigure(encoding='utf-8')
ROOT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-neutral-20261023T005129814690Z')
P=ROOT/'payload'
OUT=ROOT/'independent-audit'
OUT.mkdir(exist_ok=False)
(OUT/'recompute.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
def sha(b): return hashlib.sha256(b).hexdigest()
def write(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def load(path): return json.loads(path.read_bytes())
def ref(rows,i): return None if i is None or i<0 else {'row_index':i,**rows[i]}
def first(indices): return next(iter(indices),None)
def changes(rows,keys): return [i for i,r in enumerate(rows) if i==0 or any(r[k]!=rows[i-1][k] for k in keys)]
def events(rows,keys): return [{'row_index':i,'t':rows[i]['t'],'values':{k:rows[i][k] for k in keys},'previous_row_index':i-1 if i else None} for i in changes(rows,keys)]
def window(rows,lo,hi):
 ids=[i for i,r in enumerate(rows) if lo<=r['t']<=hi]
 if not ids: raise ValueError('empty window')
 a,b=ids[0],ids[-1]
 return {'requested_inclusive':[lo,hi],'row_count':len(ids),'first_row_index':a,'last_row_index':b,'actual_t':[rows[a]['t'],rows[b]['t']],'x_first_last_m':[rows[a]['x'],rows[b]['x']],'absolute_x_displacement_m':abs(rows[b]['x']-rows[a]['x']),'max_abs_vx_mps':max(abs(rows[i]['vx']) for i in ids),'largest_signed_vx_mps':max(rows[i]['vx'] for i in ids)}
def difference(a,b,path=''):
 result=[]
 if isinstance(a,dict) and isinstance(b,dict):
  if set(a)!=set(b): result.append({'path':path,'key_difference':[sorted(set(a)-set(b)),sorted(set(b)-set(a))]})
  for k in set(a)&set(b): result.extend(difference(a[k],b[k],path+'/'+k))
 elif isinstance(a,list) and isinstance(b,list):
  if len(a)!=len(b): result.append({'path':path,'lengths':[len(a),len(b)]})
  for i,(v,w) in enumerate(zip(a,b)): result.extend(difference(v,w,path+'/'+str(i)))
 elif isinstance(a,(int,float)) and not isinstance(a,bool) and isinstance(b,(int,float)) and not isinstance(b,bool):
  if not math.isclose(a,b,rel_tol=0,abs_tol=1e-10): result.append({'path':path,'independent':a,'packet':b})
 elif a!=b: result.append({'path':path,'independent':a,'packet':b})
 return result
def series(rows,key):
 ds=[b[key]-a[key] for a,b in zip(rows,rows[1:])]
 return {'first':rows[0][key],'last':rows[-1][key],'minimum':min(r[key] for r in rows),'maximum':max(r[key] for r in rows),'positive_deltas':sum(v>0 for v in ds),'negative_deltas':sum(v<0 for v in ds),'zero_deltas':sum(v==0 for v in ds),'largest_positive_delta':max(ds,default=0),'largest_negative_delta':min(ds,default=0)}
def scan(text): return [line for line in text.splitlines() if re.search(r'SCRIPT ERROR|(?:^|\s)ERROR:|Parse Error|FATAL|crash|backtrace|REVIEW_ALIAS FAIL',line,re.I)]
manifest=load(ROOT/'MANIFEST.json')
assert len(manifest['files'])==362
inventory=[];names=set();folded=set()
reserved={'CON','PRN','AUX','NUL'}|{'COM'+str(i) for i in range(1,10)}|{'LPT'+str(i) for i in range(1,10)}
with zipfile.ZipFile(ROOT/'neutral-input-packet.zip') as z:
 assert len(z.infolist())==363
 for info in z.infolist():
  n=info.filename;parts=n.split('/');pos=pathlib.PurePosixPath(n)
  assert n and not pos.is_absolute() and chr(92) not in n and ':' not in n
  assert all(part not in ('','..','.') and not part.endswith((' ','.')) and not any(ord(c)<32 for c in part) and part.split('.')[0].upper() not in reserved for part in parts)
  assert not info.is_dir() and stat.S_IFMT(info.external_attr>>16) in (0,stat.S_IFREG)
  assert not info.flag_bits&1 and info.file_size<5000000
  assert n not in names and n.casefold() not in folded
  names.add(n);folded.add(n.casefold());b=z.read(info)
  expected={'bytes':len((ROOT/'MANIFEST.json').read_bytes()),'sha256':'fe83c4bdcc1ea662f034ff4ebc340a4e115ed27e8a7d404a2aa80175d84146ce'} if n=='MANIFEST.json' else manifest['files'][n]
  assert len(b)==expected['bytes'] and sha(b)==expected['sha256']
  assert (P.joinpath(*parts)).read_bytes()==b
  inventory.append({'path':n,'bytes':len(b),'sha256':sha(b),'crc32':f'{info.CRC:08x}','compression_ratio':len(b)/max(info.compress_size,1),'safe_regular':True,'external_manifest_match':True,'extracted_bytes_match':True})
assert names==set(manifest['files'])|{'MANIFEST.json'}
write('inventory.json',{'manifest_payloads':362,'zip_regular_files':363,'embedded_manifest_identical':True,'uncompressed_bytes':sum(i['bytes'] for i in inventory),'all_safe_and_verified':True,'files':inventory})
pins={'frozen_git_commit':'0cbc3ae7a9a017aa179eaeff61cf902629de1c0d','source_blobs_only':['docs/reports/network-input-freshness-v3/blind/neutral-input-packet.zip','docs/reports/network-input-freshness-v3/blind/MANIFEST.json'],'zip_sha256':sha((ROOT/'neutral-input-packet.zip').read_bytes()),'manifest_sha256':sha((ROOT/'MANIFEST.json').read_bytes()),'python_executable':sys.executable,'python_version':sys.version,'native_execution_performed':False,'network_or_services_used':False,'implementation_source_semantically_inspected':False,'identity_mapping_inspected':False,'provenance_content_inspected':False}
assert pins['zip_sha256']=='8fb111324051b4bfc590a216ab09c107ef0c10605f755b7e481757d125172112'
assert pins['manifest_sha256']=='fe83c4bdcc1ea662f034ff4ebc340a4e115ed27e8a7d404a2aa80175d84146ce'
write('input-pins.json',pins)
m=load(P/'run_manifest.json'); schedule=load(P/'schedule.json');retention=load(P/'failure_retention_index.json')
write('failure-retention-index.json',retention)
raw=(OUT/'raw-audit.jsonl').open('x',encoding='utf-8',newline='\n')
def audit(obj): raw.write(json.dumps(obj,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n')
audit({'record_type':'audit_header','pins':pins,'clock_rule':'simulation_t-last_input is simulation age; peer_last_input_msec has unknown relative origin; never subtract t*1000 from it','source':'full matched raw peer rows, logs and controller receipts; historical recorder evidence, not execution attestation'})
all_cases=[];all_gate_logs=[];cross=[];sample_objects=[]
for sample in m['samples']:
 label=sample['sample'];cases=[];gates=[]
 for spec in sample['cases']:
  cid=spec['case'];base=P/label/cid;s=load(base/'server.json');c=load(base/'client.json');receipt=load(base/'capture.json');t=load(base/'timeline_index.json');sr=s['rows'];cr=c['rows']
  logs={role:(base/(role+'.log')).read_text(encoding='utf-8') for role in ['server','client']}
  context={'record_type':'case_context','sample':label,'case':cid,'specification':spec,'server_report':{k:v for k,v in s.items() if k!='rows'},'client_report':{k:v for k,v in c.items() if k!='rows'},'capture_receipt':receipt,'raw_logs':logs,'barrier_start':load(base/'barrier/start.json'),'barrier_stop':(base/'barrier/stop').read_text(),'ready_files':{role:(base/(role+'.json.ready')).read_text() for role in ['server','client']}}
  audit(context)
  for role,rows in [('server',sr),('client',cr)]:
   for i,r in enumerate(rows):
    assert all(not isinstance(v,float) or math.isfinite(v) for v in r.values())
    a={'record_type':role+'_row','sample':label,'case':cid,'row_index':i,'actual':r}
    keys=['t','simulation_t','ack','last_input','peer_last_input_msec','x','vx','rejected','shots','ammo'] if role=='server' else ['t','sequence','pending','accepted_snapshots','dropped_snapshots','x']
    a['deltas_from_previous']=None if i==0 else {k:r[k]-rows[i-1][k] for k in keys}
    if role=='server': a['simulation_silence_age_seconds']=r['simulation_t']-r['last_input']
    audit(a)
  anchors=[i for i in changes(sr,['ack']) if 2<=sr[i]['t']<4.8]
  anchor=anchors[-1] if anchors else None
  clear=first(i for i in range(anchor or 0,len(sr)) if sr[i]['t']<5 and sr[i]['move_x']==0)
  rest=first(i for i in range(anchor or 0,len(sr)) if sr[i]['t']<5 and abs(sr[i]['vx'])<.001)
  cap=first(i for i,r in enumerate(cr) if r['pending']>=120)
  live=[i for i in changes(sr,['peer_last_input_msec']) if sr[i]['peer_last_input_msec']>=0]
  lastlive=live[-1] if live else None
  unbound=first(i for i in range(1,len(sr)) if sr[i-1]['peer_count']>0 and sr[i]['peer_count']==0)
  travel=window(sr,3.8,4.8);recover=window(sr,7.0,7.8)
  silence={'scope':'last ACK-change row in [2,4.8), followed only until t<5; inspect scenario before interpreting','last_ack_anchor':ref(sr,anchor),'row_before_control_clear':ref(sr,clear-1) if clear is not None else None,'first_control_clear':ref(sr,clear),'first_x_velocity_rest':ref(sr,rest),'simulation_silence_age_at_clear':None if clear is None else sr[clear]['simulation_t']-sr[clear]['last_input'],'simulation_silence_age_before_clear':None if clear is None or clear==0 else sr[clear-1]['simulation_t']-sr[clear-1]['last_input'],'deceleration_simulation_seconds':None if clear is None or rest is None else sr[rest]['simulation_t']-sr[clear]['simulation_t'],'deceleration_observed_wall_seconds':None if clear is None or rest is None else sr[rest]['t']-sr[clear]['t'],'x_rest_wall_seconds_after_ack_anchor':None if anchor is None or rest is None else sr[rest]['t']-sr[anchor]['t']}
  wall={'last_observed_liveness_update':ref(sr,lastlive),'row_before_liveness_update':ref(sr,lastlive-1) if lastlive is not None else None,'last_bound_row':ref(sr,unbound-1) if unbound is not None else None,'first_unbound_row':ref(sr,unbound),'reported_disconnected_at':s['disconnected_at'],'inactivity_seconds_bracket_from_callback_samples':None if unbound is None or lastlive is None else [sr[unbound-1]['t']-sr[lastlive]['t'],sr[unbound]['t']-sr[max(lastlive-1,0)]['t']],'limit':'t is server monotonic milliseconds relative to an unretained start_msec; bracket is not an exact server wall-age reading'}
  reconstructed={'rows':{'server':len(sr),'client':len(cr)},'first_server':ref(sr,0),'last_server':ref(sr,len(sr)-1),'first_client':ref(cr,0),'last_client':ref(cr,len(cr)-1),'observation_window':travel,'fresh_direction_window':recover,'control_and_edge_changes':events(sr,['move_x','fire_held','shots','ammo','peer_count']),'ack_changes':events(sr,['ack']),'liveness_updates_at_sampled_rows':events(sr,['last_input','peer_last_input_msec']),'snapshot_counter_changes':events(cr,['accepted_snapshots','dropped_snapshots']),'first_history_cap':ref(cr,cap),'cleanup_reported':{k:s[k] for k in ['final_peer_count','lifecycle_entries','input_queues','pending_joins']},'captured_counters':{'server_shots':s['shots'],'client_privacy_violations':c['privacy_violations'],'client_dropped_snapshots':c['dropped_snapshots'],'client_max_pending':c['max_pending']},'silence_opportunity':silence,'wall_expiry':wall}
  snap=None
  if spec['scenario']=='snapshot-gap':
   rs=first(i for i in range(1,len(cr)) if cr[i]['t']>=5 and cr[i]['accepted_snapshots']>cr[i-1]['accepted_snapshots'])
   pending=first(i for i,r in enumerate(cr) if r['t']>=5 and r['pending']<120)
   newseq=first(i for i,r in enumerate(cr) if r['t']>=5 and cap is not None and r['sequence']>cr[cap]['sequence'])
   ra=first(i for i in range(1,len(sr)) if sr[i]['t']>=5 and sr[i]['ack']>sr[i-1]['ack'])
   left=first(i for i,r in enumerate(sr) if r['t']>=6 and r['move_x']<-.1)
   reconstructed['snapshot_recovery']={'first_resumed_snapshot_counter':ref(cr,rs),'first_pending_below_cap':ref(cr,pending),'first_new_sequence_after_cap':ref(cr,newseq),'first_resumed_ack':ref(sr,ra),'first_leftward_authority_control':ref(sr,left),'peer_count_values_through_observation':sorted(set(r['peer_count'] for r in sr)),'limit':'eight-second trace; later 30-second healthy retention was not recorded'}
   caps=[i for i,r in enumerate(cr) if r['pending']>=120]
   seq=cr[cap]['sequence'];acap=first(i for i,r in enumerate(sr) if r['ack']>=seq);atcap=max(i for i,r in enumerate(sr) if r['t']<=cr[cap]['t'])
   rejectfirst=first(i for i,r in enumerate(sr) if r['rejected']>0)
   snap={'first_cap':ref(cr,cap),'last_cap':ref(cr,caps[-1]),'cap_row_count':len(caps),'cap_sequence_constant':len(set(cr[i]['sequence'] for i in caps))==1,'server_row_at_or_before_cap':ref(sr,atcap),'unacked_tail_at_sampled_cap':seq-sr[atcap]['ack'],'authority_reaches_cap_sequence':ref(sr,acap),'rejected_before_cap_sequence_ack':max(r['rejected'] for r in sr[:acap+1]),'first_rejection':ref(sr,rejectfirst),'accepted_snapshot_increments_inside_omission':sum(cr[i]['accepted_snapshots']>cr[i-1]['accepted_snapshots'] for i in range(1,len(cr)) if 1<=cr[i]['t']<5),'dropped_snapshot_delta_observation':cr[-1]['dropped_snapshots']-cr[0]['dropped_snapshots'],'recovery':reconstructed['snapshot_recovery'],'client_final':ref(cr,len(cr)-1),'authority_final':ref(sr,len(sr)-1),'healthy_observation_after_snapshot_resume_seconds':None if rs is None else cr[-1]['t']-cr[rs]['t']}
  timeline_diffs=difference(reconstructed,t)
  recomputed_capture={'scenario':spec['scenario'],'prediction':spec['prediction_requested'],'protocol':s['protocol'],'privacy_violations':c['privacy_violations'],'hit_history_frames':s['hit_history_frames'],'max_pending':c['max_pending'],'client_prediction':c['prediction'],'dropped_snapshots':c['dropped_snapshots'],'barrier_read_retries':{'server':s['barrier_read_retries'],'client':c['barrier_read_retries']},'first_history_cap_seconds':None if cap is None else cr[cap]['t'],'stale_window_displacement_m':travel['absolute_x_displacement_m'],'stale_window_max_speed_mps':travel['max_abs_vx_mps'],'last_ack_before_resume_seconds':None if anchor is None else sr[anchor]['t'],'stop_after_last_ack_seconds':silence['x_rest_wall_seconds_after_ack_anchor'],'recovery_min_speed_mps':min(abs(r['vx']) for r in sr if 7<=r['t']<=7.8),'recovery_largest_vx_mps':recover['largest_signed_vx_mps'],'shots_at_end':sr[-1]['shots'],'ammo_at_end':sr[-1]['ammo'],'rejected_packets':max(r['rejected'] for r in sr),'disconnected_at_seconds':s['disconnected_at'],**reconstructed['cleanup_reported']}
  capture_diffs=difference(recomputed_capture,{k:receipt[k] for k in recomputed_capture})
  cross.append({'sample':label,'case':cid,'timeline_differences':timeline_diffs,'capture_recomputation_differences':capture_diffs,'timeline_complete_field_comparison':True})
  real=spec['scenario'] in ['snapshot-gap','stale-replay']
  frozen_end=first(i for i in range((anchor or 0)+1,len(sr)) if sr[i]['ack']>sr[anchor]['ack']) if anchor is not None else None
  frozen_ids=[i for i in range((anchor or 0)+1,frozen_end or len(sr)) if sr[i]['peer_count']>0]
  livefrozen=[i for i in frozen_ids if sr[i]['peer_last_input_msec']!=sr[i-1]['peer_last_input_msec']]
  simfrozen=[i for i in frozen_ids if sr[i]['last_input']!=sr[i-1]['last_input']]
  nofalse_release=all(sr[i]['fire_held'] for i in range(clear, first(j for j,r in enumerate(sr) if r['t']>=5) or len(sr)) if sr[i]['peer_count']>0) if real and clear is not None else None
  speedstop=silence['x_rest_wall_seconds_after_ack_anchor']
  actions={'changes':events(sr,['fire_held','shots','ammo']),'ammo_plus_shots_always_15':all(r['ammo']+r['shots']==15 for r in sr),'shot_steps':[{'row_index':i,'t':sr[i]['t'],'delta':sr[i]['shots']-sr[i-1]['shots'],'fire_before':sr[i-1]['fire_held'],'fire_after':sr[i]['fire_held'],'ammo_delta':sr[i]['ammo']-sr[i-1]['ammo']} for i in range(1,len(sr)) if sr[i]['shots']!=sr[i-1]['shots']],'reported_shots_match_final':s['shots']==sr[-1]['shots'],'no_false_fire_release_while_neutral_and_bound_before_5':nofalse_release,'standard_two_shots_ammo_13':None if spec['scenario']=='stale-replay' else sr[-1]['shots']==2 and sr[-1]['ammo']==13}
  replay=None
  if spec['scenario']=='stale-replay':
   plateau=sr[anchor]['ack']; client_seq=set(r['sequence'] for r in cr if r['t']>=2.1)
   after=[r for r in sr[anchor:] if r['peer_count']>0]
   replay={'fully_acked_observed_max_sequence':plateau==max(r['sequence'] for r in cr),'authority_ack_plateau':plateau,'client_sequence_after_2_1':sorted(client_seq),'liveness_updates_after_ack_plateau':len(livefrozen),'simulation_activity_updates_after_ack_plateau':len(simfrozen),'wall_timestamp_plateau':len(livefrozen)==0,'binding_retired':unbound is not None,'retirement_observed_t':None if unbound is None else sr[unbound]['t'],'wall_retirement':wall,'cleanup_counts':reconstructed['cleanup_reported'],'displacement_after_ack_anchor_m':sr[-1]['x']-sr[anchor]['x'],'max_speed_after_ack_anchor_mps':max(abs(r['vx']) for r in after),'rejected_max':max(r['rejected'] for r in sr),'client_sequence_pending_post_freeze_values':sorted({(r['sequence'],r['pending']) for r in cr if r['t']>=2.1}),'accepted_snapshots_continue_after_2_1':cr[-1]['accepted_snapshots']-next(r for r in cr if r['t']>=2.1)['accepted_snapshots'],'first_unbound_client_counter_state':None if unbound is None else next((r for r in cr if r['t']>=sr[unbound]['t']),None),'payload_bytes_not_retained':True}
  physics_steps=[sr[i]['simulation_t']-sr[i-1]['simulation_t'] for i in range(1,len(sr))]
  residuals=[abs(sr[i]['x']-sr[i-1]['x']-sr[i]['vx']*physics_steps[i-1]) for i in range(1,len(sr))]
  clocks={role:{'relative_wall':series(rows,'t'),'repeated_wall_timestamp_row_indices':[i for i in range(1,len(rows)) if rows[i]['t']==rows[i-1]['t']],'maximum_callback_gap_seconds':max(rows[i]['t']-rows[i-1]['t'] for i in range(1,len(rows)))} for role,rows in [('server',sr),('client',cr)]}
  clientcmd=receipt['normalized_commands']['client'];servercmd=receipt['normalized_commands']['server']
  controls={'protocol_6_both_reports':s['protocol']==c['protocol']==6,'client_prediction_matches_requested':c['prediction']==spec['prediction_requested'],'client_prediction_flag_matches_requested':('--prediction' in clientcmd)==spec['prediction_requested'],'server_prediction_false':s['prediction'] is False,'privacy_violation_reports':[s['privacy_violations'],c['privacy_violations']],'active_hit_history_reports':[s['hit_history_frames'],c['hit_history_frames']],'client_pending_observed_max':max(r['pending'] for r in cr),'client_pending_reported_process_max':c['max_pending'],'reported_process_max_bounds_rows':c['max_pending']>=max(r['pending'] for r in cr),'rejected_observed_max':max(r['rejected'] for r in sr),'barrier_negative_control_reported':receipt['barrier_control'],'barrier_publish_retries':receipt['barrier_publish_retries'],'barrier_read_retries':receipt['barrier_read_retries'],'peer_exit_receipts':receipt['exits'],'controller_error_flags':receipt['native_errors'],'native_log_error_lines':{role:scan(text) for role,text in logs.items()},'completion_markers':{role:('INPUT_FRESHNESS_PROBE role='+role+' scenario='+spec['scenario']+' completed') in logs[role] for role in logs},'ready_markers':context['ready_files'],'command_ports_match':next(x for x in clientcmd if x.startswith('--port='))==next(x for x in servercmd if x.startswith('--port=')),'native_execution_authenticated':False}
  verdicts={'travel_window_below_0_001_m_and_mps':travel['absolute_x_displacement_m']<.001 and travel['max_abs_vx_mps']<.001,'simulation_silence_clear_policy':None if not real else clear is not None and .3<silence['simulation_silence_age_at_clear']<=.3+1/60+1e-10 and abs(silence['simulation_silence_age_before_clear']-.3)<1e-10,'ack_to_x_rest_below_350_ms':None if not real else speedstop is not None and 0<=speedstop<.350,'later_signed_authority_left_below_minus_0_9':None if spec['scenario']=='stale-replay' else recover['largest_signed_vx_mps']<-.9,'standard_shots_and_ammo_preserved':actions['standard_two_shots_ammo_13'],'replay_no_activity_extension_and_retirement':None if replay is None else replay['fully_acked_observed_max_sequence'] and replay['wall_timestamp_plateau'] and unbound is not None and 31.5<=sr[unbound]['t']<=32.5 and all(v==0 for v in replay['cleanup_counts'].values()),'snapshot_queued_tail_and_recovery_preserved':None if snap is None else snap['authority_reaches_cap_sequence'] is not None and snap['rejected_before_cap_sequence_ack']==0 and snap['cap_sequence_constant'] and all(r['peer_count']==1 for r in sr) and all(reconstructed['snapshot_recovery'][k] is not None for k in ['first_resumed_snapshot_counter','first_pending_below_cap','first_new_sequence_after_cap','first_resumed_ack','first_leftward_authority_control'])}
  result={'sample':label,'case':cid,**spec,'source_hashes':{name:sha((base/name).read_bytes()) for name in ['server.json','client.json','server.log','client.log','capture.json','timeline_index.json']},'raw_row_counts':{'server':len(sr),'client':len(cr)},'motion':{'travel':travel,'fresh_direction':recover,'simulation_step_min_max':[min(physics_steps),max(physics_steps)],'max_abs_x_integration_residual_m':max(residuals)},'silence':silence,'ack_plateau_interval':{'end_row_index':frozen_end,'wall_activity_update_count_while_bound':len(livefrozen),'simulation_activity_update_count_while_bound':len(simfrozen),'first_three_wall_updates':[ref(sr,i) for i in livefrozen[:3]]},'snapshot_gap':snap,'stale_replay':replay,'actions':actions,'controls':controls,'clocks':clocks,'row_counter_series':{'server':{key:series(sr,key) for key in ['ack','last_input','shots','rejected']},'client':{key:series(cr,key) for key in ['sequence','accepted_snapshots','dropped_snapshots','pending']}},'criteria':verdicts,'timeline_and_capture_match':not timeline_diffs and not capture_diffs}
  cases.append(result);all_cases.append(result)
 for g in sample['focused_gates']:
  text=(P/label/'gates'/g['log']).read_text(encoding='utf-8');h=sha((P/label/'gates'/g['log']).read_bytes())
  summaries=[{'checks':int(x),'failures':f} for x,f in re.findall(r'checks=(\d+)\s+failures=(\d+|\[.*?\])',text)]
  expected_denials=[line for line in text.splitlines() if line.startswith('PROTOCOL_CLIENT_FAILED ')]
  welcome=None
  for line in text.splitlines():
   if line.startswith('LOST_WELCOME_REVIEW '): welcome=json.loads(line[len('LOST_WELCOME_REVIEW '):])
  gate={'sample':label,'name':g['name'],'raw_log':text,'sha256':h,'receipt':g,'receipt_hash_matches':h==g['log_sha256'],'error_scan':scan(text),'summary_checks':summaries,'expected_credential_denials':expected_denials,'raw_pass_lines':[line for line in text.splitlines() if line.startswith('REVIEW_ALIAS PASS ')],'lost_welcome_record':welcome,'native_execution_authenticated':False}
  gate['recorded_checks_pass']=not gate['error_scan'] and all(v['failures'] in ['0','[]'] for v in summaries) and (bool(summaries) or welcome is not None and welcome['fixture_valid'] and welcome['final_state']=='connected' and welcome['restored_same_actor'] and not welcome['old_credential_still_valid'])
  gates.append(gate);all_gate_logs.append(gate);audit({'record_type':'focused_gate',**gate})
 sample_obj={'sample':label,'identity_unknown':True,'source_review_performed':False,'recorded_metadata':{k:v for k,v in sample.items() if k not in ['cases','focused_gates']},'cases':cases,'focused_gates':gates,'counts':{'cases':len(cases),'native_peer_processes_recorded':len(cases)*2,'focused_gate_processes_recorded':len(gates),'numeric_gate_checks_logged':sum(s['checks'] for g in gates for s in g['summary_checks']),'all_peer_rows':sum(sum(c['raw_row_counts'].values()) for c in cases)},'interpretation':'historical neutral data outcome only; no release approval or authenticated execution'}
 write(label+'-assessment.json',sample_obj);sample_objects.append(sample_obj)
raw.close()
write('crosschecks.json',{'numerical_absolute_tolerance':1e-10,'cases':cross,'all_match':all(not c['timeline_differences'] and not c['capture_recomputation_differences'] for c in cross)})
comparison={'schema':1,'assessment_scope':'blinded outcome critique before identity or implementation-source inspection','sample_labels':[s['sample'] for s in sample_objects],'completed_pairs':len(all_cases),'recorded_peer_processes':len(all_cases)*2,'recorded_focused_gates':len(all_gate_logs),'raw_rows':sum(sum(c['raw_row_counts'].values()) for c in all_cases),'manifest_payloads_verified':362,'zip_members_verified':363,'cases_with_timeline_or_summary_difference':[{'sample':c['sample'],'case':c['case']} for c in all_cases if not c['timeline_and_capture_match']],'case_criteria_counts':{s['sample']:{k:{'pass':sum(c['criteria'][k] is True for c in s['cases']),'fail':sum(c['criteria'][k] is False for c in s['cases']),'not_applicable':sum(c['criteria'][k] is None for c in s['cases'])} for k in s['cases'][0]['criteria']} for s in sample_objects},'retained_failure_index_entries':len(retention['entries']),'authenticity':'SHA256 binds supplied bytes, not authorship or native/OS execution; controller exit 0 not authenticated execution','all_human_device_protocol6_defaultoff_rewindoff_gates_remain':True}
write('comparison.json',comparison)
print(json.dumps(comparison,indent=2))
print('CROSSCHECK_DIFFERENCES',json.dumps([c for c in cross if c['timeline_differences'] or c['capture_recomputation_differences']],indent=2)[:12000])
print('AUDIT_DIRECTORY',OUT)