import pathlib,sys,json,hashlib,datetime,stat,collections,math
sys.stdout.reconfigure(encoding='utf-8')
BASE=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode')
ROOT=BASE/'sol-input-neutral-20261023T005129814690Z'
A=ROOT/'independent-audit';P=ROOT/'payload'
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
V=BASE/('sol-input-neutral-verdict-'+stamp)
V.mkdir(exist_ok=False)
def sha(data): return hashlib.sha256(data).hexdigest()
def load(path): return json.loads(path.read_bytes())
def save(name,obj): (V/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
(V/'finalize.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
for name in ['recompute.py','inventory.json','input-pins.json','failure-retention-index.json','crosschecks.json','raw-audit.jsonl']:
 (V/name).write_bytes((A/name).read_bytes())
for name in ['neutral-input-packet.zip','MANIFEST.json','discovery.py']:
 (V/name).write_bytes((ROOT/name).read_bytes())
gaps=[
 'Historical recorder evidence only: pinned bytes, logs, and awaited process receipts are not signed OS/native-execution attestation; controller exit 0 does not authenticate execution.',
 'No PCAP, datagram payload archive, send/receive timestamp list, ENet retransmission trace, or fixed replay batch bytes; no packet-by-packet replay/parser/privacy audit is possible.',
 'Server relative-clock origin start_msec is absent. Expiry is callback-bracketed around 30 seconds, not an exact millisecond-age boundary proof.',
 'Simulation silence policy is strict >0.3 simulation seconds, quantized at approximately 1/60 s. It is not a 300 ms observed-wall stop guarantee.',
 'Only x position/velocity and move_x are captured. No grounded flag, y/z motion, full-vector stop, rendered output, real device input, or human-feel measurements.',
 'Only two repeats for each deterministic application-impairment scenario and prediction mode, loopback, fixed run order and no randomized seed; no Internet-loss/reordering/jitter/distribution or statistical reliability claim.',
 'Variable pre-observation warmup lacks role spawn/ready/latch timestamps; controller durations and startup offsets are not comparable performance outcomes.',
 'Snapshot-gap traces end at eight seconds, only about 2.95-2.98 seconds after first accepted snapshot resumes. No post-recovery 30-second healthy-session retention soak.',
 'The 120-command history cap still stops fresh command production until ACK processing resumes; neutralization is safer than stale movement but does not recover intent during the gap.',
 'Replay client sequence and pending remain frozen after about 2 seconds even while accepted snapshot counters rise. This is not a normal fully processing healthy client or a duplicate-plus-continuing-fresh-intent mixed traffic test.',
 'Authority ACK equals the observed client maximum sequence in each replay, supporting fully-ACKed replay interpretation. Missing replay bytes prevent independent proof of the exact batch structure/contents.',
 'Queued-tail consumption and recovery are observed, with zero rejection before cap sequence ACK; this does not exhaustively prove retry preservation under loss, reorder, sequence jumps, malformed batches, or adversarial traffic.',
 'Higher valid sequences do not authenticate human presence; indefinite valid-sequence synthetic input and exhaustive adversarial sequence cases are not established.',
 'Fire latch, shot, ammo, release/press outcomes are captured. Jump/grenade/smoke/utility edges are not individually exposed in live rows; the three-check focused lifecycle log cannot alone prove all edge paths.',
 'Privacy reports zero violations and the focused test logs 55 checks, but raw snapshot payloads are unavailable. Absence of a measured leak is not an independent comprehensive privacy proof.',
 'Protocol 6, requested/default-off-mode prediction, and zero active hit-history frames match reports/receipts. Shipped configuration and implementation invariants were not inspected in this blinded outcome phase.',
 'Focused input-stream coverage counts differ (20 versus 17). No assertion-by-assertion equivalence or causal attribution can be established without later source review. Raw counts, other checks, and expected credential denials are retained.',
 'Seven prior unsuccessful/superseded attempt indices remain, including a native allocation crash before admission and a startup JSON/nil-access error. Their original detailed artifacts are outside this neutral packet; do not erase failures or infer an all-attempts success rate.',
 'Source-cleanliness and unchanged-identity receipts are retained claims, not independent custody/source-identity verification. No identity map or implementation/fixture source was semantically inspected.'
]
validation={'raw_audit_line_count':0,'row_count':0,'row_counts_by_sample_case_role':{},'case_context_count':0,'gate_count':0,'all_rows_equal_original_reports':True,'all_saved_deltas_recomputed':True}
expected={}
for label in ['sample-H','sample-T']:
 for i in range(1,17):
  for role in ['server','client']:
   expected[(label,f'case-{i:02}',role)]=load(P/label/f'case-{i:02}'/(role+'.json'))['rows']
lasts={}
with (V/'raw-audit.jsonl').open(encoding='utf-8') as f:
 for line in f:
  validation['raw_audit_line_count']+=1;rec=json.loads(line);kind=rec['record_type']
  if kind.endswith('_row'):
   role=kind[:-4];key=(rec['sample'],rec['case'],role);i=rec['row_index'];r=rec['actual'];assert r==expected[key][i]
   if i:
    prev=expected[key][i-1]
    assert all(math.isclose(value,r[k]-prev[k],rel_tol=0,abs_tol=1e-12) for k,value in rec['deltas_from_previous'].items())
   else: assert rec['deltas_from_previous'] is None
   assert i==lasts.get(key,-1)+1;lasts[key]=i
   if role=='server': assert abs(rec['simulation_silence_age_seconds']-(r['simulation_t']-r['last_input']))<1e-12
   validation['row_count']+=1
  elif kind=='case_context': validation['case_context_count']+=1
  elif kind=='focused_gate': validation['gate_count']+=1
for key,rows in expected.items():
 assert lasts[key]+1==len(rows)
 validation['row_counts_by_sample_case_role']['/'.join(key)]=len(rows)
assert validation['row_count']==55743 and validation['case_context_count']==32 and validation['gate_count']==22
save('audit-validation.json',validation)
objects=[]
for label in ['sample-H','sample-T']:
 obj=load(A/(label+'-assessment.json'))
 for c in obj['cases']:
  sr=expected[(label,c['case'],'server')];w=[r for r in sr if 3.8<=r['t']<=4.8]
  c['motion']['independent_path_checks']={'window_x_total_variation_m':sum(abs(b['x']-a['x']) for a,b in zip(w,w[1:])),'window_x_range_m':max(r['x'] for r in w)-min(r['x'] for r in w),'window_vx_integral_simulation_m':sum(b['vx']*(b['simulation_t']-a['simulation_t']) for a,b in zip(w,w[1:])),'window_all_zero_move_and_vx':all(r['move_x']==0 and r['vx']==0 for r in w)}
  if c['scenario']=='stale-replay':
   index=c['silence']['last_ack_anchor']['row_index'];rr=sr[index:]
   c['stale_replay']['x_total_variation_after_ack_anchor_m']=sum(abs(b['x']-a['x']) for a,b in zip(rr,rr[1:]))
 obj['neutral_verdict']={'rank':'observed_safety_outcome_winner' if label=='sample-H' else 'observed_stale_safety_failure','release_approval':False,'execution_authenticated':False,'full_safety_bar_established':False,'stale_control_cases_passed':sum(c['criteria']['simulation_silence_clear_policy'] is True for c in obj['cases']),'stale_control_cases_failed':sum(c['criteria']['simulation_silence_clear_policy'] is False for c in obj['cases']),'replay_retirement_cases_passed':sum(c['criteria']['replay_no_activity_extension_and_retirement'] is True for c in obj['cases']),'preservation_scope':'No measured regression in queued tail, snapshot/ACK recovery, fire edges, authority x movement, recorded privacy/protocol/prediction/rewind controls; broader invariants unproven.'}
 obj['coverage_gaps']=gaps
 obj['required_gates_remain']={'human_and_device_validation':True,'protocol_must_remain_6':True,'prediction_must_remain_default_off':True,'live_rewind_must_remain_off':True,'authority_privacy_and_retry_controls_must_not_be_sacrificed':True,'all_other_original_acceptance_gates':True}
 save(label+'-assessment.json',obj);objects.append(obj)
comp=load(A/'comparison.json')
comp.update({'neutral_winner':'sample-H','tie':False,'comparison_kind':'conditional historical measured safety-outcome advantage, not generic speed/latency/throughput or release approval','release_approval':False,'full_safety_bar_established':False,'execution_authenticated':False,'ties_on_observed_metrics':['healthy steady and short input-gap motion windows','snapshot/ACK/fresh-direction recovery within eight-second observation','standard two fire shots and ammo 15 to 13','recorded privacy/protocol/default-off-mode prediction/live-rewind counters','shared focused lifecycle/authority/privacy/welcome/alias checks, subject to incomplete log detail'],'coverage_gaps':gaps,'all_source_identities_unknown':True,'source_and_mapping_review_deferred_until_after_this_freeze':True})
save('comparison.json',comp)
report=r'''# Independent blinded neutral-input outcome verdict

## Outcome and scope

**sample-H is the observed safety-outcome winner over sample-T. This is not release approval, authenticated native execution, or a general network-performance claim.** Both sample identities remain unknown. The complete safety bar is not established by this packet: the measured stale-input improvements are strong within the recorded fixture, while human/device, real-network, comprehensive protocol/authority/privacy and longer-session coverage remain open.

I read only the two explicitly permitted Git blobs from commit `0cbc3ae7a9a017aa179eaeff61cf902629de1c0d`, exporting bytes with Python `subprocess` and `git show` into a new isolated directory. No branch/parent files, identity map, source identities, neighboring files, or implementation/fixture-source contents were inspected. No packet-supplied code was executed. The only execution was small serial offline analysis under the exact approved CPython 3.13.15 executable; no native engine, database, network or services were used, and the repository/index were not edited.

The supplied external pins match:

- ZIP: `8fb111324051b4bfc590a216ab09c107ef0c10605f755b7e481757d125172112`
- Manifest: `fe83c4bdcc1ea662f034ff4ebc340a4e115ed27e8a7d404a2aa80175d84146ce`

All **362 listed payloads** match their byte lengths and SHA256 values. The ZIP has exactly **363 regular members**: those payloads plus the byte-identical manifest, totaling 15,749,223 uncompressed bytes. Inventory checks reject traversal/absolute/Windows-unsafe names, case collisions, duplicates, symlinks/nonregular entries and encryption. ZIP CRC reads and extracted-byte comparisons pass. No omitted or extra member was found.

I independently processed **all 55,743 actual peer rows**, all 64 peer native logs, 32 capture receipts/barriers/ready records, and all 22 focused gate logs/receipts. The per-sample row totals are 27,874 and 27,869. Full row values and independently computed deltas/ages are preserved in `raw-audit.jsonl`, not merely selected excerpts. Reconstructed motion windows, every ACK/control/liveness/snapshot change reference, silence/retirement/recovery structures and capture summary calculations agree across all 32 cases (absolute numerical tolerance 1e-10). This is internal consistency, not independent truth/authentication of the historical recorder.

## Primary matched outcomes

Each scenario has prediction off/on and two repeats: four cases per sample. Travel uses inclusive authority callbacks at 3.8-4.8 s, not an invented exact one-second wire interval. Both endpoint displacement and cumulative absolute x movement were recomputed; speed and move controls were inspected throughout, preventing a zero-net-displacement false pass.

| Observed test | sample-H | sample-T |
| --- | --- | --- |
| Snapshot-gap stale travel, four cases | 0 m, 0 m/s | 1.003009-1.020009 m at about 1.02 m/s |
| Replay stale travel, four cases | 0 m, 0 m/s | 1.003009-1.020010 m at about 1.02 m/s |
| Actual silence control-clear opportunities | 8/8 clear at about 0.316667 simulation s of accepted-input age | 0/8 clear before t=5; stale controls persist |
| ACK-anchor to sampled x-axis rest, actual stale cases | 315-336 ms, 8/8 below the separately declared 350 ms gate | No rest before t=5, 0/8 |
| Fully-ACKed observed fixed-sequence replay extends activity | No, 0 subsequent liveness updates after final ACK in all four | Yes, 941-959 subsequent liveness updates despite fixed final ACK |
| Replay binding retirement and four cleanup counts zero | 4/4, observed t=32.057-32.072 s | 0/4; still bound and moving through about 34 s, counts 1/1/1/0 |
| Steady/short-input-gap travel controls | 8/8 stationary in requested travel window | 8/8 stationary in requested travel window |
| Standard-case later authority direction and fire/ammo | 12/12 leftward vx about -1.02; 2 shots, ammo 13 | Same 12/12 |

The eight steady/short-input-gap travel passes are controls, **not eight additional demonstrations of silence neutralization**. The input callback omission is only 200 ms and does not by itself exercise the >0.3 s silence threshold.

### Exact per-case stale timing

All times below are sampled relative wall seconds except the stated simulation age. Prediction describes the client mode. H's observed clear age is about 0.316667 simulation s in every row; the preceding moving row is about 0.300000 s. T has no corresponding clear/rest before 5 s.

| Case | Scenario | Prediction | H final pre-resume ACK t | H first move_x=0 t | H ACK-to-rest ms | H replay retirement t |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| case-05 | snapshot-gap | off | 2.949 | 3.249 | 332 | n/a |
| case-06 | snapshot-gap | on | 2.945 | 3.227 | 315 | n/a |
| case-13 | snapshot-gap | off | 2.964 | 3.264 | 331 | n/a |
| case-14 | snapshot-gap | on | 2.960 | 3.243 | 316 | n/a |
| case-07 | stale-replay | off | 2.057 | 2.357 | 335 | 32.060 |
| case-08 | stale-replay | on | 2.067 | 2.367 | 333 | 32.072 |
| case-15 | stale-replay | off | 2.077 | 2.360 | 318 | 32.061 |
| case-16 | stale-replay | on | 2.056 | 2.356 | 336 | 32.057 |

For an auditable example, H/case-05 server rows 193-196 have control/speed pairs `(+0.2,1.02)`, `(0,0.553333)`, `(0,0.086667)`, `(0,0)`. Thus control neutralization is not an instantaneous physical stop. Rest follows the first cleared row by about 0.033333 simulation s; the entire ACK-to-rest delay is not the simulation silence deadline. The last-input age is computed from **simulation_t minus last_input**, not from the ACK wall timestamp. Serialized floating-point values around 0.300000 can differ by roughly 1e-15; they do not justify sub-frame boundary claims.

### Replay/lifecycle interpretation

In every replay case, the authority ACK reaches the observed client's maximum generated sequence (H 174/175/175/174; T 175/164/173/174 in case order 07/08/15/16), then remains fixed. The raw client sequence remains fixed too. H's accepted-input simulation timestamp and wall lifecycle timestamp stop renewing; rejected counters continue increasing and binding is eventually removed. T repeatedly refreshes both timestamps while ACK and command sequence remain fixed, keeps move_x about +0.2 and vx about +1.02, and remains bound. After the ACK anchor, H accumulates only about 0.283-0.300 m of x travel before rest, versus T's 32.589-32.606 m through the retained end.

H/case-07, for example, last changes liveness at row 123/t=2.057, remains bound at row 1921/t=32.039, and is unbound at row 1922/t=32.060. The independently recomputed inactivity sampling brackets across the four H replays span **29.982-30.023 s**, consistent with a 30 s expiry. They do **not** prove an exact 30,000 ms boundary: server `start_msec` was not retained, so subtracting `t*1000` from absolute `peer_last_input_msec` would be invalid. Binding retirement is not a claim that the actor was destroyed; only the four reported peer/lifecycle/queue/pending-join tables are shown empty.

The fixed batch's bytes were not captured. “Fully ACKed replay” is supported by the observed max-sequence/ACK plateau and configured replay, not by an independent payload/parser audit. H's rejection counts are **900 per replay**; T reports zero. These counters are not silently dropped or equated with fresh-input failure.

## Preservation and counter-controls

### Legitimate queued/unACKed tail and ACK recovery

All eight snapshot-gap cases reach the 120-command history cap. H first reaches it at 2.884-2.902 s; T at 2.881-2.947 s. Production remains frozen until snapshots/ACK handling resumes around 5 s: this unresolved loss of fresh intent must remain in any improvement claim.

At the sampled H cap callbacks, authority still trails the frozen cap sequence by 3-5 commands. It subsequently reaches sequence 228 in all four cases with **zero recorded rejections through that ACK**, then rejects later redundant traffic. This supports preservation of the real queued/unACKed tail rather than indiscriminate duplicate dropping. It does not prove exhaustive loss/reordering retry correctness without packet data.

H resumes accepted snapshots at 5.018-5.043 s, pending drops from 120 to 1, sequence advances to 229, and authority ACK resumes at 5.049-5.075 s. T also recovers (snapshots at 5.032-5.063 s; ACKs at 5.050-5.109 s). Both remain peer-bound throughout these eight-second observations and later apply actual signed leftward authority movement. Every standard case's 7.0-7.8 s authority window has largest vx about -1.02 m/s, not just an unsigned “recovered speed” boolean. Only about 2.95-2.98 s of post-snapshot-recovery client observation exists, **not a later thirty-second healthy-session soak**.

Rejection counter controls are important: H's four snapshot cases report **62,63,62,63**, its four replay cases **900 each**, and its eight healthy controls **0**. T reports **0 in all sixteen cases**. In H the snapshot rejections begin after the authority reaches the cap sequence; recovery still succeeds. Rejection totals cannot be turned into exact UDP replay packet counts because callbacks can aggregate events.

### Action edges and authority

All twelve standard cases per sample finish with two shots and ammo 15 to 13. Every authority row satisfies `ammo + shots == 15`; shot increments align with fire-held rising transitions, and genuine release followed by press yields the second shot. H's stale-control clear keeps fire_held true through silence; no silence-induced second shot appears. Replay has one shot/ammo 14; the configured client replay does not process the later release/press schedule, so that missing second shot is **not** an edge regression. On H's eventual retirement, the latch can clear as part of retirement, not as a false silent release while bound.

The focused lifecycle log for both samples records `steady_held_shots=1 gap_held_shots=1 gap_rejected=0` and the epoch counter control `accepted=200 ack=200 client_sequence=200 pending=0 first_sequence=200 last_sequence=200`, with 3 checks and 0 failures. Additional jump/utility latch outcomes are not individually exposed by the raw live captures or these summary lines; no comprehensive edge-preservation proof is claimed.

All server ACK traces are nondecreasing. X displacement is internally consistent with per-step server vx integration to maximum residual below 1.8e-6 m across all cases. This supports authoritative x-motion consistency, not authentication of the server or full movement/collision correctness.

### Protocol/privacy/default prediction/live rewind

All 64 peer reports record protocol **6**, zero privacy violations and zero active hit-history frames. For all sixteen prediction-off client cases the launch receipt omits `--prediction` and the raw client report is false; the on cases explicitly request and report true. These modes must not be traded away for the stale-input improvement. The privacy counter and focused 55-check privacy test are corroborating historical observations, not packet-by-packet privacy re-audit: no raw snapshot payloads were retained. Zero active history frames is the measured live-rewind control, not authorization to enable rewind. No implementation or shipped-default source was reviewed in this blinded phase.

### Focused gates and failures retained

There are 11 focused gate process receipts per sample, all with recorded exit 0, matching log hashes and no unexpected native-error scan hits. Numerical checks logged per sample are 1,699 for H and 1,696 for T, plus the structured lost-welcome record. Input-stream checks differ **20 versus 17**; shared logged counts are lifecycle 3, peer lifecycle 16, reconnect 21, snapshot buffer 15, movement prediction 725 (maximum_error_m=0.075834), privacy 55, actor lifecycle 183, hit history 638 and resume alias 23. Counts are not equal assertion coverage or proof that each hidden assertion is sound.

The alias logs retain all 23 PASS lines, including lost-welcome recovery, bounded previous-credential lifetime, no eviction of an unconfirmed live owner, and old-alias invalidation on first accepted input. Two terminal `PROTOCOL_CLIENT_FAILED` lines are expected credential-denial controls, not discarded errors. The separate lost-welcome JSON records the same actor restored, old client credential retained, old credential no longer valid, connected final state and valid suppression fixture; its stated scope is one native process with ENet/application delivery suppression.

The completed comparison's peer native logs have completion markers and no unexpected error lines. That is **not an all-attempts clean-run claim**. All seven failure-retention indices are preserved verbatim, including dirty preflights, an earlier startup JSON/nil-access error, and an allocation crash before first admission. The detailed original failure artifacts are not in this neutral packet and were not inspected. They remain unresolved selection/robustness limitations, not erased trials.

## Limitations and remaining gates

- This is historical, unsigned recorder output. External hashes establish byte identity; controller exit 0, readiness strings, native banners and clean-source receipts do not authenticate actual execution. No new native run was authorized or performed.
- Only two repeats per deterministic scenario/mode on loopback, no randomized impairment seed and no true wire-loss/reorder/ENet trace. Fixed sample/run order and variable warmup prevent general latency, CPU, startup or total-runtime speed comparisons.
- Source role spawn/ready/latch timestamps and exact wall-clock origin are missing. Repeated millisecond wall timestamps occur in replay/on client traces (one row in H, eight in T); maximum callback gaps reach 75 ms server/64 ms client in H and 109/137 ms in T. Physics steps remain about 1/60 simulation s. Nominal rates are not actual datagram timestamps.
- Replay counters show accepted snapshots continuing while client sequence and pending remain frozen. This is not a normal client fully maintaining ACK history, a post-replay fresh recovery test, or mixed redundant-plus-continuing-fresh-input traffic. Higher valid sequences also do not prove human presence.
- No grounded flag, y/z position/velocity, real device/rendered behavior, full-vector stop or individually logged jump/utility edge outcomes. Privacy payloads and exact replay bytes are absent.
- Source identities, implementation invariants, source cleanliness and actual process custody cannot be resolved in this blinded phase. Shared source/provenance contents were deliberately not inspected. None of these gaps are filled by equal-looking log hashes or summary booleans.

**All original human/device acceptance gates remain. Protocol must remain 6; prediction must remain default off; live rewind must remain off; authority/privacy/retry/edge safeguards must remain.** The only supported comparative conclusion is sample-H's substantially better measured stale-input safety with the listed observed preservation controls. Broader release approval is withheld.

## Frozen record

`sample-H-assessment.json` and `sample-T-assessment.json` contain individual case criteria, exact row references, all control/gate counters and neutral verdicts. `comparison.json` retains every failure/not-applicable status and the coverage gaps. `raw-audit.jsonl` contains every actual peer row and focused log plus independently recomputed deltas. `crosschecks.json`, `audit-validation.json`, `inventory.json`, input pins, failure index, original neutral ZIP/manifest and executed analysis scripts provide the audit trail. `SHA256SUMS.txt` covers these payloads; `FROZEN.json` binds that ledger and the explicit UTC freeze record. Its separate checksum is the external freeze handle, not a cryptographic signature or trusted timestamp attestation.
'''
(V/'REPORT.md').write_text(report,encoding='utf-8',newline='\n')
process={'read_boundary':'Only the two explicitly approved frozen Git blobs and their neutral archive payloads; no adjacent repository/parent/branch/source/mapping inspection. Code-like payloads were only byte-hashed, not semantically inspected or executed.','extraction_directory':str(ROOT),'approved_python':r'C:\Users\blith\AppData\Local\Temp\opencode\sightbreak-tools\python\cpython-3.13.15-windows-x86_64-none\python.exe','python_version':sys.version,'native_network_database_services_used':False,'repository_and_index_modified':False,'git_operations':['git show 0cbc3ae7a9a017aa179eaeff61cf902629de1c0d:docs/reports/network-input-freshness-v3/blind/neutral-input-packet.zip','git show 0cbc3ae7a9a017aa179eaeff61cf902629de1c0d:docs/reports/network-input-freshness-v3/blind/MANIFEST.json'],'assessor_local_failure_retained':[{'stage':'first extraction/inventory/read console','error':'UnicodeEncodeError cp1252 on U+2212 in CLOCKS_AND_LIMITS.md printing','effect':'All inventory checks and isolated extraction had succeeded before console print failure. No native execution failure or source-data modification. Subsequent serial reads configured UTF-8 stdout.'}],'semantic_source_mapping_provenance_review_performed':False,'packet_code_executed':False,'new_native_execution_performed':False,'freeze_before_any_source_or_identity_mapping':True,'release_approval':False}
save('review-process.json',process)
assert load(V/'crosschecks.json')['all_match']
assert all(c['timeline_and_capture_match'] for s in objects for c in s['cases'])
assert all(g['recorded_checks_pass'] and g['receipt_hash_matches'] for s in objects for g in s['focused_gates'])
assert all(all(c['controls']['completion_markers'].values()) and all(v==0 for v in c['controls']['peer_exit_receipts'].values()) and not any(c['controls']['native_log_error_lines'].values()) for s in objects for c in s['cases'])
assert sha((V/'neutral-input-packet.zip').read_bytes())=='8fb111324051b4bfc590a216ab09c107ef0c10605f755b7e481757d125172112'
assert sha((V/'MANIFEST.json').read_bytes())=='fe83c4bdcc1ea662f034ff4ebc340a4e115ed27e8a7d404a2aa80175d84146ce'
frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
(V/'FROZEN_UTC.txt').write_text(frozen_utc+'\n',encoding='ascii')
payloads=sorted((p for p in V.iterdir() if p.is_file()),key=lambda p:p.name)
ledger_entries=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in payloads]
(V/'SHA256SUMS.txt').write_text(''.join(e['sha256']+'  '+e['path']+'\n' for e in ledger_entries),encoding='utf-8',newline='\n')
frozen={'schema':1,'frozen_utc':frozen_utc,'freeze_directory':str(V),'neutral_winner':'sample-H','tie':False,'source_identity_unknown':True,'source_and_mapping_not_reviewed':True,'release_approval':False,'native_execution_authenticated':False,'manifest_payloads_verified':362,'zip_members_verified':363,'matched_pairs':32,'historical_peer_process_receipts':64,'focused_gate_receipts':22,'actual_peer_rows_recomputed':55743,'ledger_file':'SHA256SUMS.txt','ledger_sha256':sha((V/'SHA256SUMS.txt').read_bytes()),'ledger_payload_count':len(ledger_entries),'ledger_entries':ledger_entries,'hash_chain_note':'SHA256SUMS covers all frozen payloads before the ledger/FROZEN/checksum files. FROZEN binds the ledger and its inventory. FROZEN.sha256 provides the non-self-referential freeze checksum. This is not signed attestation or trusted time.'}
save('FROZEN.json',frozen)
frozen_hash=sha((V/'FROZEN.json').read_bytes())
(V/'FROZEN.sha256').write_text(frozen_hash+'  FROZEN.json\n',encoding='ascii')
for p in V.iterdir():
 if p.is_file(): p.chmod(stat.S_IREAD)
for entry in ledger_entries:
 b=(V/entry['path']).read_bytes();assert len(b)==entry['bytes'] and sha(b)==entry['sha256']
assert sha((V/'FROZEN.json').read_bytes())==frozen_hash
assert sha((V/'SHA256SUMS.txt').read_bytes())==frozen['ledger_sha256']
print(json.dumps({'neutral_winner':'sample-H','tie':False,'release_approval':False,'frozen_path':str(V),'frozen_utc':frozen_utc,'FROZEN_json_sha256':frozen_hash,'SHA256SUMS_sha256':frozen['ledger_sha256'],'REPORT_sha256':sha((V/'REPORT.md').read_bytes()),'all_ledger_entries_verified_after_readonly_freeze':True,'frozen_file_count':len(list(V.iterdir())),'raw_audit_lines':validation['raw_audit_line_count']},indent=2))