import pathlib,sys,json,hashlib,itertools,datetime
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z')
(OUT/'13-bounded-mixed-newline-check.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
b=(OUT/'production/H_executed/game/scripts/network/input_stream.gd').read_bytes();lines=b.splitlines(keepends=True);assert all(x.endswith(b'\n') and b'\r' not in x for x in lines)
expected=json.loads((OUT/'original-counterparts/candidate-r2/summary.json').read_bytes())['source_before']['input_stream_sha256'];trials=0;matches=[]
def check(data,profile):
 global trials
 trials+=1
 if hashlib.sha256(data).hexdigest()==expected:
  matches.append(profile);(OUT/'H-measured-input-newline-reproduction.gd').write_bytes(data)
N=len(lines)
for polarity in ['CRLF_outside_LF_inside','LF_outside_CRLF_inside']:
 for start in range(N):
  for end in range(start,N):
   data=b''.join((line if start<=i<=end else line.replace(b'\n',b'\r\n')) if polarity.startswith('CRLF_outside') else (line.replace(b'\n',b'\r\n') if start<=i<=end else line) for i,line in enumerate(lines))
   check(data,{'kind':'single contiguous newline-style interval','polarity':polarity,'inclusive_line_range':[start+1,end+1]})
   if matches:break
  if matches:break
 if matches:break
if not matches:
 for bits in itertools.product([False,True],repeat=8):
  data=b''.join((line.replace(b'\n',b'\r\n') if (bits[i-33] if 33<=i<=40 else True) else line) for i,line in enumerate(lines))
  check(data,{'kind':'independent newline choices around guard','line_range':[34,41],'CRLF_choices':list(bits),'outside':'CRLF'})
result={'recorded_hash':expected,'canonical_git_sha256':hashlib.sha256(b).hexdigest(),'bounded_profiles_tested':trials,'exact_matching_profiles':matches,'status':'Exact newline-only representation reproduced' if matches else 'UNRESOLVED after bounded standard/mixed profiles. This does not prove no arbitrary newline-only representation exists; original measured working-file bytes or producer explanation required.','finished_utc_local':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'H-mixed-newline-investigation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))