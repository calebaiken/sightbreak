import pathlib,sys,json,hashlib,difflib
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z')
(OUT/'12-source-hash-profiles-and-receipt-shape.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
proof=json.loads((OUT/'production-source-binding.json').read_bytes());print('PRODUCTION_TREES',json.dumps(proof['roles'],indent=2),'H_TO_RUNTIME_GAME_DIFF',proof['H_runtime_to_executed_game_changes_only'])
results=[]
for role,run in [('H_executed','candidate-r2'),('T_executed','baseline-r3')]:
 b=(OUT/'production'/role/'game/scripts/network/input_stream.gd').read_bytes();expected=json.loads((OUT/'original-counterparts'/run/'summary.json').read_bytes())['source_before']['input_stream_sha256'];lines=b.splitlines(keepends=True)
 variants={'git_LF':b,'all_CRLF':b.replace(b'\n',b'\r\n'),'all_CRCRLF':b.replace(b'\n',b'\r\r\n')}
 for label,raw in list(variants.items()):
  for bom,prefix in [('no_BOM',b''),('UTF8_BOM',b'\xef\xbb\xbf')]:
   for suffix,tail in [('same',b''),('extra_LF',b'\n'),('extra_CRLF',b'\r\n')]:variants[label+'/'+bom+'/'+suffix]=prefix+raw+tail
  variants[label+'/without_final_newline']=raw.rstrip(b'\r\n')
 if role=='H_executed':
  variants['base_CRLF_inserted_guard_LF']=b''.join(line if 35<=i<=40 else line.replace(b'\n',b'\r\n') for i,line in enumerate(lines,1))
  variants['base_LF_inserted_guard_CRLF']=b''.join(line.replace(b'\n',b'\r\n') if 35<=i<=40 else line for i,line in enumerate(lines,1))
 matches=[k for k,v in variants.items() if hashlib.sha256(v).hexdigest()==expected]
 item={'role':role,'recorded_per_run_input_stream_sha256':expected,'canonical_git_sha256':hashlib.sha256(b).hexdigest(),'all_CRLF_sha256':hashlib.sha256(b.replace(b'\n',b'\r\n')).hexdigest(),'candidate_profiles_tested':len(variants),'matching_profiles':matches,'status':'matched exact enumerated representation' if matches else 'UNRESOLVED; these tested profiles do not explain the per-run hash. Arbitrary mixed newline patterns/other representations not exhaustively ruled out.','profiles':[{'name':k,'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in variants.items()]};results.append(item)
(OUT/'measured-input-hash-discrepancy.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
for r in results:print('PER_RUN_SOURCE_HASH',json.dumps({k:v for k,v in r.items() if k!='profiles'},indent=2))
for name in ['baseline-r3-receipt.json','matched-run-r2-receipt.json']:
 obj=json.loads((OUT/'original-counterparts'/name).read_bytes());print('CONTROLLER_RECEIPT',name,json.dumps(obj,indent=2))