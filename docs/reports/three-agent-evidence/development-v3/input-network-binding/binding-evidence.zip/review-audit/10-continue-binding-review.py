import pathlib,sys,subprocess,re
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z')
(OUT/'10-continue-binding-review.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
source=(OUT/'08-bind-neutral-and-production.py').read_text(encoding='utf-8')
source=source.replace("(OUT/'08-bind-neutral-and-production.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')","(OUT/'11-bind-neutral-and-production-with-limits.py').write_text(pathlib.Path(__file__).read_text(encoding='utf-8'),encoding='utf-8')")
old="assert item['sha256_exact_LF_to_CRLF']==recorded;item['recorded_run_disk_hash']=recorded;item['exact_CRLF_reproduction_of_run_hash']=True"
new="item['recorded_run_disk_hash']=recorded;item['exact_CRLF_reproduction_of_run_hash']=item['sha256_exact_LF_to_CRLF']==recorded;item['exact_LF_reproduction_of_run_hash']=item['sha256_LF']==recorded;item['measured_run_hash_binding_status']='exact' if recorded in [item['sha256_LF'],item['sha256_exact_LF_to_CRLF']] else 'UNRESOLVED: committed LF/global CRLF do not reproduce recorded per-run hash'"
assert old in source;source=source.replace(old,new)
source=source.replace("'source_disk_hash_limit':'Run identity directly measured input_stream hash only; nine additional recorded source-artifact disk digests are exporter snapshot commitments, not individual per-process loaded-byte attestations. CRLF transformation reproduces recorded bytes; source status before/after remains unsigned author/controller evidence.'","'source_disk_hash_limit':'Run identity directly measured input_stream hash only; nine additional recorded source-artifact disk digests are exporter snapshot commitments, not individual per-process loaded-byte attestations. Do not conflate their verified LF-to-CRLF digests with separate currently-unresolved per-run input_stream hashes. Source status before/after remains unsigned author/controller evidence.'")
p=OUT/'11-bind-neutral-and-production-with-limits.py';p.write_text(source,encoding='utf-8')
subprocess.run([sys.executable,'-I',str(p)],check=True)