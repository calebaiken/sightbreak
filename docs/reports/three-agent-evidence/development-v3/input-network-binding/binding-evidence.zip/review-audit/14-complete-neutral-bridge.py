import pathlib,sys,json,subprocess
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z')
(OUT/'14-complete-neutral-bridge.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
old=(OUT/'production-source-binding.json').read_bytes();(OUT/'production-source-binding.pre-reconciliation.json').write_bytes(old);proof=json.loads(old)
mixed=json.loads((OUT/'H-mixed-newline-investigation.json').read_bytes());assert mixed['exact_matching_profiles'][0]['inclusive_line_range']==[33,41]
for item in proof['production_modules_and_config']:
 if item['path'].endswith('/input_stream.gd') and item['role'].startswith('H'):
  item['measured_run_hash_binding_status']='exact mixed-newline reproduction; LF lines33-41, CRLF elsewhere'
  item['exact_mixed_newline_reproduction_of_run_hash']=True
  item['reproduction_recipe']={'canonical_line_numbering':True,'LF_lines_inclusive':[33,41],'all_other_line_endings':'CRLF','reproduced_bytes':3547,'reproduced_sha256':mixed['recorded_hash']}
proof['source_disk_hash_limit']='All recorded source digests now reproduce exactly: nine exporter source-artifact digests via uniform LF->CRLF; H run InputStream via LF lines33-41/CRLF elsewhere; T run InputStream uniform CRLF. These are byte-representation reconciliations of unsigned author/controller commitments, not authentication of actually loaded process/cache bytes.'
(OUT/'production-source-binding.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
b=(OUT/'production/T_executed/game/scripts/network/input_stream.gd').read_bytes();(OUT/'T-measured-input-CRLF-reproduction.gd').write_bytes(b.replace(b'\n',b'\r\n'))
source=(OUT/'11-bind-neutral-and-production-with-limits.py').read_text(encoding='utf-8');tail=source[source.index('def norm(cmd):'):]
oldline="receipts=receipt_r2+(receipt_b if isinstance(receipt_b,list) else [receipt_b])"
newline="receipts=receipt_r2+[dict(item,name='baseline-r3') if 'name' not in item else item for item in (receipt_b if isinstance(receipt_b,list) else [receipt_b])]"
assert oldline in tail;tail=tail.replace(oldline,newline)
preamble="""import pathlib,sys,json,hashlib,zipfile,collections
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\\Users\\blith\\AppData\\Local\\Temp\\opencode\\sol-input-network-sourcebinding-20261024T090142760702Z')
OLD=pathlib.Path(r'C:\\Users\\blith\\AppData\\Local\\Temp\\opencode\\sol-input-neutral-verdict-20261023T010348965361Z')
M=json.loads((OUT/'released/mapping.json').read_bytes())
ids={v['origin_id']:(k,v) for k,v in M['original_counterparts'].items()}
proof=json.loads((OUT/'production-source-binding.json').read_bytes());trees=proof['roles'];delta=proof['H_runtime_to_executed_game_changes_only']
def sha(b):return hashlib.sha256(b).hexdigest()
"""
file=OUT/'15-neutral-bridge-only.py';file.write_text(preamble+tail,encoding='utf-8')
subprocess.run([sys.executable,'-I',str(file)],check=True)