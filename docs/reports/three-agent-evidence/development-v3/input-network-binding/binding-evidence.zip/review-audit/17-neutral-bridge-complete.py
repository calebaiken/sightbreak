import pathlib,sys,json,hashlib,zipfile,collections
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z')
OLD=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-neutral-verdict-20261023T010348965361Z')
M=json.loads((OUT/'released/mapping.json').read_bytes())
ids={v['origin_id']:(k,v) for k,v in M['original_counterparts'].items()}
proof=json.loads((OUT/'production-source-binding.json').read_bytes());trees=proof['roles'];delta=proof['H_runtime_to_executed_game_changes_only']
def sha(b):return hashlib.sha256(b).hexdigest()
def norm(cmd):
 out=list(cmd);out[0]='<GODOT_EXECUTABLE>'
 for flag,replacement in [('--path','<MEASURED_PROJECT>'),('--script','<NATIVE_SCRIPT>')]:
  if flag in out:out[out.index(flag)+1]=replacement
 return ['--output=<ROLE_REPORT>' if x.startswith('--output=') else '--barrier=<PAIR_BARRIER>' if x.startswith('--barrier=') else x for x in out]
records=[];counts=collections.Counter();used=set();gate_checks=[];sample_checks=[]
with zipfile.ZipFile(OLD/'neutral-input-packet.zip') as z:
 manifest=json.loads(z.read('MANIFEST.json'));assert len(manifest['files'])==362
 infos=z.infolist();assert len(infos)==363;seen=set()
 for info in infos:
  name=info.filename;p=pathlib.PurePosixPath(name);assert not info.is_dir() and not p.is_absolute() and '..' not in p.parts and chr(92) not in name and name not in seen;seen.add(name);b=z.read(info)
  if name=='MANIFEST.json':assert b==(OLD/'MANIFEST.json').read_bytes()
  else:assert len(b)==manifest['files'][name]['bytes'] and sha(b)==manifest['files'][name]['sha256']
 prov=json.loads(z.read('provenance.json'))['artifacts'];assert len(prov)==354
 cross=json.loads((OLD/'crosschecks.json').read_bytes());assert cross['all_match'] and len(cross['cases'])==32
 for name,record in prov.items():
  b=z.read(name);assert sha(b)==record['exported_sha256'];origin_ids=record['original_counterpart_ids'];used.update(origin_ids);kind=record['transformation'];r={'neutral_path':name,'bytes':len(b),'sha256':sha(b),'original_counterpart_ids':origin_ids,'declared_transformation':kind}
  if kind.startswith('byte-for-byte'):
   assert len(origin_ids)==1;origin_name,rec=ids[origin_ids[0]];original=(OUT/'original-counterparts'/origin_name).read_bytes();assert b==original;r['original_name']=origin_name;r['status']='independent exact counterpart bytes';counts['direct_raw_exact']+=1
  elif name.endswith('/capture.json'):
   original=json.loads((OUT/'original-counterparts'/ids[origin_ids[0]][0]).read_bytes());neutral=json.loads(b);removed=set(original)-set(neutral)-{'commands'};assert removed<={'transport_authority_privacy_pass','recovery_and_edges_pass','improvement_gate'}
   assert set(neutral)-set(original)=={'normalized_commands'} and all(neutral[k]==v for k,v in original.items() if k not in removed|{'commands'})
   assert neutral['normalized_commands']=={role:norm(cmd) for role,cmd in original['commands'].items()}
   expected={k:v for k,v in original.items() if k not in removed|{'commands'}};expected['normalized_commands']={role:norm(cmd) for role,cmd in original['commands'].items()};assert (json.dumps(expected,indent=2)+'\n').encode()==b
   r['status']='independent exact JSON reserialization and command redaction';r['removed_policy_fields']=sorted(removed);counts['capture_redactions_exact']+=1
  elif name.endswith('/timeline_index.json'):
   pair='/'.join(name.split('/')[:2]);assert any(c['sample']+'/'+c['case']==pair and not c['timeline_differences'] and not c['capture_recomputation_differences'] for c in cross['cases'])
   assert origin_ids[0]==prov[pair+'/server.json']['original_counterpart_ids'][0] and origin_ids[1]==prov[pair+'/client.json']['original_counterpart_ids'][0] and origin_ids[2]==prov[pair+'/capture.json']['original_counterpart_ids'][0]
   r['status']='derived index bound to exact raw counterparts and immutable original independent all-field recomputation';counts['timeline_indexes_bound']+=1
  elif origin_ids[0].startswith('S'):
   sid=origin_ids[0];source=M['source_artifacts'][sid];canonical=(OUT/'source-artifacts'/sid/source['repository_path']).read_bytes()
   if source['excerpt_ranges']:
    lines=canonical.decode('utf-8').splitlines();expected=''
    for lo,hi in source['excerpt_ranges']:expected+='\n# Original source lines '+str(lo)+'–'+str(hi)+'\n'+'\n'.join(lines[lo-1:hi])+'\n'
    assert b==expected.encode();r['status']='exact selected line bytes/range headers from canonical source';counts['source_excerpts_exact']+=1
   else:assert b==canonical;r['status']='exact canonical committed source bytes';counts['canonical_sources_exact']+=1
  elif name=='run_manifest.json':r['status']='selected structured controller receipts, identity withheld; independently linked below';counts['run_manifest_linked']+=1
  else:raise ValueError((name,kind))
  records.append(r)
 nm=json.loads(z.read('run_manifest.json'));resume=json.loads((OUT/'original-counterparts/resume-gates/summary.json').read_bytes());receipt_r2=json.loads((OUT/'original-counterparts/matched-run-r2-receipt.json').read_bytes());receipt_b=json.loads((OUT/'original-counterparts/baseline-r3-receipt.json').read_bytes());receipts=receipt_r2+[dict(item,name='baseline-r3') if 'name' not in item else item for item in (receipt_b if isinstance(receipt_b,list) else [receipt_b])]
 for sample in nm['samples']:
  label=sample['sample'];meta=M['samples'][label];summary=json.loads((OUT/'original-counterparts'/meta['run']/'summary.json').read_bytes());controller=next(r for r in receipts if r['name']==meta['run'])
  assert sample['controller_receipt']=={k:controller[k] for k in ['started_epoch','duration_seconds','exit']}
  assert sample['source_before_status']==summary['source_before']['status']=='' and sample['source_after_status']==summary['source_after']['status']=='' and sample['source_unchanged']==summary['source_unchanged'] is True
  assert sample['source_identity_fields_equal_before_after'] == (summary['source_before']==summary['source_after'])
  env=sample['recorded_environment'];assert all(env[k]==summary[k] for k in ['platform','python','godot_sha256','driver_sha256','probe_sha256']) and sample['harness_status']==summary['harness_status']=='' and sample['import']==summary['import']
  assert len(summary['trials'])==len(sample['cases'])==16
  for spec,trial in zip(sample['cases'],summary['trials']):
   nmetrics=json.loads(z.read(label+'/'+spec['case']+'/capture.json'));assert all(nmetrics[k]==v for k,v in trial['metrics'].items() if k in nmetrics);assert spec['scenario']==trial['metrics']['scenario'] and spec['prediction_requested']==trial['metrics']['prediction'] and spec['repeat']==int(trial['directory'].split('-')[0])
  for g in sample['focused_gates']:
   if g['name'] in ['independent_resume_alias_test','lost_welcome_test']:original=next(q for q in resume['checks'] if q['source']==meta['resume_label'] and q['name']==g['name'])
   else:original=next(q for q in summary['checks'] if q['log']==g['log'])
   assert all(g[k]==original[k] for k in ['exit','seconds','log_sha256']);assert g['normalized_command']==norm(original['command']) and g['logged_errors']==original.get('logged_errors',original.get('native_errors')) is False
   gate_checks.append({'sample':label,'gate':g['name'],'original_exit':original['exit'],'duration_and_log_hash_exact':True,'normalized_command_exact':True})
  assert resume['sources'][meta['resume_label']]['before']==resume['sources'][meta['resume_label']]['after'] and resume['sources'][meta['resume_label']]['before']['commit']==meta['commit']
  sample_checks.append({'sample':label,'mapped_run':meta['run'],'executed_commit':meta['commit'],'source_before_after_equal_recorded':True,'recorded_game_tree_verified':trees['H_executed' if label=='sample-H' else 'T_executed']['game_tree'],'cases':16,'controller_receipt_exact':True,'controller_argv':controller['command'],'controller_exit':controller['exit'],'author_recorded_expect_fixed':summary['expect_fixed'],'import_cache_scope':summary['import']})
 admin=sorted(set(manifest['files'])-set(prov));assert len(admin)==8
 for name in admin:records.append({'neutral_path':name,'bytes':len(z.read(name)),'sha256':sha(z.read(name)),'status':'new pinned administrative/descriptive/export-verifier artifact; no raw counterpart identity claimed'})
 retain=json.loads(z.read('failure_retention_index.json'))['entries'];retention_checks=[]
 for item in retain:
  inv=M['retention_indices'][item['id']]['inventory'];encoding=json.loads((OUT/'retention-canonical-encoding.json').read_bytes())[item['id']]
  assert len(inv)==item['retained_file_count']
  retention_checks.append({'id':item['id'],'file_count':len(inv),'inventory_hash_exact':bool(encoding['digest_profiles_matching']),'canonical_encoding':encoding['digest_profiles_matching'],'original_contents_checked_in_this_binding':False,'git_reference_prefix':M['published_evidence_commit']+':docs/reports/network-input-freshness-v3-evidence/','limit':'If no digest profile matched, the exact released inventory remains pinned but its neutral canonical-hash serialization is not independently reconstructed.'})
assert len(records)==362 and len(gate_checks)==22
result={'neutral_payloads_verified':362,'safe_zip_members':363,'artifact_binding_counts':dict(counts),'new_admin_artifacts':admin,'all_payload_records':records,'sample_controller_bindings':sample_checks,'focused_gate_receipt_bindings':gate_checks,'retained_failure_inventory_bindings':retention_checks,'unused_original_counterpart_ids':sorted(set(ids)-used),'unexplained_payload_transform_mismatches':[],'limits':'New administrative artifacts verified against frozen manifest, not claimed original execution records. 32 timeline indexes use already-frozen independent recomputation, not a new native run. Retention369 content blobs not reread; exact inventories/commit refs preserved.'}
(OUT/'neutral-source-bridge.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('PRODUCTION_TREE_BINDING',json.dumps(trees,indent=2),'H_TO_RUNTIME_GAME_DIFF',delta)
print('BRIDGE_COUNTS',json.dumps(counts),'ADMIN',admin,'RETENTION_INVENTORY_CHECKS',len(retention_checks),'CONTROLLER_BINDS',len(sample_checks),'GATE_BINDS',len(gate_checks),'UNUSED_ORIGIN_IDS',result['unused_original_counterpart_ids'])