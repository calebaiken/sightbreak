import pathlib,sys,json,hashlib,subprocess,datetime,time
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z');REPO=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sightbreak-v3')
(OUT/'06-resolve-release-references.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
M=json.loads((OUT/'released/mapping.json').read_bytes());EVID=M['published_evidence_commit'];commands=json.loads((OUT/'actual-git-commands.json').read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
requests=[];cache={};argv=['git','-C',str(REPO),'cat-file','--batch'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.perf_counter();proc=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def obj(spec):
 if spec in cache:return cache[spec]
 assert '\n' not in spec and '\r' not in spec
 rec={'git_spec':spec};requests.append(rec);proc.stdin.write((spec+'\n').encode());proc.stdin.flush();header=proc.stdout.readline();parts=header.rstrip(b'\n').split(b' ')
 if len(parts)!=3 or parts[1]!=b'blob':rec['error_header']=header.decode(errors='replace');raise RuntimeError(rec)
 oid,kind,size=parts;size=int(size);b=proc.stdout.read(size);assert len(b)==size and proc.stdout.read(1)==b'\n';calc=hashlib.sha1(b'blob '+str(size).encode()+b'\0'+b).hexdigest();assert calc==oid.decode();rec.update({'git_blob':calc,'bytes':size,'sha256':sha(b)});cache[spec]=(b,rec);return b,rec
counter=[];sources=[]
try:
 for name,rec in M['original_counterparts'].items():
  b,proof=obj(EVID+':'+rec['repository_path']);assert len(b)==rec['bytes'] and sha(b)==rec['sha256'],name
  dest=OUT/'original-counterparts'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  counter.append({'origin_name':name,'origin_id':rec['origin_id'],'git_reference_released_by_a78':proof,'recorded_sha_and_size_match':True})
 for sid,rec in M['source_artifacts'].items():
  b,proof=obj(rec['commit']+':'+rec['repository_path']);assert proof['git_blob']==rec['git_blob_oid'] and proof['sha256']==rec['git_blob_sha256']
  if rec['also_identical_at']:other,op=obj(rec['also_identical_at']+':'+rec['repository_path']);assert other==b
  else:op=None
  assert b'\r' not in b;crlf=b.replace(b'\n',b'\r\n');exact=sha(b)==rec['disk_sha256'];converted=sha(crlf)==rec['disk_sha256'];assert exact or converted,(sid,'unexplained measured disk hash')
  assert exact==rec['disk_exact_equal'] and rec['newline_normalized_equal'] is True
  dest=OUT/'source-artifacts'/sid/rec['repository_path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  sources.append({'id':sid,**proof,'also_identical_at_proof':op,'recorded_disk_sha256':rec['disk_sha256'],'recorded_disk_matches_git_exactly':exact,'recorded_disk_matches_exact_LF_to_CRLF':converted and not exact,'LF_count':b.count(b'\n'),'CR_count_git':0,'git_bytes':len(b),'reproduced_disk_bytes':len(b) if exact else len(crlf),'transformation':'none' if exact else 'replace every LF byte0A with CRLF bytes0D0A, no other changes'})
finally:
 proc.stdin.close();stderr=proc.stderr.read();code=proc.wait();commands.append({'argv':argv,'started_utc_local':start,'elapsed_seconds':time.perf_counter()-t,'exit':code,'request_count':len(requests),'requests_receipt_file':'git-object-batch-receipts.json','stdin_sha256':sha(''.join(r['git_spec']+'\n' for r in requests).encode()),'stderr':stderr.decode(errors='replace'),'scope':'Exact evidence/source objects named by released a78 mapping; no checkout/ref/index modification.'});(OUT/'actual-git-commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf-8');(OUT/'git-object-batch-receipts.json').write_text(json.dumps(requests,indent=2)+'\n',encoding='utf-8')
assert code==0 and len(counter)==316 and len(sources)==11
verification={'mapping_sha256':'1d5b1cbed67c7fb94c2afe72c64b52b44c1b0915720cd0ddbc21151833709709','release_commit':'a78a0dc927fc32de33614ff5339e15750b04aa2b','counterpart_evidence_commit':EVID,'locator_limit':'a78 releases key/verification references; first attempted original path absent there. Counterparts independently resolved at exact1627 evidence commit named by released mapping, not misrepresented as blobs present under a78.','counterparts':counter,'source_artifacts':sources,'all_counterparts_exact':True,'source_exact':sum(s['recorded_disk_matches_git_exactly'] for s in sources),'source_newline_only':sum(s['recorded_disk_matches_exact_LF_to_CRLF'] for s in sources),'unexplained_byte_mismatches':[]}
(OUT/'counterpart-verification.json').write_text(json.dumps(verification,indent=2)+'\n',encoding='utf-8')
print('VERIFIED',len(counter),'COUNTERPART_BYTES',sum(c['git_reference_released_by_a78']['bytes'] for c in counter),'SOURCE_EXACT',verification['source_exact'],'SOURCE_LF_TO_CRLF',verification['source_newline_only'])
for name in ['candidate-r2/summary.json','baseline-r3/summary.json','matched-run-r2-receipt.json','matched-run-r3-baseline-receipt.json','resume-gates/summary.json']:
 p=OUT/'original-counterparts'/name
 if not p.is_file():continue
 r=json.loads(p.read_bytes());print('ORIGINAL_SCHEMA',name,list(r))
 for k,v in r.items():
  if k in ['trials','tests','gates','results','native_gates','focused_gates']:
   print(k,'TYPE',type(v).__name__,'COUNT',len(v),'EXAMPLE',json.dumps(v[:1] if isinstance(v,list) else dict(list(v.items())[:1]),indent=2)[:2500])
  elif isinstance(v,(str,int,float,bool)) or v is None:print(k,json.dumps(v))
  else:print(k,json.dumps(v,indent=2)[:6500])