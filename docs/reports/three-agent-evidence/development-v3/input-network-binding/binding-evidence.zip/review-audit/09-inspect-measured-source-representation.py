import pathlib,sys,json,hashlib
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z')
(OUT/'09-inspect-measured-source-representation.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
p=OUT/'production/H_executed/game/scripts/network/input_stream.gd';b=p.read_bytes();expected=json.loads((OUT/'original-counterparts/candidate-r2/summary.json').read_bytes())['source_before']['input_stream_sha256']
variants={'git_exact':b,'LF_to_CRLF':b.replace(b'\n',b'\r\n'),'CRLF_to_LF':b.replace(b'\r\n',b'\n'),'LF_to_CRCRLF':b.replace(b'\n',b'\r\r\n')}
print('MEASURED_INPUT_SOURCE',json.dumps({'path':str(p),'bytes':len(b),'LF':b.count(b'\n'),'CR':b.count(b'\r'),'expected':expected,'variants':{k:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest(),'matches':hashlib.sha256(v).hexdigest()==expected} for k,v in variants.items()}},indent=2))
print('SOURCE_TEXT','\n'+b.decode('utf-8'))