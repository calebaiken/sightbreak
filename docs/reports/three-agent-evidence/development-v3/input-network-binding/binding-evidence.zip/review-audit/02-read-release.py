import pathlib,sys,json,hashlib,subprocess,datetime,time
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z')
REPO=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sightbreak-v3');COMMIT='a78a0dc927fc32de33614ff5339e15750b04aa2b'
(OUT/'02-read-release.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
commands=json.loads((OUT/'actual-git-commands.json').read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):
 argv=['git','-C',str(REPO),*args];start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.perf_counter();p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 commands.append({'argv':argv,'started_utc_local':start,'elapsed_seconds':time.perf_counter()-t,'exit':p.returncode,'stdout_bytes':len(p.stdout),'stdout_sha256':sha(p.stdout),'stderr':p.stderr.decode('utf-8',errors='replace')});(OUT/'actual-git-commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf-8')
 if p.returncode:raise RuntimeError(commands[-1])
 return p.stdout
for name in ['.gitattributes','README.md','mapping.json','release-verification.json','sha256.json']:
 rel='docs/reports/network-input-review-release/'+name;b=git('show',COMMIT+':'+rel);p=OUT/'released'/name;p.parent.mkdir(exist_ok=True);p.write_bytes(b)
 print('RELEASED_FILE',name,len(b),sha(b))
 if name=='mapping.json':assert len(b)==212748 and sha(b)=='1d5b1cbed67c7fb94c2afe72c64b52b44c1b0915720cd0ddbc21151833709709'
 if name.endswith('.md') or name=='sha256.json':print(b.decode('utf-8'))
 elif name.endswith('.json'):
  obj=json.loads(b)
  print('TOP_KEYS',list(obj))
  for k,v in obj.items():
   if isinstance(v,list):print(k,'LIST',len(v),json.dumps(v[:2],indent=2)[:14000])
   elif isinstance(v,dict):print(k,'DICT',len(v),json.dumps(v,indent=2)[:18000])
   else:print(k,json.dumps(v))