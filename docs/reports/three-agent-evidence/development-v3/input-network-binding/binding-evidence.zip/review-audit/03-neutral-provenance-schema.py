import pathlib,sys,json,zipfile,hashlib
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z')
OLD=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-neutral-verdict-20261023T010348965361Z')
(OUT/'03-neutral-provenance-schema.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
with zipfile.ZipFile(OLD/'neutral-input-packet.zip') as z:
 for name in ['provenance.json','shared/source_context.json','run_manifest.json']:
  obj=json.loads(z.read(name));print('SCHEMA',name,list(obj))
  for k,v in obj.items():
   if isinstance(v,list):print(k,'LIST',len(v),'FIRST',json.dumps(v[:2],indent=2)[:11000])
   elif isinstance(v,dict):print(k,'DICT',len(v),'FIRST',json.dumps(dict(list(v.items())[:3]),indent=2)[:11000])
   else:print(k,json.dumps(v)[:3000])
 for name in ['README.md','shared/controller_excerpt.txt']:
  print('TEXT',name,'\n'+z.read(name).decode('utf-8')[:18000])
print('RELEASE_README','\n'+(OUT/'released/README.md').read_text(encoding='utf-8'))