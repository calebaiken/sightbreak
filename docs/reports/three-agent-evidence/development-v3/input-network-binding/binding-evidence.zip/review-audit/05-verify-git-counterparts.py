import pathlib,sys,json,hashlib,subprocess,datetime,time,zipfile,collections
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z');REPO=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sightbreak-v3')
(OUT/'05-verify-git-counterparts.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
M=json.loads((OUT/'released/mapping.json').read_bytes());A78='a78a0dc927fc32de33614ff5339e15750b04aa2b';EVID=M['published_evidence_commit']
assert M['samples']['sample-H']['commit']=='77f204083ab5bea4dc9149d3179daf540a994de4' and M['samples']['sample-T']['commit']=='701ce2c4d7f8b2872cf1fefa64cb6edd0cd1a3fd' and M['runtime_commit']=='f3ceaad98e089aa393c7f5fa650a52695094d979'
commands=json.loads((OUT/'actual-git-commands.json').read_bytes());requests=[];responses={}
def sha(b):return hashlib.sha256(b).hexdigest()
argv=['git','-C',str(REPO),'cat-file','--batch'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.perf_counter();proc=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def obj(spec):
 if spec in responses:return responses[spec]
 assert '\n' not in spec and '\r' not in spec
 proc.stdin.write((spec+'\n').encode());proc.stdin.flush();header=proc.stdout.readline();words=header.rstrip(b'\n').split(b' ')
 if len(words)!=3 or words[1]!=b'blob':raise RuntimeError(('expected blob',spec,header.decode(errors='replace')))
 oid,kind,size=words;size=int(size);b=proc.stdout.read(size);assert len(b)==size and proc.stdout.read(1)==b'\n'
 calc=hashlib.sha1(b'blob '+str(size).encode()+b'\0'+b).hexdigest();assert calc==oid.decode()
 rec={'git_spec':spec,'git_blob':calc,'bytes':size,'sha256':sha(b)};requests.append(rec);responses[spec]=(b,rec);return b,rec
counter=[];source=[]
try:
 for name,rec in M['original_counterparts'].items():
  b,a=obj(A78+':'+rec['repository_path']);old,e=obj(EVID+':'+rec['repository_path'])
  assert b==old and len(b)==rec['bytes'] and sha(b)==rec['sha256'],name
  dest=OUT/'original-counterparts'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  counter.append({'origin_name':name,'origin_id':rec['origin_id'],'released_commit_check':a,'original_evidence_commit_check':e,'recorded_sha_match':True,'both_git_commits_exact_equal':True})
 for sid,rec in M['source_artifacts'].items():
  b,proof=obj(rec['commit']+':'+rec['repository_path']);assert proof['git_blob']==rec['git_blob_oid'] and proof['sha256']==rec['git_blob_sha256']
  if rec['also_identical_at']:
   other,op=obj(rec['also_identical_at']+':'+rec['repository_path']);assert other==b
  else:op=None
  assert b'\r' not in b
  crlf=b.replace(b'\n',b'\r\n');exact=sha(b)==rec['disk_sha256'];converted=sha(crlf)==rec['disk_sha256']
  assert exact or converted,(sid,'unexplained measured disk hash')
  assert exact==rec['disk_exact_equal'] and rec['newline_normalized_equal'] is True
  dest=OUT/'source-artifacts'/sid/rec['repository_path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  source.append({'id':sid,**proof,'also_identical_at_proof':op,'recorded_disk_sha256':rec['disk_sha256'],'recorded_disk_matches_git_exactly':exact,'recorded_disk_matches_exact_LF_to_CRLF':converted and not exact,'LF_count':b.count(b'\n'),'CR_count_git':b.count(b'\r'),'git_bytes':len(b),'reproduced_disk_bytes':len(b) if exact else len(crlf),'transformation':'none' if exact else 'replace each LF byte 0A with CRLF 0D0A; no other byte change'})
finally:
 proc.stdin.close();stderr=proc.stderr.read();code=proc.wait();commands.append({'argv':argv,'started_utc_local':start,'elapsed_seconds':time.perf_counter()-t,'exit':code,'request_count':len(requests),'requests_receipt_file':'git-object-batch-receipts.json','stdin_sha256':sha(''.join(r['git_spec']+'\n' for r in requests).encode()),'stderr':stderr.decode(errors='replace'),'scope':'Exact release/evidence counterparts and specified source objects only; no checkout/ref/index modification.'});(OUT/'actual-git-commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf-8');(OUT/'git-object-batch-receipts.json').write_text(json.dumps(requests,indent=2)+'\n',encoding='utf-8')
assert code==0 and len(counter)==316 and len(source)==11
(OUT/'counterpart-verification.json').write_text(json.dumps({'mapping_pin_verified':True,'release_commit':A78,'evidence_commit':EVID,'counterparts':counter,'source_artifacts':source,'all_counterparts_exact':True,'source_exact':sum(s['recorded_disk_matches_git_exactly'] for s in source),'source_newline_only':sum(s['recorded_disk_matches_exact_LF_to_CRLF'] for s in source),'unexplained_mismatches':[]},indent=2)+'\n',encoding='utf-8')
print('GIT_COUNTERPARTS_VERIFIED',len(counter),'SOURCE_EXACT',sum(s['recorded_disk_matches_git_exactly'] for s in source),'SOURCE_CRLF_ONLY',sum(s['recorded_disk_matches_exact_LF_to_CRLF'] for s in source),'ALL_FROM_A78_AND_EVIDENCE_EQUAL',True)
for name in ['candidate-r2/summary.json','baseline-r3/summary.json','matched-run-r2-receipt.json','matched-run-r3-baseline-receipt.json','resume-gates/summary.json']:
 path=OUT/'original-counterparts'/name
 if not path.is_file():continue
 r=json.loads(path.read_bytes());print('ORIGINAL_SCHEMA',name,list(r))
 for k,v in r.items():
  if k in ['trials','tests','gates','results','native_gates','focused_gates','scenarios']:
   print(k,'TYPE',type(v).__name__,'COUNT',len(v),'EXAMPLE',json.dumps(v[:1] if isinstance(v,list) else dict(list(v.items())[:1]),indent=2)[:5500])
  elif isinstance(v,(str,int,float,bool)) or v is None:print(k,json.dumps(v))
  else:print(k,json.dumps(v,indent=2)[:10000])