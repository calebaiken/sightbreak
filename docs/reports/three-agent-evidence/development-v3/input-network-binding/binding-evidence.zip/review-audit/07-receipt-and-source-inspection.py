import pathlib,sys,json,zipfile,collections
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z');OLD=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-neutral-verdict-20261023T010348965361Z')
(OUT/'07-receipt-and-source-inspection.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
M=json.loads((OUT/'released/mapping.json').read_bytes());ids={v['origin_id']:(k,v) for k,v in M['original_counterparts'].items()}
with zipfile.ZipFile(OLD/'neutral-input-packet.zip') as z:
 prov=json.loads(z.read('provenance.json'))['artifacts']
 for name in ['sample-H/case-05/capture.json','sample-T/case-07/capture.json','run_manifest.json']:
  print('NEUTRAL_BINDING',name,prov[name]['original_counterpart_ids'])
  if '/capture' in name:
   original=json.loads((OUT/'original-counterparts'/ids[prov[name]['original_counterpart_ids'][0]][0]).read_bytes());neutral=json.loads(z.read(name))
   print('ORIGINAL_ONLY_FIELDS',json.dumps({k:v for k,v in original.items() if k not in neutral},indent=2)[:8000]);print('NEUTRAL_ONLY_FIELDS',sorted(set(neutral)-set(original)))
 for name in ['provenance.json','failure_retention_index.json']:
  if name.startswith('failure'):print('RETENTION_NEUTRAL',json.dumps(json.loads(z.read(name)),indent=2)[:5000])
for name in ['matched-run-r3-baseline-receipt.json','resume-gates/summary.json']:
 p=OUT/'original-counterparts'/name
 if p.is_file():print('RECEIPT',name,p.read_text(encoding='utf-8')[:14000])
print('COUNTERPART_RECEIPT_NAMES',[k for k in M['original_counterparts'] if k.endswith('receipt.json')])
for sid in ['S001','S002','S006']:
 rec=M['source_artifacts'][sid];p=OUT/'source-artifacts'/sid/rec['repository_path'];lines=p.read_text(encoding='utf-8').splitlines()
 print('SOURCE',sid,rec['repository_path'],'LINES',len(lines))
 for i,line in enumerate(lines,1):print(f'{i}: {line}')
match=(OUT/'source-artifacts/S003/game/scripts/gameplay/match.gd').read_text(encoding='utf-8').splitlines()
for term in ['func _service_peers','func _retire_peer','func _neutral','func _remove_peer','func _peer_disconnected']:
 for i,line in enumerate(match):
  if line.startswith(term):
   end=next((j for j in range(i+1,len(match)) if match[j].startswith('func ') or match[j].startswith('@rpc')),min(i+100,len(match)))
   print('MATCH_FUNCTION',term,'\n'+'\n'.join(f'{j+1}: {match[j]}' for j in range(i,end)))