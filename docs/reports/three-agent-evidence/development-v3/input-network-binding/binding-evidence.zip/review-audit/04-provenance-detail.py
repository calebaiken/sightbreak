import pathlib,sys,json,zipfile,collections
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z')
OLD=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-neutral-verdict-20261023T010348965361Z')
(OUT/'04-provenance-detail.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
with zipfile.ZipFile(OLD/'neutral-input-packet.zip') as z:
 p=json.loads(z.read('provenance.json'));groups=collections.defaultdict(list)
 for name,item in p['artifacts'].items():groups[item['transformation']].append((name,item))
 print('PROVENANCE_GROUPS',json.dumps({k:len(v) for k,v in groups.items()},indent=2))
 for k,v in groups.items():print('TRANSFORM_EXAMPLES',k,json.dumps(v[:3],indent=2)[:7000])
 print('NO_PROVENANCE',sorted(set(json.loads(z.read('MANIFEST.json'))['files'])-set(p['artifacts'])))
 print('RUN_MANIFEST_KEYS',list(json.loads(z.read('run_manifest.json'))))
 for name in ['shared/controller_excerpt.txt','shared/authority_context.txt','shared/history_context.txt']:
  print('TEXT',name,'\n'+z.read(name).decode('utf-8'))
print('RELEASE_README','\n'+(OUT/'released/README.md').read_text(encoding='utf-8'))