import pathlib,sys,json,hashlib,datetime,subprocess,time
sys.stdout.reconfigure(encoding='utf-8')
BASE=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode')
REPO=BASE/'sightbreak-v3';OLD=BASE/'sol-input-neutral-verdict-20261023T010348965361Z'
OUT=BASE/('sol-input-network-sourcebinding-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));OUT.mkdir(exist_ok=False)
(OUT/'01-intake-and-release-list.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
def sha(data):return hashlib.sha256(data).hexdigest()
def streamsha(path):
 d=hashlib.sha256();n=0
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):d.update(b);n+=len(b)
 return n,d.hexdigest()
pins={'FROZEN.json':'e944002cdd8980f5e3f75d24efdc62b1041458b1a2a52138672a2e9a5c6671a0','SHA256SUMS.txt':'ae0aee6f6e5019f18490ab5162501bcc7a85fd9ddbce5c552444d9183872031d','REPORT.md':'9ed4a4e61f16612067978db54ad584a201315e0935328b5b39f2746231124bdc','neutral-input-packet.zip':'8fb111324051b4bfc590a216ab09c107ef0c10605f755b7e481757d125172112','MANIFEST.json':'fe83c4bdcc1ea662f034ff4ebc340a4e115ed27e8a7d404a2aa80175d84146ce'}
verified=[]
for name,h in pins.items():
 n,actual=streamsha(OLD/name);assert actual==h,(name,actual);verified.append({'path':name,'bytes':n,'sha256':actual})
entries=[]
for line in (OLD/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
 h,rel=line.split('  ',1);p=pathlib.PurePosixPath(rel);assert not p.is_absolute() and '..' not in p.parts
 n,actual=streamsha(OLD.joinpath(*p.parts));assert actual==h,rel;entries.append({'path':rel,'bytes':n,'sha256':actual})
oldreceipt={'verified_utc_local':datetime.datetime.now(datetime.timezone.utc).isoformat(),'origin':str(OLD),'pins':verified,'all_original_ledger_payloads_verified':len(entries),'ledger_entries':entries,'freeze_not_modified_or_rejudged':True,'scope':'Network freeze only; previous separate component publication not opened/modified for this binding.'}
(OUT/'old-neutral-freeze-rehash.json').write_text(json.dumps(oldreceipt,indent=2)+'\n',encoding='utf-8')
commands=[]
def git(*args,allow_failure=False):
 argv=['git','-C',str(REPO),*args];started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.perf_counter();p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 rec={'argv':argv,'started_utc_local':started,'elapsed_seconds':time.perf_counter()-t,'exit':p.returncode,'stdout_bytes':len(p.stdout),'stdout_sha256':sha(p.stdout),'stderr':p.stderr.decode('utf-8',errors='replace')};commands.append(rec)
 (OUT/'actual-git-commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf-8')
 if p.returncode and not allow_failure:raise RuntimeError(rec)
 return p
commit='a78a0dc927fc32de33614ff5339e15750b04aa2b';p=git('cat-file','-t',commit,allow_failure=True)
if p.returncode:
 git('-c','pack.threads=1','-c','gc.auto=0','-c','fetch.writeCommitGraph=false','fetch','--no-tags','--no-write-fetch-head','--no-recurse-submodules','--no-auto-maintenance','origin',commit)
 p=git('cat-file','-t',commit)
assert p.stdout.strip()==b'commit'
listing=git('ls-tree','-r','-l',commit,'--','docs/reports/network-input-review-release').stdout.decode()
(OUT/'release-tree.txt').write_text(listing,encoding='utf-8')
print('NEW_EXTERNAL_ROOT',OUT)
print('OLD_NEUTRAL_FREEZE_REHASH',json.dumps({'pinned_files':verified,'all_ledger_payloads':len(entries),'total_ledger_payload_bytes':sum(e['bytes'] for e in entries)},indent=2))
print('RELEASE_TREE',listing)
for rel in ['AGENTS.md','docs/AGENTS.md','docs/reports/AGENTS.md','docs/reports/three-agent-evidence/AGENTS.md','docs/reports/three-agent-evidence/development-v3/AGENTS.md']:
 p=REPO/rel
 if p.is_file():print('APPLICABLE_ROUTER',rel,'\n'+p.read_text(encoding='utf-8'))