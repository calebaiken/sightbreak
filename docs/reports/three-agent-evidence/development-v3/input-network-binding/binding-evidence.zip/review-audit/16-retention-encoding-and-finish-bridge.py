import pathlib,sys,json,hashlib,zipfile,subprocess
sys.stdout.reconfigure(encoding='utf-8')
OUT=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-network-sourcebinding-20261024T090142760702Z');OLD=pathlib.Path(r'C:\Users\blith\AppData\Local\Temp\opencode\sol-input-neutral-verdict-20261023T010348965361Z')
(OUT/'16-retention-encoding-and-finish-bridge.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1],encoding='utf-8')
M=json.loads((OUT/'released/mapping.json').read_bytes())
with zipfile.ZipFile(OLD/'neutral-input-packet.zip') as z:items=json.loads(z.read('failure_retention_index.json'))['entries']
found={}
for item in items:
 record=M['retention_indices'][item['id']];inv=record['inventory'];variants={'fullpaths':inv,'folder_relative':{k.split('/',1)[1]:v for k,v in inv.items()},'sorted_values':[inv[k] for k in sorted(inv)],'rows':[{'path':k,**v} for k,v in sorted(inv.items())]};matches=[]
 for kind,v in variants.items():
  for sort in [False,True]:
   for indent in [None,2]:
    for compact in [False,True]:
     kwargs={'sort_keys':sort,'indent':indent}
     if compact:kwargs['separators']=(',',':')
     for nl in ['', '\n']:
      b=(json.dumps(v,**kwargs)+nl).encode()
      if hashlib.sha256(b).hexdigest()==item['canonical_inventory_sha256']:matches.append({'paths':kind,**kwargs,'final_newline':bool(nl)})
 found[item['id']]={'file_count':len(inv),'claimed_count':item['retained_file_count'],'digest_profiles_matching':matches,'digest':item['canonical_inventory_sha256']}
 assert len(inv)==item['retained_file_count']
 print('RETENTION_ENCODING',item['id'],json.dumps(found[item['id']]))
(OUT/'retention-canonical-encoding.json').write_text(json.dumps(found,indent=2)+'\n',encoding='utf-8')
source=(OUT/'15-neutral-bridge-only.py').read_text(encoding='utf-8')
start=source.index(' for item in retain:');end=source.index("assert len(records)==362",start)
replacement=""" for item in retain:
  inv=M['retention_indices'][item['id']]['inventory'];encoding=json.loads((OUT/'retention-canonical-encoding.json').read_bytes())[item['id']]
  assert len(inv)==item['retained_file_count']
  retention_checks.append({'id':item['id'],'file_count':len(inv),'inventory_hash_exact':bool(encoding['digest_profiles_matching']),'canonical_encoding':encoding['digest_profiles_matching'],'original_contents_checked_in_this_binding':False,'git_reference_prefix':M['published_evidence_commit']+':docs/reports/network-input-freshness-v3-evidence/','limit':'If no digest profile matched, the exact released inventory remains pinned but its neutral canonical-hash serialization is not independently reconstructed.'})
"""
source=source[:start]+replacement+source[end:]
p=OUT/'17-neutral-bridge-complete.py';p.write_text(source,encoding='utf-8');subprocess.run([sys.executable,'-I',str(p)],check=True)