# Cache-boundary traces only

Review both JSON traces before any identity mapping or source-linked capture receipt.
This is the narrow follow-up to the recorded observability verdict, not a new accuracy trial.
Each has121 direct same-ACK reconciliations: P(n)=[3+(n-1)/32, 0.0625, -2], n=1..121.
A real pending command supplies a0.5m legacy error on the first ACK; later ACKs must not append.
Compare every legacy row across traces. Helper absence is N/A for the cache-boundary assertion.
Where available, verify each raw retained-ID list, observed/retained/eviction count, oldest/latest
position, original anchor and drift. At121:120 retained,1 evicted, IDs2..121, original anchor,
3.75m total drift and1/32m previous-snapshot delta. All offsets are exactly representable.
No transport, physics-time, consumption-time or gameplay accuracy inference is supported.
Freeze the outcome-only boundary verdict before requesting the separate controller key.
