"""Serial, standard-library-only observation audit; never imports trace contents."""
import datetime
import hashlib
import io
import json
import math
from pathlib import Path
import sys
import traceback
import zipfile
from fractions import Fraction

SOURCE = Path(r"C:\Users\blith\AppData\Local\Temp\opencode\ack-cache-boundary-neutral-r1\blind-traces.zip")
OUT = Path(__file__).resolve().parent
EXPECTED_SHA = "70a15c1f330c7e9e51bf50fc52673243dd3cbe62dd030acdc60081eba6443517"
CAPACITY = 120  # Reviewer-supplied bar, not an independently inspected source constant.
COUNT = 121
checks = []


def check(label, actual, expected):
    passed = strict_equal(actual, expected)
    checks.append({"check": label, "pass": passed, "actual": actual, "expected": expected})
    return passed


def strict_equal(a, b):
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(strict_equal(a[k], b[k]) for k in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(strict_equal(x, y) for x, y in zip(a, b))
    return a == b


def no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON object key: {key!r}")
        result[key] = value
    return result


def nonstandard_constant(value):
    raise ValueError(f"Nonstandard JSON constant: {value}")


def all_finite(value):
    if isinstance(value, dict):
        return all(all_finite(x) for x in value.values())
    if isinstance(value, list):
        return all(all_finite(x) for x in value)
    return not isinstance(value, float) or math.isfinite(value)


decoder = json.JSONDecoder(object_pairs_hook=no_duplicates, parse_constant=nonstandard_constant)


def whitespace(text, i):
    while i < len(text) and text[i] in " \t\r\n":
        i += 1
    return i


def object_spans(text, start):
    """Get exact raw value spans, without reparsing/reformatting those values."""
    i = whitespace(text, start)
    assert text[i] == "{"
    i = whitespace(text, i + 1)
    result = {}
    if text[i] == "}":
        return result
    while True:
        key, end = decoder.raw_decode(text, i)
        assert isinstance(key, str) and key not in result
        i = whitespace(text, end)
        assert text[i] == ":"
        begin = whitespace(text, i + 1)
        _, end = decoder.raw_decode(text, begin)
        result[key] = (begin, end)
        i = whitespace(text, end)
        if text[i] == "}":
            return result
        assert text[i] == ","
        i = whitespace(text, i + 1)


def array_spans(text, start):
    i = whitespace(text, start)
    assert text[i] == "["
    i = whitespace(text, i + 1)
    result = []
    if text[i] == "]":
        return result
    while True:
        begin = i
        _, end = decoder.raw_decode(text, begin)
        result.append((begin, end))
        i = whitespace(text, end)
        if text[i] == "]":
            return result
        assert text[i] == ","
        i = whitespace(text, i + 1)


def position(n):
    return [float(Fraction(3) + Fraction(n - 1, 32)), 0.0625, -2.0]


def sample(n):
    return {
        "ack": 1,
        "anchor_kind": "first_observed_snapshot_not_consumption",
        "epoch": 7,
        "first_snapshot_drift_m": float(Fraction(n - 1, 32)),
        "first_snapshot_position": position(1),
        "observation": n,
        "position": position(n),
        "prediction_enabled": True,
        "previous_snapshot_delta_m": None if n == 1 else 0.03125,
        "repeated_ack": n > 1,
    }


def squared_distance(a, b):
    return sum((Fraction(x) - Fraction(y)) ** 2 for x, y in zip(a, b, strict=True))


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


exit_code = 1
result = {
    "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "python_version": sys.version,
    "python_executable": sys.executable,
    "input_path": str(SOURCE),
    "expected_sha256": EXPECTED_SHA,
    "bar_capacity": CAPACITY,
    "capacity_declaration_limit": "120 is the supplied review bar and README boundary expectation; no source/API capacity constant is inspected or bound by this ZIP.",
    "method": "Independent exact per-row expected values; strict JSON types; complete raw ID windows; exact byte-value spans for legacy and nondiagnostic parity; no tolerance; no use of producer checks as proof.",
}
try:
    assert sys.version_info[:3] == (3, 13, 15), "Unapproved interpreter"
    blob = SOURCE.read_bytes()
    result["input_sha256"] = hashlib.sha256(blob).hexdigest()
    assert result["input_sha256"] == EXPECTED_SHA, "Input hash mismatch"
    docs, texts, spans, members = {}, {}, {}, []
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        names = archive.namelist()
        check("zip.names.unique", len(names), len(set(names)))
        check("zip.member_set", sorted(names), ["README.md", "sample-M.json", "sample-T.json"])
        check("zip.testzip", archive.testzip(), None)
        for info in archive.infolist():
            data = archive.read(info)
            crc = zipfile.crc32(data) & 0xffffffff
            check(info.filename + ".crc32", crc, info.CRC)
            check(info.filename + ".uncompressed_size", len(data), info.file_size)
            members.append({"name": info.filename, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "crc32": f"{crc:08x}"})
            if not info.filename.endswith(".json"):
                continue
            text = data.decode("utf-8", errors="strict")
            obj = json.loads(text, object_pairs_hook=no_duplicates, parse_constant=nonstandard_constant)
            check(info.filename + ".all_numbers_finite", all_finite(obj), True)
            check(info.filename + ".row_count", len(obj["rows"]), COUNT)
            check(info.filename + ".declared_count", obj["count"], COUNT)
            check(info.filename + ".anchor", obj["anchor"], position(1))
            check(info.filename + ".step_m", obj["step_m"], 0.03125)
            root_spans = object_spans(text, 0)
            row_spans = array_spans(text, root_spans["rows"][0])
            check(info.filename + ".raw_row_count", len(row_spans), COUNT)
            docs[info.filename] = obj
            texts[info.filename] = text
            spans[info.filename] = [object_spans(text, start) for start, _ in row_spans]

    result["members"] = members
    legacy_fields = ["ammo", "corrections", "crouching", "epoch", "error_samples_m", "hard_corrections", "health", "jump_held", "large_corrections", "pending", "position", "previous_position", "sequence", "velocity", "visual_offset"]
    correction = {"ack": 1, "authority": position(1), "error": 0.5, "pending": 0, "previous": [3.5, 0.0625, -2.0], "replayed": position(1)}
    row_keys = ["ack", "diagnostic", "epoch", "insertion", "legacy", "received_position"]
    per_row = []
    boundary = []
    for name, obj in docs.items():
        available = name == "sample-T.json"
        check(name + ".diagnostic_status", obj["diagnostic_status"], "available" if available else "not_available_not_applicable")
        for n, row in enumerate(obj["rows"], 1):
            prefix = f"{name}.rows[{n}]"
            check(prefix + ".keys", sorted(row), row_keys)
            check(prefix + ".insertion", row["insertion"], n)
            check(prefix + ".ack", row["ack"], 1)
            check(prefix + ".epoch", row["epoch"], 7)
            check(prefix + ".received_position", row["received_position"], position(n))
            if n > 1:
                spacing = squared_distance(row["received_position"], obj["rows"][n - 2]["received_position"])
                check(prefix + ".squared_input_spacing_exact", spacing == Fraction(1, 1024), True)
            legacy = row["legacy"]
            check(prefix + ".legacy.keys", sorted(legacy), legacy_fields)
            expected_legacy = {
                "ammo": 15, "corrections": n, "crouching": False, "epoch": 7,
                "error_samples_m": [0.5], "hard_corrections": 0, "health": 100.0,
                "jump_held": False, "large_corrections": [correction], "pending": [],
                "position": position(n), "previous_position": [3.5, 0.0625, -2.0] if n == 1 else position(n - 1),
                "sequence": 1, "velocity": [0.125, 0.0, 0.0],
            }
            for key, value in expected_legacy.items():
                check(prefix + ".legacy." + key, legacy[key], value)
            check(prefix + ".legacy.visual_offset.shape", len(legacy["visual_offset"]), 3)
            check(prefix + ".legacy.recorded_error_squared_exact", Fraction(legacy["error_samples_m"][0]) ** 2 == squared_distance(correction["previous"], correction["authority"]), True)
            diagnostic = row["diagnostic"]
            if not available:
                check(prefix + ".diagnostic_absence_not_failure", diagnostic, None)
                continue
            first = max(1, n - CAPACITY + 1)
            expected_diag = {
                "eviction_count": max(0, n - CAPACITY), "ignored": 0,
                "latest_sample": sample(n), "observed_count": n,
                "oldest_sample": sample(first), "repeats": n - 1,
                "retained_ordinals": list(range(first, n + 1)), "retained_size": min(n, CAPACITY),
            }
            for key, value in expected_diag.items():
                check(prefix + ".diagnostic." + key, diagnostic[key], value)
            check(prefix + ".diagnostic.keys", sorted(diagnostic), sorted(expected_diag))
            check(prefix + ".diagnostic.retention_accounting", diagnostic["retained_size"] + diagnostic["eviction_count"], diagnostic["observed_count"])
            check(prefix + ".diagnostic.oldest_matches_historical_latest", diagnostic["oldest_sample"], obj["rows"][first - 1]["diagnostic"]["latest_sample"])
            latest = diagnostic["latest_sample"]
            check(prefix + ".diagnostic.first_drift_squared_exact", Fraction(latest["first_snapshot_drift_m"]) ** 2 == squared_distance(row["received_position"], obj["rows"][0]["received_position"]), True)
            if n > 1:
                check(prefix + ".diagnostic.previous_delta_squared_exact", Fraction(latest["previous_snapshot_delta_m"]) ** 2 == squared_distance(row["received_position"], obj["rows"][n - 2]["received_position"]), True)
                previous_ids = obj["rows"][n - 2]["diagnostic"]["retained_ordinals"]
                current_ids = diagnostic["retained_ordinals"]
                check(prefix + ".diagnostic.added_id", sorted(set(current_ids) - set(previous_ids)), [n])
                check(prefix + ".diagnostic.evicted_ids", sorted(set(previous_ids) - set(current_ids)), [] if n <= CAPACITY else [n - CAPACITY])
            if n in (1, 2, 119, 120, 121):
                boundary.append({"insertion": n, "observed": diagnostic["observed_count"], "retained": diagnostic["retained_size"], "evicted": diagnostic["eviction_count"], "first_id": diagnostic["retained_ordinals"][0], "last_id": diagnostic["retained_ordinals"][-1], "oldest_position": diagnostic["oldest_sample"]["position"], "latest_position": latest["position"], "original_anchor": latest["first_snapshot_position"], "first_drift_m": latest["first_snapshot_drift_m"], "previous_delta_m": latest["previous_snapshot_delta_m"]})

    left, right = docs["sample-M.json"]["rows"], docs["sample-T.json"]["rows"]
    for n, (m, t) in enumerate(zip(left, right, strict=True), 1):
        m_projected = {k: v for k, v in m.items() if k != "diagnostic"}
        t_projected = {k: v for k, v in t.items() if k != "diagnostic"}
        semantic = check(f"parity.rows[{n}].legacy.type_strict_exact", m["legacy"], t["legacy"])
        nondiagnostic = check(f"parity.rows[{n}].nondiagnostic.type_strict_exact", m_projected, t_projected)
        raw = {}
        for key in m_projected:
            a, b = spans["sample-M.json"][n - 1][key]
            c, d = spans["sample-T.json"][n - 1][key]
            m_bytes = texts["sample-M.json"][a:b].encode("utf-8")
            t_bytes = texts["sample-T.json"][c:d].encode("utf-8")
            raw[key] = check(f"parity.rows[{n}].{key}.raw_value_bytes_exact", m_bytes == t_bytes, True)
        per_row.append({"insertion": n, "legacy_exact": semantic, "nondiagnostic_exact": nondiagnostic, "raw_value_byte_parity": raw, "legacy_sha256": digest(m["legacy"]), "nondiagnostic_sha256": digest(m_projected)})

    result["boundary_rows"] = boundary
    result["per_row_parity"] = per_row
    result["counts"] = {"input_bytes": len(blob), "zip_members": len(members), "json_documents": len(docs), "rows_each": COUNT, "rows_total": sum(len(d["rows"]) for d in docs.values()), "diagnostic_rows_available": sum(r["diagnostic"] is not None for d in docs.values() for r in d["rows"]), "diagnostic_rows_not_available": sum(r["diagnostic"] is None for d in docs.values() for r in d["rows"]), "legacy_parity_rows": sum(r["legacy_exact"] for r in per_row), "nondiagnostic_parity_rows": sum(r["nondiagnostic_exact"] for r in per_row), "independent_checks": len(checks), "checks_passed": sum(c["pass"] for c in checks), "checks_failed": sum(not c["pass"] for c in checks)}
    result["producer_self_reports_not_proof"] = {name: {k: obj[k] for k in ("checks", "failures", "engine", "scope")} for name, obj in docs.items()}
    result["status"] = "pass" if all(c["pass"] for c in checks) else "fail"
    exit_code = 0 if result["status"] == "pass" else 1
except Exception:
    result["status"] = "audit_error"
    result["traceback"] = traceback.format_exc()
finally:
    result["exit_code"] = exit_code
    result["completed_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT / "auditraw" / "03-independent-checks.jsonl").write_text("".join(json.dumps(c, ensure_ascii=False, allow_nan=False) + "\n" for c in checks), encoding="utf-8")
    (OUT / "auditraw" / "03-independent-result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    (OUT / "auditraw" / "03-independent.exit.txt").write_text(str(exit_code) + "\n", encoding="ascii")
    print(json.dumps({k: v for k, v in result.items() if k != "per_row_parity"}, indent=2, ensure_ascii=False))
sys.exit(exit_code)
