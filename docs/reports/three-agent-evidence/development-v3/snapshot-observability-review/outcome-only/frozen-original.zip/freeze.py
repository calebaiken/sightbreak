"""Freeze only this review's artifacts and recheck the supplied ZIP digest."""
import datetime
import hashlib
import json
from pathlib import Path
import sys

assert sys.version_info[:3] == (3, 13, 15), "Unapproved interpreter"
out = Path(__file__).resolve().parent
source = Path(r"C:\Users\blith\AppData\Local\Temp\opencode\ack-cache-boundary-neutral-r1\blind-traces.zip")
expected = "70a15c1f330c7e9e51bf50fc52673243dd3cbe62dd030acdc60081eba6443517"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new_json(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


assert sha(source) == expected, "Input ZIP changed before freeze"
result = json.loads((out / "auditraw" / "03-independent-result.json").read_text(encoding="utf-8"))
judgments = json.loads((out / "machine-judgments.json").read_text(encoding="utf-8"))
assert result["status"] == "pass" and result["exit_code"] == 0
assert result["counts"]["checks_failed"] == 0
assert judgments["independent_verification"]["checks"] == result["counts"]["independent_checks"]
assert judgments["input_sha256"] == result["input_sha256"] == expected
assert judgments["blinding"]["mapping_opened"] is False
assert judgments["blinding"]["identity_source_inspected"] is False
assert judgments["release_approval"] is False
assert len(result["per_row_parity"]) == 121
assert all(r["legacy_exact"] and r["nondiagnostic_exact"] and all(r["raw_value_byte_parity"].values()) for r in result["per_row_parity"])
for index, member in enumerate(result["members"]):
    assert sha(out / "auditraw" / f"entry-{index:03d}.bin") == member["sha256"]
for name in ("01-zip-audit.exit.txt", "02-structure.exit.txt", "03-independent.exit.txt"):
    assert (out / "auditraw" / name).read_text(encoding="ascii").strip() == "0"
utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
write_new_json(out / "auditraw" / "04-freeze.json", {
    "frozen_utc": utc,
    "python_version": sys.version,
    "python_executable": sys.executable,
    "input_sha256_rechecked": expected,
    "raw_member_capture_hashes_rechecked": True,
    "all_prior_exits_zero": True,
    "independent_verifier_pass_confirmed": True,
    "report_and_machine_judgments_exist_before_freeze": (out / "report.md").is_file() and (out / "machine-judgments.json").is_file(),
    "identity_or_source_inspected": False,
    "exit_code": 0,
})
with (out / "auditraw" / "04-freeze.exit.txt").open("x", encoding="ascii", newline="\n") as stream:
    stream.write("0\n")
with (out / "FROZENUTC.txt").open("x", encoding="ascii", newline="\n") as stream:
    stream.write(utc + "\n")
excluded = {"SHA256-LEDGER.json", "FREEZE-RECEIPT.json"}
files = []
for path in sorted(out.rglob("*")):
    if path.is_file() and path.relative_to(out).as_posix() not in excluded:
        files.append({"path": path.relative_to(out).as_posix(), "bytes": path.stat().st_size, "sha256": sha(path)})
ledger = {
    "schema": "sol-review-sha256-ledger-v1",
    "frozen_utc": utc,
    "external_input": {"path": str(source), "bytes": source.stat().st_size, "sha256": expected},
    "zip_members": result["members"],
    "files": files,
    "excluded_to_avoid_hash_self_reference": sorted(excluded),
    "identity_material_unopened_at_freeze": True,
}
write_new_json(out / "SHA256-LEDGER.json", ledger)
receipt = {
    "schema": "sol-review-freeze-receipt-v1",
    "frozen_utc": utc,
    "input_sha256": expected,
    "ledger_sha256": sha(out / "SHA256-LEDGER.json"),
    "report_sha256": sha(out / "report.md"),
    "machine_judgments_sha256": sha(out / "machine-judgments.json"),
    "frozen_utc_marker_sha256": sha(out / "FROZENUTC.txt"),
    "ledger_included_files": len(files),
    "mapping_opened": False,
    "identity_source_inspected": False,
    "release_approval": False,
    "immutability": "Timestamped content-hash snapshot, not an OS write lock or trusted timestamp authority",
}
write_new_json(out / "FREEZE-RECEIPT.json", receipt)
# Final read-back has no writes. A failure prevents a successful final receipt being returned.
for item in ledger["files"]:
    assert sha(out / item["path"]) == item["sha256"], item["path"]
assert sha(out / "SHA256-LEDGER.json") == receipt["ledger_sha256"]
assert sha(source) == expected
print(json.dumps({"output_directory": str(out), **receipt, "freeze_receipt_sha256": sha(out / "FREEZE-RECEIPT.json"), "all_ledger_hashes_readback_verified": True, "exit_code": 0}, indent=2))
