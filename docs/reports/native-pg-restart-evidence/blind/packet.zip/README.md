# Neutral receipt-recovery evidence review

## Reviewer boundary

Use only this packet. Do not search repositories, external reports, commit
history, source paths or controller material to identify either implementation.
Random group labels are identifiers, not a ranking. The source/version mapping
and original-file hash bindings remain outside this packet until your verdict.
No preferred outcome or prior review verdict is supplied here.

This is a review of completed observations. Do not run applications, services,
database operations, native clients or further tests. Read the supplied records.

## Workload and evidence layout

Each group contains three cases, with original integer prices 400, 401 and
10,000,000. A native UI signs in to an existing account, enters its transaction
method, and sends a real HTTP market purchase. A proxy is intended to hold the
upstream response before any headers or bytes reach the client. A separate SQL
reader captures the committed state. The native process is terminated and its
exit acknowledged. Two successive native processes sign in to the same account
using fresh sessions: the first attempts saved-receipt recovery, and the second
checks the subsequent restart state.

The recorded method is `EconomyUI._authenticate` followed by `_perform` for the
initial mutation and `_retry_pending` after restart. Harness/probe source and
their hashes are withheld by the controller for blinding. Distinguish observed
trace consistency from assertions that would require inspecting that source.

Every case includes:

- `01-before.json`: actual economic rows and session rows before dispatch.
- `02-committed-before-kill.json`: independent PostgreSQL reader's rows at the
  response-hold boundary, including connection PID, database clock and snapshot.
- `03-after-kill.json`, `04-after-recovery.json`,
  `05-after-second-restart.json`: the three subsequent complete recorded states.
- `fixture.redacted.json`: actor/item/listing IDs and original request context.
  It is not a substitute for the actual SQL rows.
- `timeline.jsonl`: all retained HTTP events, request/response text, native PIDs,
  wall/monotonic times, hold/discard records, exit acknowledgements and SQL reads.
- Native stdout/stderr for the initial process and both restarts. These are
  full captured outputs, with only explicit absolute-path neutralization where
  needed; those copies are not described as raw-byte-identical.
- Journal presence/digest/record captures and original journal byte files where
  a journal existed. Missing journal bytes remain an observed absence.
- `result.json`: the producer's recorded outcomes and checks, not an independent
  verdict. Verify its claims against the other records.
- `semantic-comparison.json`: an aid derived from all five supplied SQL files,
  including actual added/removed/changed rows, persisted receipt, wire result,
  native result, session-row matches and the ordering events. It substitutes
  neither expected fixtures nor hashes for the real rows.

`OBSERVED_COMPARISON.json` lists actual prices and unfiltered initial row counts.
`MANIFEST.json` pins each payload's bytes and SHA-256, except itself. The external
ZIP and manifest pins are provided by the controller. ZIP metadata timestamps
are fixed for reproducibility; timestamps inside the evidence are unchanged.

## Fixed quality bar

Judge each case and each group independently. Cite packet paths and relevant
row IDs/event timestamps for every material claim.

1. **Completeness and integrity:** all five actual SQL stages and the relevant
   native/HTTP/journal records exist; note any missing or contradictory evidence.
   Do not accept a producer `true` flag as proof by itself.
2. **Initial dispatch:** correlate native process, authenticated owner, original
   UUID receipt, market path and strict integer expected price with the actual
   HTTP request. Distinguish a constructed fixture from observed dispatch.
3. **Commit before termination:** require a held upstream success, independent
   SQL visibility before the termination request, acknowledged native exit,
   response discard and only then recovery. Check that no original purchase
   response-delivery event contradicts the hold. Preserve clock-domain
   distinctions; do not mix monotonic times from different executions.
4. **One real settlement:** derive buyer debit, seller credit, fee burn, item
   ownership/reservation, listing state, Operation/request hash/response, Ledger
   rows and Audit rows from the actual before/after records. Explain unrelated
   fixture rows rather than counting all rows as mutation effects.
5. **Authentication and exact recovery:** establish the original owner/server,
   three distinct login digests matched to real session rows, journal survival
   or absence, and any retry's original receipt/body. Compare the full committed
   response, persisted Operation response and native recovery result. A refreshed
   balance or inventory alone is not exact receipt recovery.
6. **Second restart:** inspect pending state, purchase-request count and complete
   economic equality against the committed state. Session and rate bookkeeping
   are not economic mutations; session changes are retained separately.
7. **Negative outcomes:** distinguish lost recovery from a duplicate settlement,
   rejection from uncertainty, and an empty local retry from a successful replay.
   Do not erase any observed failure merely because another check passes.
8. **Verdict:** provide per-case findings, per-group counts and one of
   `supported`, `failed`, or `insufficient` for the specified recovery behavior.
   Identify the strongest supported group, if any, by its neutral label only.
   List remaining blockers and the exact scope of any supported claim. Do not
   infer a shipping/source identity from the outcome or chronology.

## Transformations and limitations

- All **30 economic-stage files** are unmodified bytes from the published
  observations. No economic/session rows, database identifiers, timestamps,
  entity UUIDs, PIDs or digests were removed or rewritten.
- Absolute executable, checkout/project, external-probe and private journal paths
  are replaced with consistent bracketed placeholders in affected context,
  timeline and native-output files. All other captured lines/fields remain.
  The controller retains the exact original text/replacement/count, original Git
  blob/SHA-256 and transformed-file SHA-256 for each file. Altered files are
  transformed observation copies, not raw-byte-identical originals.
- Plaintext synthetic passwords and bearer credentials were already redacted in
  the immutable observations. Those redactions remain. Token digests are retained.
- Three cases per group share one database within that group's invocation;
  unrelated earlier-case records remain in later snapshots. The workload/prices
  match, but executions occurred on **different dates**. All original times remain
  visible. This is not a latency, throughput or statistical-reliability study.
- One invocation pre-seeded separate ancillary-regression accounts. Its first
  stage has **eight additional Player/Ledger seed rows combined**: four players
  and four fixture-credit ledger entries. It also has six additional minted item
  rows, six item-mint audit rows and four initial session rows. All are retained;
  assess within-case changes and the actual actors rather than equating initial
  totals. These differences do not constitute eight extra purchases.
- Balances/items were explicitly seeded fictional fixtures in real PostgreSQL.
  This does not establish gameplay earning or registration behavior.
- Native UI/API methods were exercised; there was no mouse/touch confirmation
  automation, physical-device qualification, backend-process-failure test or
  actual power failure. Process termination is not machine power-loss durability.
- Native JSON can represent whole-number responses as floats, while the sent
  expected price must remain a strict JSON integer. PostgreSQL JSONB may reorder
  response object keys; compare exact semantic content as well as captured request
  bytes. Preserve large nanosecond integers when reading JSON.
- A separately retained ancillary regression recorded an **original 36/37 failure**
  and a **37/37 result only after a one-literal unreachable-address calibration**.
  Its original/calibrated executed sources and logs remain with the controller,
  outside this paired packet. The calibrated result is not a full unmodified-suite
  pass and contributes no extra case to the comparative recovery counts.
