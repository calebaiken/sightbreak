# Windows retry outcome review

Run 39723283770 is frozen to `dc2a198372b2e5da51ca1618f16d8249e44ec485`. Connector metadata must show exactly one actual Windows job, 119641410526, and every ordinary selected-host step must remain present. This run cannot attest Linux/Mac/iOS or relabel the earlier 0ca125d artifacts.

The actual comparison is the failed Windows ordinary journey from run 39719407304: settings resume led to an eliminated player and the living-HUD guard correctly rejected it before restart/focus coverage. Source/focused-Linux acceptance is separate from this actual Windows outcome.

Required raw evidence:

- Official transferred artifact digests, full receipt index, clean matching source, exact executable receipt identity and unaltered decoded CI logs. Preserve failures and image-transfer limits.
- Ten genuine native suites with distinct fresh engine producer paths, resource preservation, produced-file integrity and outer namespace cleanup. The new `HUD_OBJECTIVE_HINT_TEST_CLEANUP` must separately attest its owned fixture removed, original directory restored, empty reason and native exit 0.
- Actual exported keyboard/pointer and reload checks, both controlled and original delayed diagnostics identified separately, with actual diagnostic exits rather than wrapper conclusions.
- Complete ordinary journey within the unchanged 300-second whole-flow budget. Native settings must keep the same living paused actor/round/weapon/ammunition and frozen elapsed/health; actual Escape acknowledgment and a two-drawn-frame fence share the existing ten-second transition budget. Context checks must continue after capture and through paused OCR; actual resumed PNG must remain a living HUD. Dead/menu negatives remain valid rejections.
- Exact settings/profile save and restarted-process equality, followed by real native focus loss, explicit resume, physical W/LMB still held while logical input remains neutral, acknowledged release and fresh same-living-player movement. No death swallowing or retry substitution.
- Player plant/defuse retain original normal rules, 15-second movement gate and 180/300-tick holds, interruption reset, one contribution, natural resolution and restart.
- Complete stock match, normal protocol/prediction/time scale, ten actors, all natural rounds/halftime, one completion, exact earned offline XP/credits formula and actual disk/restarted equality. A twelve-round capped draw is valid stock behavior.

No local native clients, implementation edits, child agents or external comments are part of this review. New functional outcomes cannot establish human play, device performance, broad bot reliability, presentation or complete G1/platform release acceptance.
