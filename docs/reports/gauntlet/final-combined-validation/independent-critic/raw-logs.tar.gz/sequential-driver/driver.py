import datetime, hashlib, json, os, pathlib, shutil, signal, subprocess, sys, time
repo = pathlib.Path(sys.argv[1]).resolve()
expected = sys.argv[2]
out = repo / 'builds' / 'final-validation-0527715'
out.mkdir(parents=True, exist_ok=False)
shutil.copy2(__file__, out / 'driver.py')
sys.path.insert(0, str(repo / 'scripts'))
import build_manifest, toolchain

def write(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def source():
    value = build_manifest.source()
    if value['source_dirty'] or value['source_game_dirty'] or value['source_commit'] != expected:
        raise RuntimeError('Frozen source identity or cleanliness changed')
    return value

before = source()
write('source-before.json', before)
engine = pathlib.Path(toolchain.binary())
write('engine.json', {'path': str(engine), 'sha256': hashlib.file_digest(engine.open('rb'), 'sha256').hexdigest()})
tracked = subprocess.check_output(['git', 'ls-files', '-z', 'backend', 'server', 'game', 'docs/reports/media/art-v9/hands/logs'], cwd=repo).split(b'\0')
write('tracked-inputs.json', {os.fsdecode(p): hashlib.sha256((repo / os.fsdecode(p)).read_bytes()).hexdigest() for p in tracked if p and (repo / os.fsdecode(p)).is_file()})
env = dict(os.environ)
env.pop('DISPLAY', None)
env.pop('SIGHTBREAK_STATE_DIR', None)
env['SIGHTBREAK_TOOLS_DIR'] = '/workspace/tools'
env['SIGHTBREAK_BACKEND_PYTHON'] = '/workspace/sightbreak/.venv/bin/python'
write('driver.json', {'pid': os.getpid(), 'started_utc': now(), 'expected_source': expected, 'selected_environment': {k: env.get(k) for k in ['DISPLAY', 'SIGHTBREAK_STATE_DIR', 'SIGHTBREAK_TOOLS_DIR', 'SIGHTBREAK_BACKEND_PYTHON', 'GODOT_BIN', 'LIBGL_ALWAYS_SOFTWARE', 'LP_NUM_THREADS']}})

def run(label, command, timeout):
    record = {'command': command, 'cwd': str(repo), 'started_utc': now(), 'timeout_seconds': timeout}
    start = time.monotonic()
    process = None
    try:
        with (out / (label + '.log')).open('w') as log:
            process = subprocess.Popen(command, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            record.update(pid=process.pid, pgid=os.getpgid(process.pid))
            write(label + '-command.json', record)
            record['exit_code'] = process.wait(timeout=timeout)
    except BaseException as error:
        record['exception'] = {'type': type(error).__name__, 'message': str(error)}
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            record['terminated_wait_status'] = process.wait(timeout=15)
        record['exit_code'] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
    finally:
        record.update(completed_utc=now(), seconds=time.monotonic()-start)
        record['source_after'] = source()
        record['source_unchanged'] = record['source_after'] == before
        write(label + '-result.json', record)
        print(json.dumps({'label':label, 'exit_code':record['exit_code'], 'seconds':record['seconds'], 'source_unchanged':record['source_unchanged']}), flush=True)
    if record['exit_code'] or not record['source_unchanged']:
        raise RuntimeError(label + ' failed; original output preserved')

failure = None
try:
    run('strict-new-native', ['python3', 'scripts/run_native_regressions.py', '--output', str(out / 'native-two-suites'), '--suites', 'transaction_journal', 'gunplay_rules'], 600)
    run('aggregate', ['./scripts/validate.sh'], 1200)
except BaseException as error:
    failure = {'type':type(error).__name(), 'message':str(error)}
finally:
    write('source-after.json', source())
    remaining=[]
    for path in pathlib.Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            comm=(path/'comm').read_text().strip()
            if not comm.lower().startswith('godot'):
                continue
            argv=(path/'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            if str(repo) in argv or 'sightbreak-native-tests-' in argv:
                remaining.append({'pid':int(path.name),'comm':comm,'argv':argv})
        except (FileNotFoundError,ProcessLookupError,PermissionError):
            pass
    write('process-after.json', {'observed_utc':now(),'scope':'Godot processes for this frozen checkout or owned private native suite projects','remaining':remaining})
    write('result.json', {'completed_utc':now(), 'passed':failure is None and not remaining, 'failure':failure, 'remaining_godot_count':len(remaining), 'source_unchanged':source()==before})
if failure is not None or remaining:
    raise SystemExit(1)
