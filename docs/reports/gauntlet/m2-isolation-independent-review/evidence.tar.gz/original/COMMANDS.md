# Commands executed

Candidate review worktree:

```sh
cd /workspace/sightbreak-ci-isolation
git worktree add --detach /workspace/reviews/m2-isolation-critic/source 1195b23423b4cb37c613e9e0304508d4c2637aff
```

Native commands ran from that clean worktree. Every native subprocess command is
also retained in `all-nine/results.json`, `save-safety/results.json`, the
save-safety baseline receipts, and their engine producer receipts.

```sh
bash /workspace/reviews/m2-isolation-critic/commands.sh
SIGHTBREAK_TOOLS_DIR=/workspace/tools SIGHTBREAK_STATE_DIR=/workspace/reviews/m2-isolation-critic/state/save-safety python3 scripts/test_native_suite_isolation.py --output /workspace/reviews/m2-isolation-critic/save-safety
SIGHTBREAK_TOOLS_DIR=/workspace/tools SIGHTBREAK_STATE_DIR=/workspace/reviews/m2-isolation-critic/state/cleanup-failure python3 /workspace/reviews/m2-isolation-critic/cleanup_failure_control.py
git diff 6a0d8d5 1195b234 --check -- .github/workflows/desktop-alpha.yml scripts/run_native_regressions.py scripts/test_native_suite_isolation.py
git status --porcelain
```

The review-only fault injection catches its expected PermissionError and exits 0
when it has reproduced the false success receipt. `cleanup-failure-observed.json`
records the raised cleanup error and namespace residue before review cleanup.

For the separate packaging task, the exact script and test bytes were copied with
`git show 32c37fe:scripts/<file>` into `qa-receipts/source/`. The original Windows
archive was safely extracted into the owned `qa-receipts/windows-qa/` directory.

```sh
python3 /workspace/reviews/m2-isolation-critic/qa-receipts/source/test_package_qa_receipts.py -v
python3 /workspace/reviews/m2-isolation-critic/qa-receipts/source/package_qa_receipts.py --source /workspace/reviews/m2-isolation-critic/qa-receipts/windows-qa --output /workspace/reviews/m2-isolation-critic/qa-receipts/actual-windows.zip
python3 /workspace/reviews/m2-isolation-critic/qa-receipts/verify_archive.py
```

`IDENTITIES.json` records the engine binary hash, checksum-verified original editor
archive, exact source commits, matching game tree identity and initial clean status.
`profiles-before.json` retains 47 preexisting profile hashes. Independent Python
checks compared those bytes after execution, checked each native path/exit/log and
produced-file inventory, checked all 295 game files against their Git blob objects,
and wrote `INDEPENDENT_CHECKS.json`. No implementation source was edited.
