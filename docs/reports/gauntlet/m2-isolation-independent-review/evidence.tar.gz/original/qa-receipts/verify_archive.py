#!/usr/bin/env python3
"""Independent reader and actual-size failure controls for exact committed packer."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import random
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path('/workspace/reviews/m2-isolation-critic/qa-receipts')
ORIGINAL = Path('/workspace/sightbreak-v1-execution/builds/mission-m1/critic-ci-39712752860/windows-qa.zip')
sys.path.insert(0, str(ROOT / 'source'))
from package_qa_receipts import package

excluded = {'.git', '.godot', '__pycache__', 'node_modules', 'cache', '.cache'}
with zipfile.ZipFile(ORIGINAL) as original, zipfile.ZipFile(ROOT / 'actual-windows.zip') as compact:
    expected = {}
    for info in original.infolist():
        path = PurePosixPath(info.filename)
        if info.is_dir() or any(part in excluded or part.endswith(('.app', '.framework', '.xcodeproj')) for part in path.parts):
            continue
        if path.suffix.lower() in {'.json', '.jsonl', '.log'} or (path.parts[0] == 'macos-diagnostics' and path.suffix.lower() == '.txt'):
            expected[info.filename] = original.read(info)
    index = json.loads(compact.read('qa-receipts-index.json'))
    assert [record['path'] for record in index['files']] == sorted(expected)
    assert set(compact.namelist()) == {'evidence/' + name for name in expected} | {'qa-receipts-index.json'}
    for record in index['files']:
        actual = compact.read(record['archive_path'])
        assert actual == expected[record['path']]
        assert record['bytes'] == len(actual)
        assert record['sha256'] == hashlib.sha256(actual).hexdigest()
        assert (ROOT / 'windows-qa' / record['path']).read_bytes() == actual
    manifests = [name for name in expected if name.endswith('manifest.json')]
    profiles = [name for name in expected if name.endswith('offline_training.json')]
    observer_traces = [name for name in expected if name.endswith('events.jsonl')]
    assert manifests and len(profiles) == 3 and len(observer_traces) == 5
    for name in profiles:
        json.loads(expected[name])
    manifest = json.loads(expected['manifest.json'])
    assert manifest.get('source_commit'), manifest.keys()
    for name in observer_traces:
        assert all(isinstance(json.loads(line), dict) for line in expected[name].splitlines() if line)
    (ROOT / 'RECONSTRUCTED_INDEX.json').write_text(json.dumps(index, indent=2) + '\n')

repeat = package(ROOT / 'windows-qa', ROOT / 'repeat.zip')
assert (ROOT / 'repeat.zip').read_bytes() == (ROOT / 'actual-windows.zip').read_bytes()
with tempfile.TemporaryDirectory(prefix='actual-bound-control-', dir=ROOT) as temp:
    temp = Path(temp)
    evidence = temp / 'source'; evidence.mkdir()
    large = evidence / 'raw.log'
    data = random.Random(714).randbytes(30 * 1024 * 1024 + 17)
    large.write_bytes(data)
    before = hashlib.sha256(data).hexdigest()
    del data
    output = temp / 'must-not-publish.zip'
    try:
        package(evidence, output)
    except RuntimeError as error:
        assert 'download bound' in str(error)
        oversize_error = str(error)
    else:
        raise AssertionError('Actual 30MiB bound admitted oversized raw evidence')
    assert not output.exists()
    assert hashlib.sha256(large.read_bytes()).hexdigest() == before
    assert not list(temp.glob('sightbreak-qa-receipts-*'))
    oversize = {'input_bytes':large.stat().st_size,'input_sha256':before,'error':oversize_error,
                'output_absent':True,'input_unchanged':True,'temporary_archive_removed':True}

result = {'raw_source_archive_sha256':hashlib.sha256(ORIGINAL.read_bytes()).hexdigest(),
          'selected_files_reconstructed':len(expected),'source_commit':manifest['source_commit'],
          'manifest_paths':manifests,'progression_paths':profiles,'observer_trace_paths':observer_traces,
          'compact_bytes':(ROOT/'actual-windows.zip').stat().st_size,
          'compact_sha256':hashlib.sha256((ROOT/'actual-windows.zip').read_bytes()).hexdigest(),
          'all_selected_bytes_and_index_match':True,'deterministic_same_source':True,
          'actual_30MiB_failure_control':oversize,'gameplay_acceptance':'Not inferred from packaging'}
(ROOT / 'INDEPENDENT_RECONSTRUCTION.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
