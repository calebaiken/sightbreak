#!/usr/bin/env bash
set -uo pipefail
cd /workspace/reviews/m2-isolation-critic/source
export SIGHTBREAK_TOOLS_DIR=/workspace/tools
export SIGHTBREAK_STATE_DIR=/workspace/reviews/m2-isolation-critic/state/all-nine
python3 scripts/run_native_regressions.py --output /workspace/reviews/m2-isolation-critic/all-nine
