# Follow-up commands

The critic created a clean detached worktree at the exact follow-up:

```sh
cd /workspace/sightbreak-ci-isolation
git worktree add --detach /workspace/reviews/m2-isolation-followup/source daafe167d8d331a2cb5f4abf276cd85f8babc101
```

Commands below ran from `/workspace/reviews/m2-isolation-followup/source` with raw
stdout/stderr and exit status retained in the corresponding command log/exit files.
Individual native subprocess arguments are retained in each suite/probe receipt.

```sh
SIGHTBREAK_TOOLS_DIR=/workspace/tools SIGHTBREAK_STATE_DIR=/workspace/reviews/m2-isolation-followup/state/original-counterexample python3 /workspace/reviews/m2-isolation-followup/recheck_original.py
SIGHTBREAK_TOOLS_DIR=/workspace/tools SIGHTBREAK_STATE_DIR=/workspace/reviews/m2-isolation-followup/state/cleanup-controls python3 scripts/test_native_suite_cleanup.py --output /workspace/reviews/m2-isolation-followup/cleanup-controls
SIGHTBREAK_TOOLS_DIR=/workspace/tools SIGHTBREAK_STATE_DIR=/workspace/reviews/m2-isolation-followup/state/all-nine python3 scripts/run_native_regressions.py --output /workspace/reviews/m2-isolation-followup/all-nine
SIGHTBREAK_TOOLS_DIR=/workspace/tools SIGHTBREAK_STATE_DIR=/workspace/reviews/m2-isolation-followup/state/save-safety python3 scripts/test_native_suite_isolation.py --output /workspace/reviews/m2-isolation-followup/save-safety
python3 /workspace/reviews/m2-isolation-followup/verify_followup.py
```

No implementation source was edited. The original counterexample was adapted only
to its new owned root; the original stored script and rejection were not changed.
The old assertion now intentionally fails in its subprocess; the wrapper checks
the truthful follow-up receipt and cleans only the owned control residue.
