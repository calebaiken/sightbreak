#!/usr/bin/env python3
"""Independent raw receipt readback for the exact cleanup follow-up."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/reviews/m2-isolation-followup')
SOURCE = ROOT / 'source'
summary = {}
for area in ('all-nine', 'save-safety'):
    folder = ROOT / area
    isolation = json.loads((folder / 'isolation.json').read_text())
    results = json.loads((folder / 'results.json').read_text())
    assert isolation['engine'] == '4.7.2.stable.official.ed1daf0bf'
    assert isolation['passed'] and isolation['failure'] is None
    assert not isolation['finalization_failures']
    assert isolation['source_resources_unchanged'] and isolation['copied_resources_unchanged']
    assert isolation['temporary_project_removed']
    assert isolation['suite_timeout_seconds'] == 120 and isolation['probe_timeout_seconds'] == 30
    assert isolation['cleanup'] and all(item['removed'] and not Path(item['user_namespace']).exists() for item in isolation['cleanup'])
    native_paths = []
    for receipt in results:
        before, after = receipt['before'], receipt['after']
        assert not before['profile_exists'] and not before['diagnostics_exist']
        assert before['user_data_dir'] == after['user_data_dir']
        expected = (Path(before['data_dir']) / before['custom_user_dir']).resolve()
        assert Path(before['user_data_dir']).resolve() == expected
        assert before['uses_custom_user_dir'] and before['custom_user_dir'] == after['custom_user_dir']
        assert receipt['exit'] == 0 and receipt['clean_log']
        log = Path(receipt['log']).read_text()
        assert not re.search(r'(^|\n)(SCRIPT ERROR:|ERROR:|WARNING:)', log)
        native_paths.append(before['user_data_dir'])
        copied = folder / (receipt['suite'] + '-userdata')
        observed = {p.relative_to(copied).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in copied.rglob('*') if p.is_file() and '.godot' not in p.relative_to(copied).parts}
        assert observed == receipt['produced_files_sha256']
    assert len(native_paths) == len(set(native_paths))
    actual = {p.relative_to(SOURCE/'game').as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
              for p in (SOURCE/'game').rglob('*') if p.is_file() and '.godot' not in p.relative_to(SOURCE/'game').parts}
    assert actual == isolation['source_resources_sha256']
    summary[area] = {'suites':[r['suite'] for r in results], 'distinct_fresh_native_paths':native_paths,
                     'game_resources_verified':len(actual),'cleanup':isolation['cleanup'],
                     'import_seconds':isolation['import']['wall_seconds']}

controls = json.loads((ROOT/'cleanup-controls/results.json').read_text())
for name, control in controls.items():
    assert control['control_assertions_passed'] and control['control_teardown_removed_resources']
    receipt = json.loads((ROOT/'cleanup-controls'/name/'isolation.json').read_text())
    assert control['passed'] == receipt['passed']
    assert bool(receipt['passed']) == (name == 'success')
    assert receipt['cleanup'] and len(receipt['cleanup']) == 1
    for result in json.loads((ROOT/'cleanup-controls'/name/'results.json').read_text()):
        assert result['suite'] == 'peer_lifecycle' and result['exit'] == 0 and result['clean_log']
        assert 'PEER_LIFECYCLE_TEST checks=16 failures=0' in Path(result['log']).read_text()
    for item in receipt['cleanup']:
        assert not Path(item['user_namespace']).exists(), 'Control teardown left owned namespace'
    assert not (ROOT/'cleanup-controls'/name/'isolation.json.pending').exists()
combined = controls['native-and-cleanup-failure']
assert combined['actual_native_failure']['exit'] == 9 and not combined['actual_native_failure']['clean_log']
native_log = Path(combined['actual_native_failure']['log']).read_text()
assert 'ERROR: Intentional native cleanup control failure' in native_log
assert combined['failure']['type'] == 'RuntimeError'
assert combined['finalization_failures'][0]['type'] == 'PermissionError'
summary['cleanup_controls'] = {name:{'passed':r['passed'],'failure':r['failure'],
                                    'finalization_failures':r['finalization_failures'],
                                    'teardown_removed':r['control_teardown_removed_resources']}
                               for name,r in controls.items()}

profiles = json.loads((ROOT/'profiles-before.json').read_text())
assert all(Path(name).is_file() and hashlib.sha256(Path(name).read_bytes()).hexdigest() == receipt['sha256']
           for name,receipt in profiles.items())
summary['preexisting_profiles_unchanged'] = len(profiles)
original = Path('/workspace/reviews/m2-isolation-critic')
verified_original = 0
for line in (original/'SHA256SUMS').read_text().splitlines():
    digest, relative = line.split('  ', 1)
    assert hashlib.sha256((original/relative).read_bytes()).hexdigest() == digest, relative
    verified_original += 1
summary['original_critic_files_immutable_verified'] = verified_original
summary['candidate_clean_status'] = subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
assert summary['candidate_clean_status'] == ''
(ROOT/'INDEPENDENT_READBACK.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
