#!/usr/bin/env python3
"""Run original counterexample unchanged except its owned review-root path."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/workspace/reviews/m2-isolation-followup')
ORIGINAL = Path('/workspace/reviews/m2-isolation-critic/cleanup_failure_control.py')
original = ORIGINAL.read_bytes()
adapted = original.replace(b'/workspace/reviews/m2-isolation-critic', str(ROOT).encode())
assert original.count(b'/workspace/reviews/m2-isolation-critic') == 1
script = ROOT / 'original_counterexample_relocated.py'
script.write_bytes(adapted)
command = [sys.executable, str(script)]
with (ROOT / 'original-counterexample.log').open('w') as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=120)
receipt = json.loads((ROOT / 'cleanup-failure/isolation.json').read_text())
assert result.returncode == 1, result.returncode
log = (ROOT / 'original-counterexample.log').read_text()
assert "receipt['passed'] is True" in log and 'AssertionError' in log
assert receipt['passed'] is False
assert receipt['failure']['type'] == 'PermissionError'
assert len(receipt['cleanup']) == 1
outcome = receipt['cleanup'][0]
assert not outcome['removed'] and outcome['error']['type'] == 'PermissionError'
assert receipt['temporary_project_removed']
namespace = Path(outcome['user_namespace'])
assert namespace.name == receipt['namespace']
assert namespace.is_relative_to(ROOT / 'state/original-counterexample/data')
assert namespace.exists()
shutil.rmtree(namespace)
observed = {'command':command,'original_script_sha256':hashlib.sha256(original).hexdigest(),
            'only_adaptation':'Replaced the single owned review-root literal; assertions/fault/native suite unchanged',
            'adapted_script_sha256':hashlib.sha256(adapted).hexdigest(),
            'original_false_success_assertion_now_fails':True,'original_control_exit':result.returncode,
            'followup_passed':receipt['passed'],'followup_failure':receipt['failure'],
            'followup_cleanup':receipt['cleanup'],
            'temporary_project_removed':receipt['temporary_project_removed'],
            'review_teardown_removed_namespace':not namespace.exists()}
(ROOT / 'ORIGINAL_COUNTEREXAMPLE_RECHECK.json').write_text(json.dumps(observed, indent=2) + '\n')
print(json.dumps(observed, indent=2))
