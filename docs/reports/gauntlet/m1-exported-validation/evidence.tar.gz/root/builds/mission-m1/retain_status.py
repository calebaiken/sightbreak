from pathlib import Path
import gzip,hashlib,json,sys,time
folder=Path(sys.argv[1]); output=Path(sys.argv[2]); until=time.monotonic()+180
last=None; count=0
with gzip.open(output,'wt',encoding='utf-8') as sink:
 while time.monotonic()<until:
  try:
   raw=(folder/'trace/status.json').read_bytes(); digest=hashlib.sha256(raw).hexdigest()
   if digest!=last:
    json.loads(raw)
    sink.write(json.dumps({'observed_at_unix_ns':time.time_ns(),'sha256':digest,'raw':raw.decode('utf-8')})+'\n');sink.flush();last=digest;count+=1
   result=json.loads((folder/'results.json').read_text())
   if 'elapsed_seconds' in result: break
  except (OSError,ValueError): pass
  time.sleep(.03)
print(json.dumps({'snapshots':count,'output':str(output),'read_only':True}))
