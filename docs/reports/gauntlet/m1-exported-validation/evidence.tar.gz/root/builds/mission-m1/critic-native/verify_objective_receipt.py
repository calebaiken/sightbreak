"""Read-only independent recomputation of one completed native objective receipt."""
from pathlib import Path
import argparse,gzip,hashlib,json,math,os

p=argparse.ArgumentParser();p.add_argument('run',type=Path);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
run=args.run;receipt=json.loads((run/'results.json').read_text());actions=[json.loads(x) for x in (run/'actions.jsonl').read_text().splitlines()]
completed=next(x for x in actions if x['event']=='movement_completed');requested=completed['requested'];first_control=next(i for i,x in enumerate(actions) if x['event']=='movement_control');start_bound=actions[first_control-1]
release=[x for x in actions if x['event'] in ('movement_pulse_released','movement_settle_begin') and x['seconds']<completed['seconds']][-1]
retained=[json.loads(x) for x in gzip.open(str(run)+'-status.jsonl.gz','rt')];raw_hashes=all(hashlib.sha256(x['raw'].encode()).hexdigest()==x['sha256'] for x in retained)
parsed=[(x,json.loads(x['raw'])) for x in retained];by_tick={}
for external,state in parsed:by_tick.setdefault(state['simulation_tick'],(external,state))
def motion(state):
 actor=state['local_actor'];pos=actor['position'];v=actor['velocity']
 return {'tick':state['simulation_tick'],'position':pos,'error_m':math.hypot(pos[0]-requested[0],pos[2]-requested[1]),'horizontal_speed':math.hypot(v[0],v[2]),'consumed_move':state['local_input']['move'],'round':state['round_number'],'phase':state['phase'],'alive':actor['alive'],'health':actor['health'],'time_scale':state['time_scale']}
settled=[];missing=[]
for tick in completed['settled_simulation_ticks']:
 if tick not in by_tick:missing.append(tick);continue
 external,state=by_tick[tick];settled.append({**motion(state),'observed_at_unix_ns':external['observed_at_unix_ns'],'raw_sha256':external['sha256']})
round_number=completed['observed']['round_number'];later=[state for _,state in parsed if state['round_number']==round_number and state['simulation_tick']>=completed['settled_simulation_ticks'][-1]]
later_motion=[motion(s) for s in later]
all_settled_valid=not missing and len(settled)==2 and settled[0]['tick']<settled[1]['tick'] and all(s['tick']>release['released_after_tick'] and s['consumed_move']==[0,0] and s['horizontal_speed']<=.05 and s['error_m']<.45 and s['round']==round_number and s['phase']=='live' and s['alive'] and 0<s['health']<=100 and s['time_scale']==1 for s in settled)
source=receipt['source'];export=receipt['artifact_source'];exe=Path(receipt['executable']);source_ok=source['source_commit']==export['source_commit']=='6a0d8d5d85b4fb37943903886982f51b4ed230b0' and source['source_dirty'] is False and source['source_game_dirty'] is False
elf_ok=hashlib.sha256(exe.read_bytes()).hexdigest()==receipt['executable_sha256']==export['artifact']['sha256']
checks={'receipt_passed':receipt['passed'] is True,'raw_hashes_match':raw_hashes,'source_identity_clean':source_ok,'elf_bytes_match':elf_ok,'whole_within_original_limit':receipt['elapsed_seconds']<receipt['timeout_seconds'],'movement_within_15s_upper_bound':completed['seconds']-start_bound['seconds']<15,'two_exact_raw_neutral_stopped_within_radius_ticks':all_settled_valid,'cleanup_empty':receipt['cleanup_errors']==[],'all_process_exits_zero':all(c['exit_code']==0 for c in receipt['commands']),'restart_equal':receipt['progression_settings_restart_equal'] is True}
groups=[]
for command in receipt['commands']:
 try:os.killpg(command['pid'],0);exists=True
 except ProcessLookupError:exists=False
 groups.append({'name':command['name'],'pid':command['pid'],'group_exists_now':exists})
checks['all_owned_groups_absent_now']=not any(g['group_exists_now'] for g in groups)
required=3 if receipt['scenario']=='plant' else 5;hold=receipt['objective_hold'];checks['objective_exact_duration']=hold['simulation_ticks']==required*60 and abs(hold['simulation_seconds']-required)<=1/60
result={'run':str(run),'scenario':receipt['scenario'],'checks':checks,'all_checks_passed':all(checks.values()),'movement_wall_upper_bound_seconds':completed['seconds']-start_bound['seconds'],'movement_preceding_bound_event':start_bound['event'],'movement_preceding_bound_label':start_bound.get('label',start_bound.get('capture')),'endpoint_error_m':completed['target_distance'],'endpoint_speed_mps':completed['horizontal_speed'],'released_after_tick':release['released_after_tick'],'settled':settled,'missing_settled_ticks':missing,'retained_snapshot_count':len(parsed),'first_retained_tick':parsed[0][1]['simulation_tick'],'last_retained_tick':parsed[-1][1]['simulation_tick'],'later_same_round_samples':len(later),'later_observed_simulation_span_seconds':(later[-1]['elapsed']-later[0]['elapsed']) if later else None,'later_max_endpoint_error_m':max((m['error_m'] for m in later_motion),default=None),'later_all_neutral_stopped_inside_radius':all(m['consumed_move']==[0,0] and m['horizontal_speed']<=.05 and m['error_m']<.45 for m in later_motion),'objective_ticks':hold['simulation_ticks'],'objective_seconds':hold['simulation_seconds'],'whole_wall_seconds':receipt['elapsed_seconds'],'owned_groups':groups}
args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(0 if result['all_checks_passed'] else 1)
