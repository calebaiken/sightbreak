import hashlib
import json
from pathlib import Path
import subprocess
import sys

from PIL import Image

ROOT = Path('/workspace/sightbreak-layout-ocr')
OUT = Path('/workspace/reviews/layout-ocr-revision-critic')
sys.path.insert(0, str(ROOT / 'scripts'))
from build_manifest import source
from capture_desktop_layouts import hud_footer_region, ocr_lines, rendered_hud_matches
from verify_integration_export import native_log_failed

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

run = ROOT / 'builds/native-layout-four-size-r1'
r = json.loads((run / 'results.json').read_text())
manifest = json.loads((ROOT / 'builds/native-candidate-r2/linux/source.json').read_text())
now = source()
assert now == r['source']
assert now['source_commit'] == 'afe7b5454572b3f14f8b9dbdbc47c5bfa7bc8331'
assert now['source_dirty'] is False and now['source_game_dirty'] is False
assert manifest == r['artifact_source']
assert {key: manifest[key] for key in now} == now
assert r['engine'] == '4.7.2.stable.official.ed1daf0bf'
assert r['requested_sizes'] == [[960, 540], [1280, 720], [1920, 1080], [1280, 800]]
assert r['capture_generation_passed'] is True and r['exact_source_unchanged'] is True
assert r['elapsed_seconds'] < 520
exe = Path(r['executable'])
assert exe.read_bytes()[:4] == b'\x7fELF'
assert sha(exe) == r['executable_sha256'] == manifest['artifact']['sha256']
assert exe.stat().st_size == manifest['artifact']['bytes']
payload = []
for p in manifest['payload']:
    path = ROOT / 'builds/native-candidate-r2' / p['path']
    assert sha(path) == p['sha256'] and path.stat().st_size == p['bytes']
    payload.append({'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size})

cases = []
for case in r['cases']:
    name = 'x'.join(map(str, case['size']))
    folder = run / name
    assert json.loads((folder / 'results.json').read_text()) == case
    assert case['capture_generation_passed'] is True
    assert case['native_menu_exit'] == case['native_live_exit'] == 0
    assert case['cleanup_errors'] == [] and 'error' not in case
    assert case['elapsed_seconds'] < 120
    assert all(c['exit_code'] == 0 for c in case['commands'])
    assert not native_log_failed((folder / 'menu.log').read_text(errors='replace'))
    assert not native_log_failed((folder / 'live-layout.log').read_text(errors='replace'))
    captures = []
    for c in case['captures']:
        path = folder / c['name']
        assert sha(path) == c['sha256']
        with Image.open(path) as raw:
            assert list(raw.size) == c['dimensions'] == case['size']
        captures.append({'name': c['name'], 'sha256': c['sha256'], 'dimensions': c['dimensions']})
    assert len(captures) == (7 if name == '1280x720' else 5)
    ocrs = []
    for o in case['ocr_commands']:
        label = o['label']
        original = label[:-7] if label.endswith('-footer') else label
        path = folder / (original + '-ocr-original.png')
        assert sha(path) == o['original_sha256']
        assert o['exit_code'] == 0
        assert (folder / (label + '.tsv')).is_file()
        with Image.open(path) as raw:
            assert list(raw.size) == case['size']
        if label.endswith('-footer'):
            full = next(p for p in case['ocr_commands'] if p['label'] == original)
            assert full['original_sha256'] == o['original_sha256']
            assert full['analysis_threshold'] == 145 and full['analysis_region'] is None
            assert o['analysis_region'] == list(hud_footer_region(case['size']))
            assert o['analysis_threshold'] is None and o['analysis_scale'] == 4
        ocrs.append(o)
    fences = []
    for a in case['actions']:
        if 'first_drawn_frames' in a:
            assert a['final_drawn_frames'] >= a['first_drawn_frames'] + 2
            fences.append({k: a[k] for k in ['label', 'first_drawn_frames', 'final_drawn_frames']})
    assert len(fences) == (7 if name == '1280x720' else 3)
    touch_actions = [a for a in case['actions'] if a.get('event') == 'touch_toggle_native_click']
    if name == '1280x720':
        assert [a['expected'] for a in touch_actions] == [True, False]
        assert all(a['native_input']['target_focused'] is True for a in touch_actions)
        touch = next(o for o in ocrs if o['label'].startswith('touch-hud-check'))
        keyboard = next(o for o in ocrs if o['label'].startswith('keyboard-hud-check') and not o['label'].endswith('-footer'))
        footer = next(o for o in ocrs if o['label'] == keyboard['label'] + '-footer')
        touch_rows = ocr_lines((folder / (touch['label'] + '.tsv')).read_text(), touch['analysis_scale'])
        keyboard_rows = ocr_lines((folder / (keyboard['label'] + '.tsv')).read_text(), keyboard['analysis_scale'])
        footer_rows = ocr_lines((folder / (footer['label'] + '.tsv')).read_text(), footer['analysis_scale'], origin=footer['analysis_region'][:2])
        assert rendered_hud_matches(touch_rows, True)
        assert not rendered_hud_matches(touch_rows, False, footer_rows)
        assert rendered_hud_matches(keyboard_rows, False, footer_rows)
    else:
        assert touch_actions == []
    progress = case['live_phase_wait']
    assert progress['stall_watchdog_seconds'] == 5 and progress['live_observed'] is True
    for a, b in zip(progress['samples'], progress['samples'][1:]):
        assert b['simulation_tick'] > a['simulation_tick'] and b['elapsed'] > a['elapsed']
        assert b['wall_seconds'] - a['wall_seconds'] < 5
    cases.append({'size': name, 'seconds': case['elapsed_seconds'], 'captures': captures,
                  'ocr_commands_verified': len(ocrs), 'fences': fences,
                  'native_exits': [case['native_menu_exit'], case['native_live_exit']],
                  'commands': case['commands'], 'cleanup_errors': case['cleanup_errors'],
                  'touch_actions': touch_actions,
                  'footer_ocr': [o for o in ocrs if o['label'].endswith('-footer')]})

result = {'source_now': now, 'source_receipt_sha256': sha(ROOT / 'builds/native-candidate-r2/linux/source.json'),
          'top_result_sha256': sha(run / 'results.json'), 'payload': payload,
          'elf_file': subprocess.check_output(['file', str(exe)], text=True).strip(),
          'seconds': r['elapsed_seconds'], 'cases': cases,
          'game_diff_from_previous': subprocess.check_output(['git', 'diff', '--stat', '3a847afa0903827dfa510f9c3c343061797c6457', 'afe7b5454572b3f14f8b9dbdbc47c5bfa7bc8331', '--', 'game'], cwd=ROOT, text=True)}
(OUT / 'native-receipt-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'source': now, 'seconds': r['elapsed_seconds'], 'cases': [{k:v for k,v in c.items() if k not in ['captures','commands','touch_actions','footer_ocr']} for c in cases]}, indent=2))
