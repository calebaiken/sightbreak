import csv
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

from PIL import Image

ROOT = Path('/workspace/sightbreak-layout-ocr')
OUT = Path('/workspace/reviews/layout-ocr-revision-critic/fresh-image-probes')
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT / 'scripts'))
from capture_desktop_layouts import hud_footer_region, ocr_input, ocr_lines, rendered_hud_matches

TESSERACT = shutil.which('tesseract')
measurements = []
def sha(data):
    return hashlib.sha256(data).hexdigest()

def analyze(raw, label, original_sha256, region=None):
    factor = 4 if region else (3 if raw.width < 1100 else 2)
    data = ocr_input(raw, factor, region=region, threshold=None if region else 145)
    (OUT / (label + '-analysis.png')).write_bytes(data)
    started = time.monotonic()
    result = subprocess.run([TESSERACT, 'stdin', 'stdout', '--psm', '11', 'tsv'],
                            input=data, capture_output=True, timeout=5, check=True)
    duration = time.monotonic() - started
    (OUT / (label + '.tsv')).write_bytes(result.stdout)
    text = result.stdout.decode()
    measurements.append({'label': label, 'seconds': duration, 'exit_code': result.returncode,
                         'original_sha256': original_sha256, 'analysis_sha256': sha(data),
                         'analysis_region': region, 'analysis_threshold': None if region else 145,
                         'analysis_scale': factor, 'words': [r['text'] for r in csv.DictReader(io.StringIO(text), delimiter='\t') if r['text'].strip()]})
    return ocr_lines(text, factor, origin=region[:2] if region else (0, 0))

probes, comparisons, failures = [], [], []
run = ROOT / 'builds/native-layout-four-size-r1'
for case in json.loads((run / 'results.json').read_text())['cases']:
    size = 'x'.join(map(str, case['size']))
    for capture in case['captures']:
        path = run / size / capture['name']
        before = sha(path.read_bytes())
        label = size + '-' + path.stem
        with Image.open(path) as raw:
            full = analyze(raw, label + '-full', before)
            footer = analyze(raw, label + '-footer', before, hud_footer_region(raw.size))
            actual = [rendered_hud_matches(full, False, footer), rendered_hud_matches(full, True)]
            expected = [capture['name'] in ['02-live-hud.png', '07-keyboard-mouse-restored.png'], capture['name'] == '06-touch-hud-opt-in.png']
            probe = {'path': str(path), 'sha256': before, 'size': list(raw.size), 'expected_desktop_touch': expected, 'actual_desktop_touch': actual, 'passed': actual == expected}
            probes.append(probe)
            if not probe['passed']:
                failures.append(probe)
            if capture['name'] == '02-live-hud.png':
                width, height = raw.size
                old_region = (width // 4, height * 4 // 5, width * 3 // 4, height)
                old_footer = analyze(raw, label + '-previous-footer', before, old_region)
                comparisons.append({'path': str(path), 'sha256': before,
                                    'previous_region': old_region, 'new_region': hud_footer_region(raw.size),
                                    'previous_desktop': rendered_hud_matches(full, False, old_footer),
                                    'candidate_desktop': actual[0]})
                missing = raw.copy()
                missing.paste((0, 0, 0), hud_footer_region(raw.size))
                erased_data = io.BytesIO()
                missing.save(erased_data, format='PNG')
                (OUT / (label + '-erased-footer.png')).write_bytes(erased_data.getvalue())
                erased_sha = sha(erased_data.getvalue())
                erased_full = analyze(missing, label + '-erased-full', erased_sha)
                erased_footer = analyze(missing, label + '-erased-footer', erased_sha, hud_footer_region(raw.size))
                erased_match = rendered_hud_matches(erased_full, False, erased_footer)
                probes.append({'counterexample_for': str(path), 'counterexample': 'erased footer', 'actual_desktop': erased_match, 'passed': not erased_match})
                if erased_match:
                    failures.append(probes[-1])
        assert sha(path.read_bytes()) == before == capture['sha256']

fixture = ROOT / 'docs/reports/gauntlet/native-layout-ocr/fixtures/1280x800-hud.png'
with Image.open(fixture) as raw:
    before = sha(fixture.read_bytes())
    full = analyze(raw, 'counterexample-original-full', before)
    old_region = (raw.width // 4, raw.height * 4 // 5, raw.width * 3 // 4, raw.height)
    old_footer = analyze(raw, 'counterexample-previous-footer', before, old_region)
    new_footer = analyze(raw, 'counterexample-candidate-footer', before, hud_footer_region(raw.size))
    comparisons.append({'path': str(fixture), 'sha256': before, 'previous_region': old_region,
                        'new_region': hud_footer_region(raw.size),
                        'previous_desktop': rendered_hud_matches(full, False, old_footer),
                        'candidate_desktop': rendered_hud_matches(full, False, new_footer)})

report = {'scope': 'Independent saved-pixel probes of newly generated native captures; no native renderer launched',
          'tesseract': subprocess.check_output([TESSERACT, '--version'], text=True).splitlines()[0],
          'probes': probes, 'comparisons': comparisons, 'measurements': measurements, 'failures': failures}
(OUT / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'probes': len(probes), 'calls': len(measurements), 'max_seconds': max(m['seconds'] for m in measurements), 'comparisons': comparisons, 'failures': failures}, indent=2))
sys.exit(bool(failures))
