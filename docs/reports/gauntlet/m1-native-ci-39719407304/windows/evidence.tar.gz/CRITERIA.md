# Independent native outcome review

Frozen CI source is `0ca125dfba637868e6e8e9772ff9c40400413e32`, run 39719407304, Windows job 119629141365 and Linux job 119629141916. The same-scope reference is run 39712752860 at `6a0d8d5d85b4fb37943903886982f51b4ed230b0`. This review judges actual combined outcomes; it does not repeat implementation acceptance.

Required evidence:

- Official connector metadata and transferred ZIP digests, with a clean matching source identity in raw scenario receipts. Reconstructed stdout JSON remains separately labeled if raw transfer fails.
- Ten actual native suites, unique engine-reported per-suite producer directories, fresh before-state, original source resources unchanged, genuine suite logs/exits, and successful owned cleanup. The original shared-save failure must improve on Windows/Linux.
- Actual exported keyboard/pointer input and reload outcomes with retained authority/action receipts. The Windows controlled delayed-capture pass remains distinct from the original delayed diagnostic schedule.
- Full ordinary offline journey under the unchanged 300-second flow budget, including rendered fire/reload/purchase/switch, settings save/restart, living-player native focus loss/explicit resume, held-input neutrality, release acknowledgment and subsequent fresh movement. The prior Windows OCR and Linux fresh-W failures must be compared separately.
- Player plant and defuse at unchanged stock rules, movement tolerance, 15-second movement budget and 180/300 physics-tick holds, with interrupted holds, one contribution, natural resolution and restart. Raw trace limits must be stated.
- Full natural first-to-seven match with ten actors, one completion, normal rules/protocol/prediction defaults, formula-correct earned offline XP/credits, and exact actual disk/restarted profile equality. This scripted player cannot establish human play quality or bot objective reliability.
- Linux captures at 960×540, 1280×720, 1920×1080 and 1280×800 under original 120/520-second limits, all native exits/cleanup and frame fences; inspect actual PNGs only when the full QA artifact is transferable. Preserve the limitation that live HUD classification executes only for 1280×720 touch-toggle.

Mac/iOS outcomes belong to a separate critic. One run cannot close complete G1, human experience, hardware performance or platform release gates. Preserve failures and name the largest remaining deficiency. No implementation edits or new local native renders are authorized for this critic.
