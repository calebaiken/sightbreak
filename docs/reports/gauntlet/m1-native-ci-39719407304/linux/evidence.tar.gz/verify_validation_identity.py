"""Recompute platform validation digests without editing source or running Godot."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser()
parser.add_argument('repo',type=Path)
parser.add_argument('--output',type=Path,required=True)
arguments=parser.parse_args()
repo=arguments.repo.resolve()
subprocess.run(['git','diff','--exit-code','0ca125dfba637868e6e8e9772ff9c40400413e32','--','scripts','.github','game/tests'],cwd=repo,check=True,stdout=subprocess.PIPE)
paths=[]
for directory in ['scripts','.github','game/tests']:
    for path in sorted((repo/directory).rglob('*')):
        if path.is_file() and not any(part in ['__pycache__','.godot'] for part in path.parts) and path.suffix!='.pyc':
            paths.append(path)
raw=subprocess.check_output(['git','check-attr','-z','--stdin','eol'],cwd=repo,
    input=b''.join(path.relative_to(repo).as_posix().encode()+b'\0' for path in paths)).split(b'\0')
eol={raw[index].decode():raw[index+2].decode() for index in range(0,len(raw)-1,3)}
lf,windows=hashlib.sha256(),hashlib.sha256()
changes=[]
for path in paths:
    relative=path.relative_to(repo).as_posix()
    data=path.read_bytes()
    prefix=relative.encode()+b'\0'
    lf.update(prefix+data+b'\0')
    if eol[relative]!='lf' and b'\0' not in data[:8000] and b'\n' in data:
        changes.append(relative)
        data=data.replace(b'\n',b'\r\n')
    windows.update(prefix+data+b'\0')
result={'recomputed_LF_validation_digest':lf.hexdigest(),
    'recomputed_Windows_checkout_validation_digest':windows.hexdigest(),
    'Windows_CRLF_files':changes,
    'linux_matches':lf.hexdigest()=='95844559cde01c1f9785d2835ea9f92a5e09e0315f87f0e7aa5029352456196c',
    'windows_matches':windows.hexdigest()=='982057ffe78de32a2795e61c48137d5b094461ec1ea74c62d8add55b22fb13a5'}
arguments.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
