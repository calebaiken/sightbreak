import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/sightbreak-client-result-recovery')
OUT = Path(__file__).resolve().parent
ENGINE = Path('/workspace/tools/godot-4.7.2/Godot_v4.7.2-stable_linux.x86_64')
SUITES = ['transaction_journal_test', 'economy_recovery_test', 'armory_state_test', 'menu_state_test', 'economy_ui_test']

def source():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()
    return dict(commit=git('rev-parse', 'HEAD'), game_tree=git('rev-parse', 'HEAD:game'), status=git('status', '--porcelain', '--untracked-files=all'))

before = source()
assert not before['status'], before
result = dict(before=before, engine_sha256=hashlib.sha256(ENGINE.read_bytes()).hexdigest(),
              engine_version=subprocess.check_output([str(ENGINE), '--version'], text=True).strip(),
              started=datetime.datetime.now(datetime.timezone.utc).isoformat(), suites=[])
(OUT / 'before.json').write_text(json.dumps(result, indent=2) + '\n')
for name in SUITES:
    command = [str(ROOT / 'scripts/godot.sh'), '--headless', '--script', 'res://tests/' + name + '.gd']
    state = OUT / (name + '-state')
    env = dict(os.environ, SIGHTBREAK_TOOLS_DIR='/workspace/tools', SIGHTBREAK_STATE_DIR=str(state))
    started = time.monotonic()
    process = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True, timeout=540)
    duration = time.monotonic() - started
    output = process.stdout + process.stderr
    (OUT / (name + '.log')).write_text(output)
    errors = [marker for marker in ['SCRIPT ERROR', 'ERROR:', 'Parse Error', 'ObjectDB instances leaked', 'resources still in use'] if marker in output]
    row = dict(name=name, command=command, state=str(state), exit=process.returncode, seconds=duration, errors=errors)
    result['suites'].append(row)
    (OUT / 'progress.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if process.returncode or errors:
        break
result['after'] = source()
result['ended'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
result['pass'] = (len(result['suites']) == len(SUITES) and all(not row['exit'] and not row['errors'] for row in result['suites']) and result['after'] == before)
(OUT / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
raise SystemExit(0 if result['pass'] else 1)
