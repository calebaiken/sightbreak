extends SceneTree
## Frozen source UI fixture only: no exported gameplay or rendered-layout pass.
## Exercise the actual _process status Label, never objective_hint directly.
var checks := 0
var failures := 0
var original_user_dir := ""
var original_custom_user_dir: Variant
var original_custom_user_dir_name: Variant
var fixture_name := ""
var fixture_user_dir := ""
var fixture_created := false
var marker_created := false
var fixture_removed := false

func check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error(message)

func _initialize() -> void:
	# Environment-only state roots do not redirect Godot's native macOS user://.
	# Use a private native directory before constructing any controller/profile.
	original_user_dir = OS.get_user_data_dir()
	original_custom_user_dir = ProjectSettings.get_setting("application/config/use_custom_user_dir")
	original_custom_user_dir_name = ProjectSettings.get_setting("application/config/custom_user_dir_name")
	fixture_name = "SIGHTBREAK_QA/hud-objective-hint-%d-%d" % [OS.get_process_id(), Time.get_ticks_usec()]
	ProjectSettings.set_setting("application/config/use_custom_user_dir", true)
	ProjectSettings.set_setting("application/config/custom_user_dir_name", fixture_name)
	fixture_user_dir = OS.get_user_data_dir()
	if fixture_parent_is_link():
		push_error("Refusing HUD fixture creation through a linked shared namespace")
		finish(2)
		return
	if fixture_user_dir == original_user_dir or not fixture_user_dir.replace("\\", "/").ends_with("/" + fixture_name) or DirAccess.dir_exists_absolute(fixture_user_dir):
		push_error("HUD fixture requires a new, distinct native user-data directory: " + fixture_user_dir)
		finish(2)
		return
	if DirAccess.make_dir_recursive_absolute(fixture_user_dir) != OK:
		push_error("Cannot create private HUD fixture directory: " + fixture_user_dir)
		finish(2)
		return
	fixture_created = true
	var marker_path := fixture_user_dir.path_join("hud-fixture-owner.txt")
	var marker := FileAccess.open(marker_path, FileAccess.WRITE)
	if marker == null:
		push_error("Cannot create private HUD fixture ownership marker: " + marker_path)
		finish(2)
		return
	marker_created = true
	marker.store_string(fixture_name)
	marker.close()
	if FileAccess.get_file_as_string("user://hud-fixture-owner.txt") != fixture_name:
		push_error("HUD fixture user:// does not resolve to its private native directory")
		finish(2)
		return
	print("HUD_OBJECTIVE_HINT_TEST_STATE native_user_dir=%s original_user_dir=%s owner=%s" % [fixture_user_dir, original_user_dir, fixture_name])
	run.call_deferred()

func fixture_parent_is_link() -> bool:
	var data_directory := DirAccess.open(OS.get_data_dir())
	return data_directory != null and data_directory.is_link("SIGHTBREAK_QA")

func fixture_entry_exists() -> bool:
	var parent := DirAccess.open(fixture_user_dir.get_base_dir())
	return DirAccess.dir_exists_absolute(fixture_user_dir) or FileAccess.file_exists(fixture_user_dir) or (parent != null and parent.is_link(fixture_user_dir.get_file()))

func cleanup_fixture() -> String:
	if not fixture_created:
		return ""
	var expected := OS.get_data_dir().path_join(fixture_name).simplify_path()
	if fixture_user_dir.simplify_path() != expected or fixture_user_dir == original_user_dir:
		return "Refusing HUD cleanup outside its private native directory"
	if fixture_parent_is_link():
		return "Refusing HUD cleanup through a linked shared namespace"
	var parent := DirAccess.open(fixture_user_dir.get_base_dir())
	if parent == null or parent.is_link(fixture_user_dir.get_file()):
		return "Refusing HUD cleanup for an unavailable or linked fixture directory"
	var directory := DirAccess.open(fixture_user_dir)
	if directory == null:
		return "Cannot inspect private HUD fixture directory"
	directory.include_hidden = true
	directory.include_navigational = false
	if directory.list_dir_begin() != OK:
		return "Cannot list private HUD fixture directory"
	var entries: Array[String] = []
	var entry := directory.get_next()
	while not entry.is_empty():
		entries.append(entry)
		entry = directory.get_next()
	directory.list_dir_end()
	var marker_path := fixture_user_dir.path_join("hud-fixture-owner.txt")
	if marker_created:
		if entries != ["hud-fixture-owner.txt"] or directory.is_link("hud-fixture-owner.txt") or FileAccess.get_file_as_string(marker_path) != fixture_name:
			return "Refusing HUD cleanup because ownership changed or protected files remain"
		if DirAccess.remove_absolute(marker_path) != OK:
			return "Cannot remove private HUD fixture ownership marker"
	elif not entries.is_empty():
		return "Refusing HUD cleanup because unowned files remain"
	if DirAccess.remove_absolute(fixture_user_dir) != OK:
		return "Cannot remove empty private HUD fixture directory"
	fixture_removed = not fixture_entry_exists()
	if not fixture_removed:
		return "Private HUD fixture entry remains after removal"
	return ""

func finish(exit_code: int) -> void:
	var reason := cleanup_fixture()
	ProjectSettings.set_setting("application/config/use_custom_user_dir", original_custom_user_dir)
	ProjectSettings.set_setting("application/config/custom_user_dir_name", original_custom_user_dir_name)
	var restored := OS.get_user_data_dir() == original_user_dir
	if not restored:
		reason += " Original native user directory was not restored"
	var final_exit := exit_code if exit_code != 0 or reason.is_empty() else 2
	print("HUD_OBJECTIVE_HINT_TEST_CLEANUP " + JSON.stringify({"native_user_dir":fixture_user_dir, "owner":fixture_name, "owned":fixture_created, "removed":fixture_removed, "original_user_dir_restored":restored, "reason":reason, "original_exit":exit_code, "exit":final_exit}))
	if not reason.is_empty():
		push_error(reason)
	quit(final_exit)

func expect_status(main: Node, game: Node, actor: Node, item: Dictionary, context: String) -> void:
	# These are declared HUD-only state inputs. Physics is disabled before its
	# first tick; none of this establishes objective or match completion evidence.
	game.phase = item.get("phase", "live")
	game.objective_state = item.get("objective", "carried")
	game.objective_carrier = actor.actor_id if item.get("carrier", true) else 2
	actor.team = item.get("team", 0)
	actor.alive = item.get("alive", true)
	actor.health = 100 if actor.alive else 0
	main.elapsed = 1000.0
	main.status_label.set_meta("until", 0.0)
	main.status_label.text = "STALE HUD TEXT"
	main._process(0.0)
	var actual: String = main.status_label.text
	check(actual == item.expected, "%s %s: expected '%s', actual '%s'" % [context, item.name, item.expected, actual])

func notification_priority_benchmark(main: Node, game: Node, actor: Node, touch_enabled: bool) -> void:
	# Declared HUD-only inputs. Repeated _process calls do not advance gameplay.
	var control := "USE" if touch_enabled else "E"
	var combat := ["Relay device armed — defend the site", "Echo  ›  Rook", "Sable  ›  Morrow", "Sable  ›  Slate", "Ember  ›  Operator", "Sable  ›  Echo"]
	var wrong_frames := 0
	var samples := 0
	for state in ["offline", "hosting", "connected"]:
		game.connection_state = state
		game.connection_notice = ""
		for role in [
			{"name": "attacker", "team": 0, "alive": true, "expected": "DEFEND THE DEVICE"},
			{"name": "defender", "team": 1, "alive": true, "expected": "HOLD %s NEAR THE DEVICE TO DEFUSE" % control},
			{"name": "spectator", "team": 0, "alive": false, "expected": "SPECTATING YOUR SQUAD"},
		]:
			game.phase = "live"
			game.objective_state = "planted"
			actor.team = role.team
			actor.alive = role.alive
			actor.health = 100 if actor.alive else 0
			for index in range(81):
				main.elapsed = 2000.0 + index * 0.25
				main.show_notification(combat[index % combat.size()])
				main._process(0.0)
				var correct: bool = main.status_label.text == role.expected
				samples += 1
				if not correct: wrong_frames += 1
				check(correct, "planted priority touch=%s state=%s role=%s sample=%d: expected '%s', actual '%s'" % [touch_enabled, state, role.name, index, role.expected, main.status_label.text])
				print("HUD_PRIORITY_SAMPLE " + JSON.stringify({"touch":touch_enabled, "connection":state, "role":role.name, "sample":index, "ui_elapsed":main.elapsed, "until":main.status_label.get_meta("until", 0.0), "actual":main.status_label.text, "expected":role.expected, "correct":correct, "game_tick":game._simulation_tick}))
	# Critical reasons use typed state/callback data, not matching message text.
	actor.team = 0
	actor.alive = true
	actor.health = 100
	for state in ["connecting", "joining", "authenticating", "reconnecting", "failed"]:
		game.connection_state = state
		var reason := "QA typed %s reason — 接続" % state
		game._notify_connection_status(reason)
		for index in range(3):
			main.elapsed = 2100.0 + index * 10.0
			main.show_notification(combat[index])
			main._process(0.0)
			check(main.status_label.text == reason, "typed %s reason survives ordinary notice beyond expiry touch=%s sample=%d" % [state, touch_enabled, index])
	game.connection_state = "connected"
	# An inactive connection reason must never leak after recovery.
	main._process(0.0)
	check(main.status_label.text == "DEFEND THE DEVICE", "connected role replaces obsolete critical reason touch=%s" % touch_enabled)
	# Exercise the actual welcome callback with this frozen fixture's valid snapshot.
	var snapshot: Dictionary = game._snapshot()
	game.connection_state = "reconnecting"
	game.connection_notice = "QA retained recovery reason"
	game._authority = false
	game._welcome_rpc(actor.actor_id, "", snapshot)
	check(game.connection_state == "connected" and game.connection_notice.is_empty(), "successful welcome clears the retained critical reason touch=%s" % touch_enabled)
	main._process(0.0)
	check(main.status_label.text == "DEFEND THE DEVICE", "welcome restores the current planted role touch=%s" % touch_enabled)
	game._authority = true
	game._pending_reconciliation.clear()
	game.connection_state = "offline"
	game.connection_notice = ""
	for item in [
		{"name": "waiting after flood", "phase": "waiting", "expected": "WAITING FOR AUTHENTICATED PLAYERS   1 / 10"},
		{"name": "buy after flood", "phase": "buy", "expected": "BUY PHASE   /   %s TO EQUIP" % ("TAP BUY" if touch_enabled else "PRESS B")},
		{"name": "post after flood", "phase": "post", "objective": "planted", "expected": "ROUND COMPLETE"},
		{"name": "completed after flood", "phase": "match_over", "objective": "planted", "expected": "OPERATION COMPLETE"},
	]:
		expect_status(main, game, actor, item, "touch=%s" % touch_enabled)
	print("HUD_PRIORITY_BENCHMARK " + JSON.stringify({"touch":touch_enabled, "samples":samples, "wrong_frames":wrong_frames, "scope":"frozen HUD fixture; no gameplay tick advanced"}))

func run() -> void:
	if FileAccess.file_exists("user://offline_training.json"):
		push_error("Use fresh isolated SIGHTBREAK_STATE_DIR; player saves are never overwritten")
		finish(2)
		return
	var source := "res://scripts/main.gd"
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--baseline-source="):
			source = argument.trim_prefix("--baseline-source=")
	var script: Script = load(source)
	if script == null or not script.can_instantiate():
		push_error("HUD main source did not compile: " + source)
		finish(2)
		return
	var main = script.new()
	main.set_process(false)
	main.set_physics_process(false)
	root.add_child(main)
	main.set_process(false)
	main.set_physics_process(false)
	main.start_match({"mode": "offline", "difficulty": "easy", "name": "Frozen HUD fixture"})
	var game = main.match_game
	game.set_process(false)
	game.set_physics_process(false)
	game.process_mode = Node.PROCESS_MODE_DISABLED
	var actor = game.local_actor()
	check(game._simulation_tick == 0 and game._elapsed == 0.0, "HUD fixture freezes before the first match tick")
	for touch_enabled in [false, true]:
		main.profile.data.settings.touch_visible = touch_enabled
		main.build_hud()
		var control := "USE" if touch_enabled else "E"
		var context := "touch=%s" % touch_enabled
		var cases := [
			{"name": "living attacker carrier", "expected": "HOLD %s AT A SITE TO PLANT" % control},
			{"name": "other living attacker", "carrier": false, "expected": "ESCORT THE DEVICE CARRIER"},
			{"name": "attacker dropped device", "objective": "dropped", "expected": "RECOVER THE RELAY DEVICE"},
			{"name": "attacker planted device", "objective": "planted", "expected": "DEFEND THE DEVICE"},
			{"name": "defender planted device", "team": 1, "objective": "planted", "expected": "HOLD %s NEAR THE DEVICE TO DEFUSE" % control},
			{"name": "defender carried device", "team": 1, "expected": "DEFEND THE TWO OBJECTIVE SITES"},
			{"name": "defender dropped device", "team": 1, "objective": "dropped", "expected": "DEFEND THE TWO OBJECTIVE SITES"},
			{"name": "post round", "phase": "post", "objective": "planted", "expected": "ROUND COMPLETE"},
			{"name": "completed operation", "phase": "match_over", "objective": "planted", "expected": "OPERATION COMPLETE"},
			{"name": "eliminated player", "alive": false, "objective": "planted", "expected": "SPECTATING YOUR SQUAD"},
			{"name": "authenticated waiting room", "phase": "waiting", "expected": "WAITING FOR AUTHENTICATED PLAYERS   1 / 10"},
			{"name": "buy phase", "phase": "buy", "expected": "BUY PHASE   /   %s TO EQUIP" % ("TAP BUY" if touch_enabled else "PRESS B")},
		]
		for item in cases:
			expect_status(main, game, actor, item, context)
		expect_status(main, game, actor, cases[0], context)
		main.show_notification("QA: live notification remains visible")
		main._process(0.0)
		check(main.status_label.text == "QA: live notification remains visible", context + ": unexpired live notification is preserved")
		main.elapsed = 1006.0
		main._process(0.0)
		check(main.status_label.text == cases[0].expected, context + ": expired live notification returns to the correct hint")
		notification_priority_benchmark(main, game, actor, touch_enabled)
	check(game._simulation_tick == 0 and game._elapsed == 0.0, "Status rendering never advances the frozen gameplay fixture")
	check(main.profile.data.matches == 0 and not FileAccess.file_exists("user://offline_training.json"), "HUD fixture never awards or saves training progression")
	main.queue_free()
	await process_frame
	print("HUD_OBJECTIVE_HINT_TEST source=%s scope=frozen_source_ui checks=%d failures=%d" % [source, checks, failures])
	finish(1 if failures else 0)
