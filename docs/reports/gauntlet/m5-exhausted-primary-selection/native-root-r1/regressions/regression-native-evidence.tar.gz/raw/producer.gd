extends SceneTree
func _initialize() -> void:
    var destination := ""
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--receipt="):
            destination = argument.trim_prefix("--receipt=")
    var receipt := {"user_data_dir":OS.get_user_data_dir(), "data_dir":OS.get_data_dir(),
        "project_path":ProjectSettings.globalize_path("res://"), "os":OS.get_name(),
        "custom_user_dir":ProjectSettings.get_setting("application/config/custom_user_dir_name"),
        "uses_custom_user_dir":ProjectSettings.get_setting("application/config/use_custom_user_dir"),
        "profile_exists":FileAccess.file_exists("user://offline_training.json"),
        "diagnostics_exist":DirAccess.dir_exists_absolute(ProjectSettings.globalize_path("user://offline-diagnostics-unit"))}
    var file := FileAccess.open(destination, FileAccess.WRITE)
    if file == null:
        push_error("Cannot write native user-directory receipt")
        quit(2)
        return
    file.store_string(JSON.stringify(receipt, "  "))
    file.close()
    quit(0)
