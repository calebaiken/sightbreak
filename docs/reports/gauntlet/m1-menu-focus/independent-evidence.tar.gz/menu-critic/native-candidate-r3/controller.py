#!/usr/bin/env python3
"""Independent narrow native field-menu critic. OS input + one-way stock observer."""
import argparse, ctypes as C, hashlib, json, os, shutil, signal, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts'))
from verify_integration_export import NativeUI
from build_manifest import source, validate_record
from native_observation import read_observation_json
import toolchain
p = argparse.ArgumentParser()
p.add_argument('--output', type=Path, required=True)
p.add_argument('--display', default=':223')
p.add_argument('--expected-resume', choices=['yes','no'], default='yes')
a=p.parse_args()
out=a.output.resolve(); out.mkdir(parents=True,exist_ok=False)
started=time.monotonic(); deadline=started+240
trace=out/'trace'; actions=[]; processes=[]; ui=None; client=None
result={'expected_initial_return_resumes': a.expected_resume=='yes', 'passed':False, 'scope':'Linux exported OS keyboard, software rendering; no hardware/controller/full-flow claim'}
def write(): (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
def event(kind, **kw):
    record={'event':kind,'seconds':time.monotonic()-started,**kw}
    actions.append(record)
    with (out/'actions.jsonl').open('a') as f: f.write(json.dumps(record)+'\n')
def launch(name, command, env):
    f=(out/(name+'.log')).open('w')
    proc=subprocess.Popen(command,env=env,cwd=out,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
    f.close(); processes.append((name,proc)); event('command',name=name,command=command,pid=proc.pid)
    return proc
last={}
def state():
    global last
    if client and client.poll() is not None: raise RuntimeError('Native client exited early')
    try: s=read_observation_json(trace/'status.json')
    except (OSError,ValueError): return last
    if s.get('scope')!='debug_offline_read_only_observation' or s.get('scenario')!='standard' or s.get('time_scale')!=1: raise RuntimeError('Trace scope/stock conditions mismatch')
    last=s; return s
def wait(pred, seconds, label, observe=True):
    until=min(deadline,time.monotonic()+seconds)
    while time.monotonic()<until:
        v=state() if observe else None
        if pred(v): event('observed',label=label,state=v if observe else None); return v
        time.sleep(.08)
    raise TimeoutError(label)
def key(name,down):
    event('key_before',key=name,down=down); ui.key(name,down); event('key_after',key=name,down=down)
def tap(name):
    key(name,True); time.sleep(.13); key(name,False); time.sleep(.3)
def capture(name):
    prior=state().get('drawn_frames')
    if prior is not None:
        wait(lambda s:s.get('drawn_frames',-1)>=prior+2,10,'two completed rendered frames before '+name)
        time.sleep(.12)
    path=out/(name+'.png'); ui.capture(path)
    event('capture',path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),state=state(),native=ui.diagnostics())
def observed(label):
    s=state(); event('snapshot',label=label,state=s,native=ui.diagnostics()); return s
try:
    receipt=source(); manifest=validate_record('linux',receipt)
    exe=Path(os.environ.get('SIGHTBREAK_BUILDS_DIR',ROOT/'builds'))/'linux/sightbreak.x86_64'
    result.update(source=receipt,artifact=manifest,engine=toolchain.verify_engine(),executable=str(exe))
    env=dict(os.environ)
    xv=launch('xvfb',['/workspace/tools/xvfb/usr/bin/Xvfb',a.display,'-screen','0','1280x720x24','-nolisten','tcp'],env)
    socket=Path('/tmp/.X11-unix/X'+a.display[1:])
    wait(lambda _:socket.exists(),5,'isolated Xvfb socket',False)
    env.update(DISPLAY=a.display,LIBGL_ALWAYS_SOFTWARE='1',LP_NUM_THREADS='2',DBUS_SESSION_BUS_ADDRESS='unix:path='+str(out/'unavailable-bus'))
    for var,part in [('XDG_DATA_HOME','data'),('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache')]:
        env[var]=str(out/'state'/part); Path(env[var]).mkdir(parents=True,exist_ok=True)
    event('environment',environment={k:env[k] for k in ('DISPLAY','LIBGL_ALWAYS_SOFTWARE','LP_NUM_THREADS','XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME')})
    ui=NativeUI(a.display)
    if shutil.which('ffmpeg'):
        launch('video',['ffmpeg','-y','-f','x11grab','-framerate','10','-video_size','1280x720','-i',a.display,'-c:v','libx264','-preset','ultrafast','-crf','20',str(out/'native-raw.mp4')],env)
    command=[str(exe),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--position','0,0','--accessibility','disabled','--accessibility-driver','dummy','--','--offline-validation','--offline-trace-dir='+str(trace)]
    client=launch('client',command,env)
    wait(lambda _:ui.focus_game(),25,'native game focus',False)
    wait(lambda _:ui.menu_visible(),40,'rendered main menu',False)
    capture('01-main-menu')
    event('deploy_click_before',x=248,y=319); ui.click(248,319); event('deploy_click_after',x=248,y=319)
    wait(lambda s:s.get('ui',{}).get('screen')=='game' and bool(s.get('local_actor')),30,'stock offline readiness')
    capture('02-stock-offline-game')
    tap('Escape')
    paused=wait(lambda s:s.get('ui',{}).get('paused') is True and s.get('ui',{}).get('mouse_mode')==0,8,'Escape opens paused field menu')
    capture('03-initial-field-menu')
    time.sleep(.8); frozen=observed('pause stability after .8 seconds')
    for field in ('elapsed','simulation_tick','time_left','round_number'):
        assert paused[field]==frozen[field],('Offline simulation advanced while menu open',field,paused[field],frozen[field])
    tap('Return')
    if a.expected_resume=='no':
        time.sleep(.8); still=observed('baseline Return has no focused action')
        assert still['ui']['paused'] is True, 'Baseline unexpectedly resumed'
        capture('04-baseline-return-still-paused')
        result['baseline_no_initial_keyboard_action']=True
        tap('Escape')
        wait(lambda s:s.get('ui',{}).get('paused') is False,5,'baseline Escape closes field menu')
    else:
        wait(lambda s:s.get('ui',{}).get('paused') is False and s['ui'].get('mouse_mode')==2,8,'initial Return explicitly resumes with captured mouse')
        capture('04-return-resumed')
        tap('Escape'); wait(lambda s:s['ui']['paused'] is True,5,'second field-menu open')
        capture('05-second-open-resume')
        for index,label in enumerate(('settings','edit-touch-hud','leave-match','resume'),6):
            tap('Tab'); capture('%02d-tab-%s'%(index,label))
        for index,label in enumerate(('leave-match','edit-touch-hud','settings','resume'),10):
            key('Shift_L',True); tap('Tab'); key('Shift_L',False); time.sleep(.2); capture('%02d-shifttab-%s'%(index,label))
        tap('Return'); wait(lambda s:s['ui']['paused'] is False,5,'Return resumes after full forward/reverse traversal')
        tap('Escape'); wait(lambda s:s['ui']['paused'] is True,5,'third field-menu open')
        capture('14-third-open-resume')
        tap('Return'); wait(lambda s:s['ui']['paused'] is False,5,'third Return resumes')
        capture('15-third-return-resumed')
        # Buy phase suppresses actor input; wait for stock live before input guard.
        wait(lambda s:s.get('phase')=='live',120,'ordinary live phase before focus guard')
        # First acknowledge actual consumed input, then lose native OS focus.
        key('w',True); ui.button(True); event('button',down=True)
        held=wait(lambda s:s.get('local_input',{}).get('fire') is True and s.get('local_input',{}).get('move')!=[0,0],8,'native W and LMB acknowledged before focus loss')
        event('focus_loss_before',native=ui.diagnostics())
        ui.x.XSetInputFocus(ui.d,ui.x.XDefaultRootWindow(ui.d),1,0); ui.x.XFlush(ui.d)
        lost=wait(lambda s:s['ui']['focused'] is False and s['ui']['paused'] is True,8,'native focus loss pauses offline match')
        wait(lambda _:ui.focus_game(),5,'restore native window focus',False)
        restored=wait(lambda s:s['ui']['focused'] is True,8,'game observes restored OS focus')
        assert restored['ui']['paused'] is True and restored['ui']['mouse_mode']==0, 'Focus restoration implicitly resumed'
        capture('16-focus-restored-still-paused')
        baseline_ammo=restored['local_actor']['ammo']
        tap('Return')
        safe=wait(lambda s:s['ui']['paused'] is False and s.get('local_input',{}).get('move')==[0,0] and s['local_input'].get('fire') is False,8,'explicit Return resumes with held input neutral')
        time.sleep(.6); safe=observed('held input remains neutral after explicit focus-recovery resume')
        native=ui.diagnostics()
        assert native['keys_down']['w'] and native['lmb_down'], 'Held native controls were not still down'
        assert safe['local_input']['move']==[0,0] and safe['local_input']['fire'] is False and safe['local_actor']['ammo']==baseline_ammo, 'Held input leaked after focus recovery'
        capture('17-focus-recovery-return-neutral')
        key('w',False); ui.button(False); event('button',down=False)
        result['candidate_native_cycles']=3
        result['focus_recovery_held_input_guard']=True
    ui.request_close(); event('standard_native_window_close_requested')
    client.wait(timeout=15); result['client_exit_code']=client.returncode
    assert client.returncode==0,'Native client did not exit cleanly'
    result['passed']=True
except BaseException as e:
    result['error']=str(e)
    event('failure',error=str(e))
    if ui:
        try: capture('failure-native')
        except BaseException as ce: event('failure_capture_error',error=str(ce))
finally:
    if ui:
        for k in ('Return','Escape','Tab','Shift_L','w'):
            try: ui.key(k,False)
            except BaseException: pass
        try: ui.button(False)
        except BaseException: pass
    if ui:
        ui.close(); ui=None
    for name,proc in reversed(processes):
        if proc.poll() is None:
            try:
                os.killpg(proc.pid,signal.SIGINT if name=='video' else signal.SIGTERM); proc.wait(timeout=7)
            except BaseException:
                try: os.killpg(proc.pid,signal.SIGKILL); proc.wait(timeout=5)
                except BaseException: pass
        event('process_cleanup',name=name,exit_code=proc.returncode)
    result['seconds']=time.monotonic()-started
    result['commands']=[x for x in actions if x['event']=='command']
    result['raw_screenshots']=sorted(p.name for p in out.glob('*.png'))
    write()
print(json.dumps({'passed':result['passed'],'error':result.get('error'),'seconds':result['seconds'],'output':str(out)}))
raise SystemExit(0 if result['passed'] else 1)
