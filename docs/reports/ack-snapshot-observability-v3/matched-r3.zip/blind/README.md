# Neutral ACK-observation outcomes

Assess sample-C.json and sample-R.json before opening any source map or author report.
The declared bar is complete observations for reconciled snapshots, including five formerly
unscored repeated-ACK held-state snapshots per burst condition, with correct snapshot-relative
drift and bounded lifecycle state. Compare every pre-existing movement/ACK/correction output.
A first observed snapshot is NOT a consumption-time pose; its earlier hold duration is unknown.
Duplicate/out-of-order outer ticks, round/reconnect resets and cache saturation are included.
metric_windows names the inclusive61–540 same-time window and ACK samples received through540;
P95 uses sorted[int((n-1)*0.95)]. The original540-tick schedule is followed by90 recovery ticks: 
neutral input through600, then complete input/history/authority/bidirectional packet drain by630.
transport_ledger retains every input/snapshot send, delivery and dropped input batch.
The lifecycle receipt includes a known0.4m snapshot-offset positive control distinct from0.3m command error.
Named native maintained-gate logs are included under each neutral sample folder. Source/capture/cache
manifests and the label map are separate from this neutral packet; inspect them after the first verdict.
This is deterministic in-process scheduling, not ENet, and can demonstrate observability only.
No gameplay accuracy, performance or prediction activation win is claimed by this bar.
