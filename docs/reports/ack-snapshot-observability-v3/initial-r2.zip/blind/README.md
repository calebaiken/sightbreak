# Neutral ACK-observation outcomes

Assess sample-C.json and sample-R.json before opening any source map or author report.
The declared bar is complete observations for reconciled snapshots, including five formerly
unscored repeated-ACK held-state snapshots per burst condition, with correct snapshot-relative
drift and bounded lifecycle state. Compare every pre-existing movement/ACK/correction output.
A first observed snapshot is NOT a consumption-time pose; its earlier hold duration is unknown.
Duplicate/out-of-order outer ticks, round/reconnect resets and cache saturation are included.
This is deterministic in-process scheduling, not ENet, and can demonstrate observability only.
No gameplay accuracy, performance or prediction activation win is claimed by this bar.
